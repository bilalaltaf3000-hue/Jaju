// HR Dashboard → Summary: the restructuring at a glance (Current → Proposed), for the CHRO
import React, { useEffect, useMemo, useState } from 'react'
import { api } from '../api.js'
import { fmt } from '../org.js'
import { L, prefs, LABEL_DEFAULT } from '../prefs.js'
import { Modal, types } from '../ui.jsx'

const nz = v => (v ? fmt(v) : '–')
const XC = { fte: '#00796B', dc: '#D99A1E', ftc: '#7CC8BA', dw: '#9A7CC4' }
const SRC = [['', 'Entered'], ['pr', 'PR contract staff replaced'], ['nonpr', 'Non-PR staff replaced'], ['trade', 'Trade Staff Realignment'], ['redeploy', 'Trade Staff Redeployment']]
const qKey = q => { const m = /Q\s*([1-4])\D*(\d{4})/i.exec(q || ''); return m ? +m[2] * 10 + +m[1] : 99999 }

// people of one type: all, FTE (permanent and PR contract) or FTC (and daily wagers)
const ofType = t => p => t === 'FTE' ? p.fte : t === 'FTC' ? !p.fte : true

// the figures of one state: staff, managers (anyone with a direct report), direct-report links, HR layers (KM L1, his directs L2 …)
function shape(O, full, tf = () => true) {   // full: everyone in the state; tf: the type counted (FTE / FTC: their managers, of any type)
  const inS = new Set(full), pop = full.filter(tf)
  const reps = p => p.kids.filter(k => inS.has(k) && tf(k)).length
  const mgr = full.filter(p => reps(p) > 0), links = mgr.reduce((a, p) => a + reps(p), 0)
  const lay = {}; pop.forEach(p => { if (p.d >= 0) lay[p.d + 1] = (lay[p.d + 1] || 0) + 1 })
  const fns = new Set(pop.filter(p => p !== O.ROOT).map(p => O.F[p.f]).filter(Boolean))
  return { staff: pop.length, mgr: mgr.length, links, span: mgr.length ? links / mgr.length : 0, mgrOwn: pop.filter(p => p.kids.some(k => inS.has(k))).length, layers: Math.max(0, ...Object.keys(lay).map(Number)), lay, fns: fns.size }
}

// Headcount by Layer: Current bars, Proposed dashed line, the table underneath
function LayerBars({ A, B, onPick }) {
  const n = Math.max(1, ...Object.keys(A).map(Number), ...Object.keys(B).map(Number)), Ls = Array.from({ length: n }, (_, i) => i + 1)
  const W = 1000, H = 180, pl = 120, pr = 0, pt = 26, pb = 26   // pl: the table's label column (12%), so bars and columns line up
  const raw = Math.max(1, ...Object.values(A), ...Object.values(B)), step = Math.pow(10, Math.floor(Math.log10(raw))) / (raw / Math.pow(10, Math.floor(Math.log10(raw))) > 5 ? 1 : 2), top = Math.ceil(raw * 1.1 / step) * step
  const cw = (W - pl - pr) / n, X = l => pl + (l - 0.5) * cw, Y = v => pt + (H - pt - pb) * (1 - v / top), y0 = Y(0)
  const ticks = []; for (let v = 0; v <= top + 1e-9; v += step) ticks.push(v)
  const line = Ls.map((l, i) => `${i ? 'L' : 'M'}${X(l)},${Y(B[l] || 0)}`).join(' ')
  return <div className="sx-chart">
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="Headcount by layer">
      {ticks.map(v => <g key={v}><line x1={pl} x2={W - pr} y1={Y(v)} y2={Y(v)} className="sm-grid" /><text x={pl - 14} y={Y(v) + 4} textAnchor="end" className="sx-ax">{fmt(v) === '-' ? 0 : fmt(v)}</text></g>)}
      {Ls.map(l => { const a = A[l] || 0
        return <g key={l} className="sm-pt" onClick={() => onPick(l)}><rect x={X(l) - cw * 0.22} y={Y(a)} width={cw * 0.44} height={Math.max(0, y0 - Y(a))} rx="2" className="sx-bar" />
          <text x={X(l)} y={Math.min(Y(a), Y(B[l] || 0)) - 9} textAnchor="middle" className="sx-v">{fmt(a) === '-' ? 0 : fmt(a)}</text>
          <text x={X(l)} y={H - 6} textAnchor="middle" className="sm-l">L{l}</text></g> })}
      <path d={line} className="sx-line" />
      {Ls.map(l => <circle key={l} cx={X(l)} cy={Y(B[l] || 0)} r="5" className="sx-dot" />)}
    </svg>
    <table className="sx-tb"><tbody>
      <tr><th>{L('hr.cur')}</th>{Ls.map(l => <td key={l}>{fmt(A[l] || 0) === '-' ? 0 : fmt(A[l] || 0)}</td>)}</tr>
      <tr><th>{L('hr.pro')}</th>{Ls.map(l => <td key={l}>{fmt(B[l] || 0) === '-' ? 0 : fmt(B[l] || 0)}</td>)}</tr>
      <tr><th>Change</th>{Ls.map(l => { const d = (B[l] || 0) - (A[l] || 0); return <td key={l} className={d > 0 ? 'up' : d < 0 ? 'dn' : ''}>{d ? (d > 0 ? '+' : '−') + fmt(Math.abs(d)) : '–'}</td> })}</tr>
    </tbody></table>
  </div>
}

const ICON = {
  people: <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.2" /><path d="M5.5 19c.6-3.3 3.2-5 6.5-5s5.9 1.7 6.5 5" /><circle cx="5.5" cy="10" r="2.2" /><circle cx="18.5" cy="10" r="2.2" /></svg>,
  mgr: <svg viewBox="0 0 24 24"><circle cx="10" cy="8" r="3.4" /><path d="M3.5 19.5c.6-3.6 3.3-5.5 6.5-5.5 1.3 0 2.5.3 3.5.9" /><circle cx="17.5" cy="16.5" r="2.4" /><path d="M17.5 12.6v1.5M17.5 18.9v1.5M13.6 16.5h1.5M19.9 16.5h1.5" /></svg>,
  org: <svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="5" rx="1" /><rect x="3" y="16" width="6" height="5" rx="1" /><rect x="15" y="16" width="6" height="5" rx="1" /><path d="M12 8v4M6 16v-4h12v4" /></svg>,
  gear: <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2" /><path d="M12 2.8v2.6M12 18.6v2.6M2.8 12h2.6M18.6 12h2.6M5.5 5.5l1.8 1.8M16.7 16.7l1.8 1.8M5.5 18.5l1.8-1.8M16.7 7.3l1.8-1.8" /></svg>,
  chart: <svg viewBox="0 0 24 24"><path d="M4 20h16M6 17v-4M10 17V9M14 17v-6M18 17V5" /></svg>,
  coin: <svg viewBox="0 0 24 24"><ellipse cx="12" cy="6" rx="7" ry="2.6" /><path d="M5 6v6c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6V6M5 12v6c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6v-6" /></svg>,
  target: <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" /><circle cx="12" cy="12" r="4.5" /><circle cx="12" cy="12" r="1.2" /><path d="M15 9l5-5M17 4h3v3" /></svg>,
}

// the function-wise table (the HR team's format; not the top person's own function), below the sections
function FnBlock({ oa, ob, curFull, proFull, tf }) {
  const [side, setSide] = useState('cur')
  const O = side === 'pro' ? ob : oa, full = side === 'pro' ? proFull : curFull
  const inS = new Set(full), pop = full.filter(tf), all = pop.length
  const by = {}
  const row = p => { const f = O.F[p.f] || '–'; return by[f] || (by[f] = { f, hc: 0, m: 0, links: 0, ml: 0 }) }
  pop.forEach(p => { if (p === O.ROOT) return; const x = row(p); x.hc++; x.ml = Math.max(x.ml, p.d + 1) })
  full.forEach(p => { if (p === O.ROOT) return; const r = p.kids.filter(k => inS.has(k) && tf(k)).length; if (r) { const x = row(p); x.m++; x.links += r } })   // FTE / FTC: their managers, of any type
  const rows = Object.values(by).filter(x => x.hc && x.f !== (O.F[O.ROOT.f] || '')).sort((a, b) => b.hc - a.hc)
  const T = rows.reduce((t, x) => ({ hc: t.hc + x.hc, m: t.m + x.m, links: t.links + x.links, ml: Math.max(t.ml, x.ml) }), { hc: 0, m: 0, links: 0, ml: 0 })
  return <div className="sz-p sz-fn"><div className="sz-ph"><h3>Function-wise</h3>
    <div className="sy-seg" role="group">{[['cur', L('hr.cur')], ['pro', L('hr.pro')]].map(([k, t]) => <button key={k} type="button" aria-pressed={side === k} onClick={() => setSide(k)}>{t}</button>)}</div></div>
    <div className="tw"><table className="sz-ft">
      <thead><tr><th>Function</th><th className="num">HC</th><th className="num">% of HC</th><th className="num">Managers</th><th className="num">Avg Span</th><th className="num">Manager Density</th><th className="num">Max Layer</th></tr></thead>
      <tbody>{rows.map(x => <tr key={x.f}><td>{x.f}</td><td className="num"><b>{fmt(x.hc)}</b></td><td className="num">{all ? Math.round(x.hc / all * 100) : 0}%</td><td className="num">{nz(x.m)}</td>
        <td className="num">{x.m ? Math.round(x.links / x.m) : '–'}</td><td className="num">{x.hc ? Math.round(x.m / x.hc * 100) + '%' : '–'}</td><td className="num">L{x.ml}</td></tr>)}</tbody>
      <tfoot><tr><td>Total</td><td className="num">{fmt(T.hc)}</td><td className="num">{all ? Math.round(T.hc / all * 100) : 0}%</td><td className="num">{nz(T.m)}</td><td className="num">{T.m ? Math.round(T.links / T.m) : '–'}</td><td className="num">{T.hc ? Math.round(T.m / T.hc * 100) : 0}%</td><td className="num">L{T.ml}</td></tr></tfoot></table></div>
    {all - T.hc > 0 && <p className="sz-fnote">Excludes {O.ROOT.n || 'the head'}{O.F[O.ROOT.f] ? ` (${O.F[O.ROOT.f]})` : ''}: {fmt(all - T.hc)}</p>}
  </div>
}

// administrators: the initiatives (name, from the portal or entered, number, description, quarter)
function InitEdit({ rows, notify, onSaved, onClose }) {
  const [rs, setRs] = useState(() => rows.map(r => ({ ...r, n: r.n ?? '' })))
  const set = (i, k, v) => setRs(x => x.map((r, j) => j === i ? { ...r, [k]: v } : r))
  const save = async () => { try { const r = await api('/api/chro/summary-inits', { method: 'PUT', body: { rows: rs } }); notify('Saved.'); onSaved(r) } catch (e) { notify(e.message, true) } }
  return <Modal wide title="Headcount Saves Opportunities" sub="Number: blank uses the portal's count (for the portal ones)" onClose={onClose}>
    <div className="tw scroll" style={{ maxHeight: 460 }}><table>
      <thead><tr><th>Initiative</th><th>Number from</th><th className="num">Number</th><th>Description</th><th>Quarter</th><th /></tr></thead>
      <tbody>{rs.map((r, i) => <tr key={r.id || i}>
        <td><input className="inp" value={r.name} onChange={e => set(i, 'name', e.target.value)} style={{ width: '100%' }} /></td>
        <td><select className="inp" value={r.src} onChange={e => set(i, 'src', e.target.value)}>{SRC.map(([k, t]) => <option key={k} value={k}>{t}</option>)}</select></td>
        <td><input className="inp" value={r.n} onChange={e => set(i, 'n', e.target.value.replace(/[^0-9]/g, ''))} placeholder={r.src ? 'portal' : ''} style={{ width: 80, textAlign: 'right' }} /></td>
        <td><input className="inp" value={r.desc} onChange={e => set(i, 'desc', e.target.value)} style={{ width: '100%' }} /></td>
        <td><input className="inp" value={r.q} onChange={e => set(i, 'q', e.target.value)} placeholder="Q1 2027" style={{ width: 110 }} /></td>
        <td><button className="btn sm" onClick={() => setRs(x => x.filter((_, j) => j !== i))}>Remove</button></td></tr>)}</tbody></table></div>
    <div className="row-actions" style={{ justifyContent: 'space-between', marginTop: 10 }}>
      <button className="btn" onClick={() => setRs(x => [...x, { id: '', name: '', src: '', n: '', desc: '', q: '' }])}>Add an initiative</button>
      <button className="btn pri" onClick={save}>Save</button></div>
  </Modal>
}


const ICON2 = {
  target: <svg viewBox="0 0 24 24"><circle cx="11" cy="13" r="8" /><circle cx="11" cy="13" r="4.5" /><circle cx="11" cy="13" r="1.2" /><path d="M14 10l6-6M17 4h3v3" /></svg>,
  stack: <svg viewBox="0 0 24 24"><path d="M12 3l9 4.5-9 4.5-9-4.5z" /><path d="M3 12l9 4.5 9-4.5M3 16.5l9 4.5 9-4.5" /></svg>,
  pin: <svg viewBox="0 0 24 24"><path d="M12 21s-6.5-6.2-6.5-11.2a6.5 6.5 0 0 1 13 0C18.5 14.8 12 21 12 21z" /><circle cx="12" cy="9.8" r="2.4" /></svg>,
  team: <svg viewBox="0 0 24 24"><circle cx="12" cy="7.5" r="3" /><path d="M6.5 19c.5-3.2 2.8-5 5.5-5s5 1.8 5.5 5" /><circle cx="5" cy="9.5" r="2" /><circle cx="19" cy="9.5" r="2" /><path d="M1.8 17.5c.3-2 1.5-3.2 3.2-3.4M22.2 17.5c-.3-2-1.5-3.2-3.2-3.4" /></svg>,
  org: <svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="5" rx="1" /><rect x="3" y="16" width="6" height="5" rx="1" /><rect x="15" y="16" width="6" height="5" rx="1" /><path d="M12 8v4M6 16v-4h12v4" /></svg>,
  gear: <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2" /><path d="M12 2.8v2.6M12 18.6v2.6M2.8 12h2.6M18.6 12h2.6M5.5 5.5l1.8 1.8M16.7 16.7l1.8 1.8M5.5 18.5l1.8-1.8M16.7 7.3l1.8-1.8" /></svg>,
  doc: <svg viewBox="0 0 24 24"><path d="M6 3h8l4 4v14H6z" /><path d="M14 3v4h4M9 12h6M9 15.5h6M9 9h2" /></svg>,
  head: <svg viewBox="0 0 24 24"><path d="M4 14v-2a8 8 0 0 1 16 0v2" /><rect x="3" y="13.5" width="4" height="6" rx="1.5" /><rect x="17" y="13.5" width="4" height="6" rx="1.5" /><path d="M19 19.5c0 1.2-1.6 2-4 2h-2" /></svg>,
  bank: <svg viewBox="0 0 24 24"><path d="M3 9l9-5 9 5M5 9v9M9.5 9v9M14.5 9v9M19 9v9M3 21h18" /></svg>,
  chart: <svg viewBox="0 0 24 24"><path d="M4 20h16M6 17v-4M10 17V9M14 17v-6M18 17V5" /></svg>,
  coin: <svg viewBox="0 0 24 24"><ellipse cx="12" cy="6" rx="7" ry="2.6" /><path d="M5 6v6c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6V6M5 12v6c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6v-6" /></svg>,
}
const initIcon = n => /rpa|automat|robot/i.test(n) ? 'gear' : /contact|call|centre|center/i.test(n) ? 'head' : /cheque|cad|digiti|document/i.test(n) ? 'doc' : /trade|branch|retail/i.test(n) ? 'bank' : /staff|replace|hiring|talent/i.test(n) ? 'team' : 'gear'
// health bands (green healthy, amber watch, red priority)
const band = { span: v => v >= 8 ? 'g' : v >= 5 ? 'a' : 'r', dens: v => v <= 12 ? 'g' : v <= 20 ? 'a' : 'r', lay: v => v <= 5 ? 'g' : v === 6 ? 'a' : 'r' }
const VERD = { g: 'Healthy', a: 'Watch', r: 'Priority' }
const ratio = v => (Math.round(v * 10) / 10).toFixed(1) + ' : 1'

// the Summary tab's texts, editable on the page (Edit text) and in Admin → Labels; {x} are filled in
const TX = [
  ['Banner', [['sum.h1', 'Title'], ['sum.title', 'Tagline (comma-separated)'], ['sum.sub', 'Line under the tagline']]],
  ['Current → Proposed', [['sum.curh', 'Current heading'], ['sum.proh', 'Proposed heading'], ['sum.k1', 'Total employees'], ['sum.k2', 'Managers'], ['sum.k2s', 'Managers, under'], ['sum.k2a', 'Span box'], ['sum.k3', 'Managerial positions'], ['sum.k3b', 'Managerial positions, box'], ['sum.mgrade', 'Managerial grade (from this grade up)']]],
  ['Strategic Alignment', [['sum.s1', 'Heading'], ['sum.t1', 'Tile 1'], ['sum.sa1', 'Tile 1 text', 1], ['sum.t2', 'Tile 2'], ['sum.sa2', 'Tile 2 text', 1], ['sum.t3', 'Tile 3'], ['sum.sa3', 'Tile 3 text', 1], ['sum.t4', 'Tile 4'], ['sum.sa4', 'Tile 4 text', 1]]],
  ['Headcount Savings', [['sum.s2', 'Heading'], ['sum.hard', 'First list (Exit Candidates)'], ['sum.ex', 'Exit Candidates line'], ['sum.add', 'Second list'], ['sum.tp', 'Overall total']]],
  ['Tables', [['sum.s3', 'Assessment heading'], ['sum.s4', 'Hierarchy heading'], ['sum.s5', 'Layers heading'], ['sum.s4s', 'Hierarchy, beside the heading ({name})']]],
]
function TextEdit({ title1, notify, onSaved, onClose }) {
  const [v, setV] = useState(() => { const o = {}; TX.forEach(([, ks]) => ks.forEach(([k]) => { o[k] = k === 'sum.h1' ? (prefs.labels[k] || title1) : L(k) })); return o })
  const save = async () => {
    const out = {}; TX.forEach(([, ks]) => ks.forEach(([k]) => { const d = k === 'sum.h1' ? title1 : (LABEL_DEFAULT[k] || ''), t = (v[k] || '').trim(); out[k] = t && t !== d ? t : '' }))
    try { const r = await api('/api/chro/summary-text', { method: 'PUT', body: { labels: out } }); prefs.labels = r.labels || {}; notify('Saved.'); onSaved() } catch (e) { notify(e.message, true) }
  }
  return <Modal wide title="Edit text" sub="Summary tab · a blank box goes back to the standard text" onClose={onClose}>
    <div className="sv-te">{TX.map(([g, ks]) => <fieldset key={g}><legend>{g}</legend>{ks.map(([k, lab, long]) => <label key={k} className={long ? 'long' : ''}><span>{lab}</span>
      {long ? <textarea className="inp" rows={2} value={v[k]} onChange={e => setV({ ...v, [k]: e.target.value })} /> : <input className="inp" value={v[k]} onChange={e => setV({ ...v, [k]: e.target.value })} />}</label>)}</fieldset>)}</div>
    <div className="row-actions" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="btn" onClick={onClose}>Cancel</button><button className="btn pri" onClick={save}>Save</button></div>
  </Modal>
}
const fill = (k, vars = {}) => L(k).replace(/\{(\w+)\}/g, (m, x) => (vars[x] ?? m))

export default function Summary({ oa, ob, obAll, op, fnName, canEdit, notify, people, onBench, onUnits, onGeo }) {
  const [typ, setTyp] = useState('all')
  const [txOpen, setTxOpen] = useState(false), [, setTick] = useState(0), [sec, setSec] = useState('')
  const [inits, setInits] = useState(null)
  const [edit, setEdit] = useState(false), [consOpen, setConsOpen] = useState(false)
  useEffect(() => { api('/api/chro/summary-inits').then(setInits).catch(() => setInits([])) }, [])
  const tf = ofType(typ)
  const proFull = useMemo(() => ob ? ob.P.filter(p => !p.ctx && !p.rs && (ob.counted(p) || p.hs)) : [], [ob])   // Proposed: no one taken off (the Headcount Saves stay in), the same staff as the Current State
  if (!oa || !ob) return <div className="loading">Loading…</div>
  // managerial positions: staff at the managerial grade (Admin → Labels, HR Summary) and above
  const mgG = L('sum.mgrade').trim().toLowerCase(), mgP = [...oa.P, ...ob.P].find(p => (p.g || '').toLowerCase() === mgG), mgR = mgP ? mgP.rk : Infinity
  const st = (O, full) => { const inS = new Set(full), pop = full.filter(tf)
    const reps = p => p.kids.filter(k => inS.has(k) && tf(k)).length
    const mgr = full.filter(p => reps(p) > 0), links = mgr.reduce((x, p) => x + reps(p), 0)
    return { O, full, inS, pop, staff: pop.length, mgr: mgr.length, links, span: mgr.length ? links / mgr.length : 0, mpos: pop.filter(p => p.rk != null && p.rk >= mgR).length,
      fte: pop.filter(p => p.fte).length, ftc: pop.filter(p => !p.fte).length, reps } }
  const A = st(oa, oa.C), B = st(ob, proFull)
  const layOf = S => { const m = {}; S.pop.forEach(p => { if (p.d >= 0) m[p.d + 1] = (m[p.d + 1] || 0) + 1 }); return m }
  const red = (a, b) => { const d = a - b; return d > 0 ? `(${fmt(d)} reduction, −${Math.round(d / Math.max(1, a) * 100)}%)` : d < 0 ? `(${fmt(-d)} increase, +${Math.round(-d / Math.max(1, a) * 100)}%)` : '(no change)' }
  const srcRows = { pr: (op?.pr || []).filter(r => r.pr), nonpr: (op?.pr || []).filter(r => !r.pr), trade: op?.trade || [], redeploy: op?.redeploy || [] }
  const num = r => r.n !== null && r.n !== undefined && r.n !== '' ? +r.n : r.src ? srcRows[r.src].length : 0
  const openInit = r => { if (!r.src) return; const ps = srcRows[r.src].map(x => obAll.byId.get(x.code)).filter(Boolean); ps.length && people(r.name, ps, obAll) }
  const yr = r => +((/(\d{4})/.exec(r.q || '') || [])[1] || 0)
  const sorted = [...(inits || [])].sort((a, b) => qKey(a.q) - qKey(b.q))
  const exit = op?.exit || [], more = sorted   // Hardcore Saves: the Exit Candidates; the initiatives are the opportunities
  const exitSub = [['dc', 'PR Contract'], ['fte', 'FTE'], ['ftc', 'FTC'], ['dw', 'Daily Wagers']].map(([k, t]) => [t, exit.filter(r => r.t === k).length]).filter(x => x[1]).map(x => `${x[0]} ${fmt(x[1])}`).join(' · ')
  const openExit = () => { const ps = exit.map(x => obAll.byId.get(x.code)).filter(Boolean); ps.length && people(L('sum.ex'), ps, obAll) }
  const tot = rs => rs.reduce((x, r) => x + num(r), 0)
  const nCons = (op?.units_n || 0) + (op?.cross || []).length, nGeo = (op?.geo || []).length, nTal = (op?.pr || []).length
  const talent = () => { const ps = (op?.pr || []).map(x => obAll.byId.get(x.code)).filter(Boolean); ps.length && people(L('sum.t4'), ps, obAll) }

  const State = ({ k, S, base }) => <div className={'sv-st ' + k}>
    <h2>{L(k === 'cur' ? 'sum.curh' : 'sum.proh')}</h2>
    <div className="sv-sg two">
      <div className="sv-sm"><i>{ICON2.org}</i><span><b>{fmt(S.mgr)}</b><em>{L('sum.k2')}</em><small>{L('sum.k2s')}</small></span>
        <span className="sv-chip box"><small>{L('sum.k2a')}</small><b>{ratio(S.span)}</b></span></div>
      <div className="sv-sm"><i>{ICON2.gear}</i><span><b>{fmt(S.mpos)} <small className="of">of {fmt(S.staff)}</small></b><em>{L('sum.k3')}</em></span>
        <span className="sv-chip box"><small>{base ? red(base.mpos, S.mpos).replace(/[()]/g, '') : L('sum.k3b')}</small><b>{Math.round(S.mpos / Math.max(1, S.staff) * 100)}%</b></span></div>
    </div></div>

  // Organizational Assessment: function-wise with health bands
  const S2 = B   // the tables are of the Proposed State
  const rowsAs = (() => { const by = {}, O = S2.O, rf = O.F[O.ROOT.f] || ''
    const row = p => { const f = O.F[p.f] || '–'; return by[f] || (by[f] = { f, hc: 0, m: 0, links: 0, ml: 0 }) }
    S2.pop.forEach(p => { if (p === O.ROOT) return; const x = row(p); x.hc++; x.ml = Math.max(x.ml, p.d + 1) })
    S2.full.forEach(p => { if (p === O.ROOT) return; const r = S2.reps(p); if (r) { const x = row(p); x.m++; x.links += r } })
    return Object.values(by).filter(x => x.hc && x.f !== rf).sort((a, b) => b.hc - a.hc).map(x => { const span = x.m ? x.links / x.m : 0, dens = x.m / x.hc * 100
      const bs = [x.m ? band.span(span) : 'g', band.dens(dens), band.lay(x.ml)], nr = bs.filter(b => b === 'r').length, na = bs.filter(b => b === 'a').length
      return { ...x, span, dens, bs, v: nr >= 2 ? 'r' : nr || na >= 2 ? 'a' : 'g' } }) })()
  // Hierarchy Analysis: the top person, then their direct reports, each with their whole team (Proposed State)
  const S3 = B
  const rowsHi = (() => { const R = S3.O.ROOT
    return R.kids.filter(k => S3.inS.has(k)).map(d => { const sub = [], st = [d]; while (st.length) { const p = st.pop(); sub.push(p); p.kids.forEach(k => S3.inS.has(k) && st.push(k)) }
      const ps = sub.filter(tf), ms = sub.filter(p => S3.reps(p) > 0), links = ms.reduce((x, p) => x + S3.reps(p), 0)
      return { d, ps, hc: ps.length, m: ms.length, links, span: ms.length ? links / ms.length : 0, ml: Math.max(0, ...ps.map(p => p.d + 1)) } }).filter(x => x.hc || x.m).sort((a, b) => b.hc - a.hc) })()
  const RT = S3.O.ROOT, rIn = S3.inS.has(RT), rR = rIn ? S3.reps(RT) : 0, rHc = rIn && tf(RT) ? 1 : 0
  const hiT = rowsHi.reduce((t, x) => ({ hc: t.hc + x.hc, m: t.m + x.m, links: t.links + x.links }), { hc: rHc, m: rR ? 1 : 0, links: rR })
  const Init = r => <button type="button" key={r.id || r.name} className={'sv-in' + (r.src ? '' : ' static')} onClick={() => openInit(r)}><i>{ICON2[initIcon(r.name)]}</i>
    <span><b>{r.name}</b><small>{[r.desc, r.q && `by ${r.q}`].filter(Boolean).join(' · ')}</small></span><em>{nz(num(r))}</em></button>

  const title0 = `${fnName || L('dash.title')} – 2026`, title = prefs.labels['sum.h1'] || title0
  return <div className="sv">
    <div className="sv-ban">
      <div><h1>{title}</h1>
        <div className="sv-tag">{L('sum.title').split(/[,|]/).map(x => x.trim()).filter(Boolean).map((x, k) => <span key={k}>{x.replace(/\.$/, '')}</span>)}</div>
        <p>{L('sum.sub')}</p></div>
      <div className="sv-bt">{canEdit && <button type="button" className="sv-tx" onClick={() => setTxOpen(true)}>Edit text</button>}
      <div className="sv-seg dk" role="group" aria-label="Staff type">{[['all', 'All Staff'], ['FTE', 'FTE'], ['FTC', 'FTC']].map(([k, t]) => <button key={k} type="button" aria-pressed={typ === k} onClick={() => setTyp(k)}>{t}</button>)}</div></div>
    </div>

    <div className="sv-te2">
      <div className="sv-tl"><i>{ICON2.team}</i><span><b>{L('sum.k1')}</b><small>{typ === 'all' ? 'All functions & layers' : typ}</small></span></div>
      <button type="button" className="sv-tv" onClick={() => people(L('sum.k1'), A.pop, A.O)}><small>{L('sum.curh')}</small><b>{fmt(A.staff)}</b></button>
      {typ === 'all' && <><span className="sv-tsp"><small>FTE</small><b>{fmt(A.fte)}</b><em>{Math.round(A.fte / Math.max(1, A.staff) * 100)}%</em></span>
        <span className="sv-tsp"><small>FTC</small><b>{fmt(A.ftc)}</b><em>{Math.round(A.ftc / Math.max(1, A.staff) * 100)}%</em></span></>}
    </div>

    <div className="sv-states"><State k="cur" S={A} /><span className="sv-go" aria-hidden="true"><i /><b><svg viewBox="0 0 24 24"><path d="M5 12h13M13 6l6 6-6 6" /></svg></b><i /></span><State k="pro" S={B} base={A} /></div>

    <div className="sz-nav sv-nav" role="tablist">{[['s1', 'sum.s1'], ['s2', 'sum.s2'], ['s3', 'sum.s3'], ['s4', 'sum.s4'], ['s5', 'sum.s5']].map(([k, lk], n) =>
      <button key={k} type="button" role="tab" aria-selected={sec === k} className={'sz-b' + (sec === k ? ' on' : '')} onClick={() => setSec(sec === k ? '' : k)}>
        <span className="n">0{n + 1}</span><span className="t">{L(lk)}</span><span className="chev" aria-hidden="true">›</span></button>)}</div>
    {sec === 's1' && <div className="sv-one" key="s1">
      <div className="sv-p"><h3 className="sv-h">{L('sum.s1')}</h3>
        <div className="sv-sa">{[
          ['target', L('sum.t1'), 'sum.sa1', onBench, 'L1 – L7'],
          ['stack', L('sum.t2'), 'sum.sa2', () => setConsOpen(true), nCons],
          ['pin', L('sum.t3'), 'sum.sa3', () => nGeo && onGeo(), nGeo],
          ['team', L('sum.t4'), 'sum.sa4', talent, nTal],
        ].map(([ic, t, lk, go, v]) => <button type="button" key={lk} className="sv-sai" onClick={go}><i>{ICON2[ic]}</i><b>{t}</b><p>{L(lk)}</p>{v !== '' && <em>{typeof v === 'number' ? nz(v) : v}</em>}</button>)}</div></div>
    </div>}
    {sec === 's2' && <div className="sv-one" key="s2">
      <div className="sv-p"><h3 className="sv-h">{L('sum.s2')}{canEdit && <button type="button" className="sv-ed" onClick={() => setEdit(true)}>Edit</button>}</h3>
        {!inits ? <div className="formula" style={{ padding: 14 }}>Loading…</div> : <div className="sv-hs2">
          <button type="button" className="sv-hard" onClick={openExit}><i>{ICON2.team}</i><span><small>{L('sum.hard')}</small><b>{L('sum.ex')}</b><em>{exitSub}</em></span><strong>{nz(exit.length)}</strong></button>
          <h4>{L('sum.add')}<span>{nz(tot(more))}</span></h4>
          <div className="sv-ol">{more.map(Init)}</div>
          <div className="sv-tt"><span>{L('sum.tp')}</span><b>{nz(exit.length + tot(more))}</b></div>
        </div>}</div>
    </div>}
    {sec === 's3' && <div className="sv-one" key="s3">
      <div className="sv-p plain"><h3 className="sv-h2">{L('sum.s3')}</h3>
        <div className="tw"><table className="sv-tb"><thead><tr><th>Function</th><th className="num">HC</th><th className="num">% of HC</th><th className="num">Mgrs.</th><th className="num">Avg Span</th><th className="num">Mgr. Density</th><th className="num">Max Layer</th></tr></thead>
          <tbody>{rowsAs.map(x => <tr key={x.f}><td className="h1" title={x.f}>{x.f}</td><td className="num">{fmt(x.hc)}</td><td className="num">{Math.round(x.hc / Math.max(1, S2.staff) * 100)}%</td><td className="num">{nz(x.m)}</td>
            <td className="num">{x.m ? ratio(x.span).replace(' : 1', '') : '–'}</td><td className="num">{Math.round(x.dens)}%</td><td className="num">L{x.ml}</td></tr>)}</tbody></table></div></div>
    </div>}
    {sec === 's4' && <div className="sv-one" key="s4">
      <div className="sv-p plain"><h3 className="sv-h2">{L('sum.s4')}<small>{fill('sum.s4s', { name: S3.O.ROOT.pos || S3.O.ROOT.n })}</small></h3>
        <div className="tw"><table className="sv-tb"><thead><tr><th>Title</th><th className="num">HC</th><th className="num">Mgrs.</th><th className="num">Avg Span</th><th className="num">Max Layer</th></tr></thead>
          <tbody>{rIn && <tr className="top"><td className="h1">{RT.pos || RT.n}</td><td className="num">{rHc}</td><td className="num">{rR ? 1 : '–'}</td><td className="num">{rR ? ratio(rR).replace(' : 1', '') : '–'}</td><td className="num">L1</td></tr>}
            {rowsHi.map(x => <tr key={x.d.id} className="ck" onClick={() => x.ps.length && people(`${x.d.pos || x.d.n} – team`, x.ps, S3.O)}><td className="h1" title={x.d.n}>{x.d.pos || x.d.n}</td>
            <td className="num">{fmt(x.hc) === '-' ? 0 : fmt(x.hc)}</td><td className="num">{nz(x.m)}</td><td className="num">{x.m ? ratio(x.span).replace(' : 1', '') : '–'}</td><td className="num">{x.ml ? 'L' + x.ml : '–'}</td></tr>)}
</tbody>
          <tfoot><tr><td>Total</td><td className="num">{fmt(hiT.hc)}</td><td className="num">{fmt(hiT.m)}</td><td className="num">{hiT.m ? ratio(hiT.links / hiT.m).replace(' : 1', '') : '–'}</td><td /></tr></tfoot></table></div></div>
    </div>}
    {sec === 's5' && <div className="sv-one" key="s5"><div className="sv-p plain"><h3 className="sv-h2">{L('sum.s5')}<span className="sx-lg"><i className="b" />{L('sum.curh')} <i className="l" />{L('sum.proh')}</span></h3>
      <LayerBars A={layOf(A)} B={layOf(B)} onPick={l => { const ps = B.pop.filter(p => p.d + 1 === l); ps.length && people(`Layer ${l} (${L('sum.proh')})`, ps, B.O) }} /></div></div>}


    {txOpen && <TextEdit title1={title0} notify={notify} onSaved={() => { setTxOpen(false); setTick(x => x + 1) }} onClose={() => setTxOpen(false)} />}
    {edit && <InitEdit rows={inits || []} notify={notify} onSaved={r => { setInits(r); setEdit(false) }} onClose={() => setEdit(false)} />}
    {consOpen && <Modal title="Consolidation of Units" onClose={() => setConsOpen(false)}>
      <div className="hx-ogr">{[[`Within ${ob.groupLabel}`, op?.units_n || 0, () => onUnits('within')], ['Geographic', (op?.geo || []).length, onGeo], [`Outside ${ob.groupLabel}`, (op?.cross || []).length, () => onUnits('outside')]].map(([t, v, go], j) =>
        <button type="button" key={t} className="hx-or" disabled={!v} onClick={() => { setConsOpen(false); go() }}><span className="hx-orn">{j + 1}</span><span className="hx-ort">{t}</span><b>{nz(v)}</b></button>)}</div></Modal>}
  </div>
}

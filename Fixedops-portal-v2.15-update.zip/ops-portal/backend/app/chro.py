"""CHRO dashboard: the As Is organisation (the HR master file, which the admin can correct or replace) against the
To Be (the portal as it is now, after every change), with what changed between them.

As Is  = the chro_asis table. It starts as a copy of the HR master file as it was imported (each employee's HR
         manager and HR function), can be edited (add missing employees, fix a manager, function, grade) and can be
         replaced by uploading another HR file. It is used only by the CHRO dashboard.
To Be  = the employees in the portal today, without the resigned and without the roles marked "headcount saved"
         (their direct reports move up to the next manager). Positions to be hired are shown beside it.
Layers are counted as on the main dashboard: from each person's level in Structure & Benchmark (the layer panel),
otherwise down the reporting line from the top person (L1), the same way for both sides, so the two can be compared."""
import io
import re
from datetime import datetime
from typing import Dict, List, Optional

from openpyxl import load_workbook
from sqlalchemy.orm import Session

from . import models
from .importer import OPTIONAL, REGION_HEADERS, REQUIRED, _norm_header, clean_name, code_text, grade_label, grade_rank, is_outsourced, strip_prefix
from .logic import shown_grade, vac_kind_label
from .security import get_setting, set_setting

META = "chro_asis_meta"
BANDS = [("1–2", 1, 2), ("3–5", 3, 5), ("6–10", 6, 10), ("11–15", 11, 15), ("16+", 16, 10 ** 6)]


def _kind(e) -> str:
    return "dw" if getattr(e, "is_dw", False) else "dc" if getattr(e, "is_dc", False) else ""


def _tkey(emp_type: str, kind: str) -> str:
    return kind if kind in ("dc", "dw") else ("fte" if (emp_type or "FTE") == "FTE" else "ftc")


# ------------------------------------------------------------------ the As Is store
def meta(db) -> dict:
    return get_setting(db, META) or {}


def _db_sig(db) -> str:
    """A fingerprint of the HR master data held in the database: changes when a new HR master file is imported
    (or the HR reference is loaded) in Admin, so the As Is built from the database follows it."""
    import hashlib
    h = hashlib.md5()
    imp = get_setting(db, "last_import") or {}
    h.update(str(imp.get("at") or "").encode())
    h.update(repr(get_setting(db, "hr_sheet_header") or []).encode())
    for c, m, f, n, s in db.query(models.Employee.code, models.Employee.hr_manager_code, models.Employee.hr_function_id, models.Employee.hr_row_no,
                                   models.Employee.source).order_by(models.Employee.code):
        h.update(f"{c}|{m}|{f}|{n}|{s == 'added'};".encode())
    return h.hexdigest()


def _hr_cols(db) -> Dict[str, int]:
    header = [_norm_header(h) for h in (get_setting(db, "hr_sheet_header") or [])]
    return {k: header.index(n) for k, n in {**REQUIRED, **OPTIONAL}.items() if n in header}


def seed_from_hr(db: Session, by: str = "", keep_edits: bool = False) -> int:
    """(Re)build the As Is from the database: each employee as HR has them in the HR master file imported in Admin
    (their HR row: name, grade, position, gender; their HR manager and HR function), not as changed in the portal since.
    keep_edits: keep the As Is corrections and additions made on the dashboard."""
    kept = {}
    if keep_edits:
        kept = {a.code: a for a in db.query(models.AsIsEmp).filter(models.AsIsEmp.source != "file")}
    db.query(models.AsIsEmp).filter(~models.AsIsEmp.code.in_(list(kept) or [""])).delete(synchronize_session="fetch")
    fns = {f.id: f.name for f in db.query(models.Function)}
    col = _hr_cols(db)

    def cell(row, key):
        i = col.get(key)
        return row[i] if row and i is not None and i < len(row) and row[i] not in (None, "") else None

    n = 0
    for e in db.query(models.Employee):
        if e.source == "added" or e.code in kept:
            continue   # not in the HR file / corrected on the dashboard
        hm = e.hr_manager_code
        mgr = e.manager_code if hm == "?" else hm
        hf = e.hr_function_id
        fn = fns.get(hf) if hf not in (None, -1) else None
        r = e.hr_row if isinstance(e.hr_row, list) else None
        g = str(cell(r, "grade") or "").strip()
        name = clean_name(cell(r, "name")) if cell(r, "name") else ""
        pos = strip_prefix(cell(r, "position")) if cell(r, "position") else ""
        gen = str(cell(r, "gender") or "").strip().lower()[:1]
        db.add(models.AsIsEmp(code=e.code, name=name or e.name, grade=grade_label(g) if g else (e.grade or ""), grade_raw=g or e.grade_raw or "",
                              grade_rank=grade_rank(g) if g else (e.grade_rank if e.grade_rank is not None else -1),
                              position=pos or e.position or "", function=fn or fns.get(e.function_id, ""), manager_code=mgr or None,
                              emp_type=("FTC" if is_outsourced(g) else "FTE") if g else (e.emp_type or "FTE"),
                              kind=_kind(e), gender=gen if r and "gender" in col else (e.gender or ""), unit=e.unit_name or "", source="file"))
        n += 1
    imp = get_setting(db, "last_import") or {}
    set_setting(db, META, {"source": "hr", "file": imp.get("file") or "HR master file (as imported)", "at": imp.get("at") or "",
                           "loaded_at": datetime.now().strftime("%Y-%m-%d %H:%M"), "by": by, "rows": n + len(kept), "edits": len(kept), "sig": _db_sig(db)})
    db.commit()
    return n + len(kept)


def ensure(db: Session):
    """The As Is exists; when it comes from the database (no HR file uploaded for the dashboard), it follows the HR
    master data there, keeping the corrections made on the dashboard."""
    if not db.query(models.AsIsEmp.code).first():
        seed_from_hr(db, "portal")
        return
    m = meta(db)
    if m.get("source", "hr") == "hr" and m.get("sig") != _db_sig(db):
        seed_from_hr(db, m.get("by") or "portal", keep_edits=True)


def read_hr_file(content: bytes) -> Dict[str, dict]:
    """The employees of an HR master file (same columns as the Admin import)."""
    wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    ws = wb.worksheets[0]
    rows = ws.iter_rows(values_only=True)
    header = [_norm_header(h) for h in next(rows, [])]
    idx = {k: header.index(n) for k, n in {**REQUIRED, **OPTIONAL}.items() if n in header}
    missing = [REQUIRED[k] for k in REQUIRED if k not in idx]
    if missing:
        raise ValueError("Missing columns: " + ", ".join(missing) + ". Use the HR master file layout (or the As Is export).")
    extra = {k: header.index(k) for k in ("unit", "type", "contract / daily wager") if k in header}
    recs = {}
    for r in rows:
        code = code_text(r[idx["code"]]) if len(r) > idx["code"] else ""
        if not code or code in recs:
            continue
        g = str(r[idx["grade"]] or "").strip()
        typ = str(r[extra["type"]] or "").strip().upper() if "type" in extra else ""
        kd = str(r[extra["contract / daily wager"]] or "").strip().lower() if "contract / daily wager" in extra else ""
        recs[code] = {"code": code, "name": clean_name(r[idx["name"]]) or code, "grade_raw": g, "grade": grade_label(g), "grade_rank": grade_rank(g),
                      "emp_type": "FTC" if (typ == "FTC" or is_outsourced(g)) else "FTE",
                      "kind": "dc" if kd.startswith("contract") or kd == "dc" else "dw" if kd.startswith("daily") else "",
                      "function": str(r[idx["function"]] or "Unassigned").strip() or "Unassigned", "manager_code": code_text(r[idx["manager"]]) or None,
                      "gender": str(r[idx["gender"]] or "").strip().lower()[:1] if "gender" in idx else "",
                      "position": strip_prefix(r[idx["position"]]) if "position" in idx else "",
                      "unit": " ".join(str(r[extra["unit"]] or "").split())[:200] if "unit" in extra else ""}
    for rec in recs.values():
        if rec["manager_code"] == rec["code"]:
            rec["manager_code"] = None
    if not recs:
        raise ValueError("No employee rows found in the first sheet.")
    return recs


def replace_from_file(db: Session, content: bytes, filename: str, by: str, dry_run: bool) -> dict:
    recs = read_hr_file(content)
    portal = {c for (c,) in db.query(models.Employee.code)}
    cur = {c for (c,) in db.query(models.AsIsEmp.code)}
    rep = {"rows": len(recs), "not_in_portal": len([c for c in recs if c not in portal]), "in_portal_not_in_file": len([c for c in portal if c not in recs]),
           "new_vs_current_as_is": len([c for c in recs if c not in cur]), "dropped_vs_current_as_is": len([c for c in cur if c not in recs])}
    if dry_run:
        return rep
    db.query(models.AsIsEmp).delete()
    for rec in recs.values():
        db.add(models.AsIsEmp(source="file", **rec))
    set_setting(db, META, {"source": "upload", "file": filename or "HR file", "at": "", "loaded_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
                           "by": by, "rows": len(recs), "edits": 0})
    db.commit()
    return rep


def bump_edits(db: Session):
    m = dict(meta(db))
    m["edits"] = int(m.get("edits") or 0) + 1
    set_setting(db, META, m)


# ------------------------------------------------------------------ the two organisations
def _asis(db) -> Dict[str, dict]:
    ensure(db)
    excluded = {c for (c,) in db.query(models.Employee.code).filter(models.Employee.exclude == True)}  # noqa: E712
    out = {}
    for a in db.query(models.AsIsEmp):
        if a.code in excluded:
            continue
        out[a.code] = {"code": a.code, "name": a.name, "grade": a.grade or "", "rank": a.grade_rank if a.grade_rank is not None else -1, "position": a.position or "",
                       "fn": a.function or "", "mgr": a.manager_code or "", "t": _tkey(a.emp_type, a.kind), "gender": (a.gender or "")[:1].lower(), "unit": a.unit or "",
                       "src": a.source or "file"}
    return out


def _tobe(db) -> (Dict[str, dict], Dict[str, dict]):
    """The To Be people, and the people out of it (resigned, headcount saved) with why. A headcount saved role stays
    on the chart as a cut box with its team under it (the team is not moved), but is not counted in the To Be."""
    fns = {f.id: f.name for f in db.query(models.Function)}
    emps = {e.code: e for e in db.query(models.Employee)}
    out_of = {c: ("saved" if e.hc_saved else "resigned") for c, e in emps.items() if e.resigned or e.hc_saved}
    keep = {}
    for c, e in emps.items():
        if e.exclude or (c in out_of and (e.resigned or not e.hc_saved)):
            continue
        m, n = e.manager_code or "", 0
        while m in out_of and emps[m].resigned and n < 40:   # reports of a resigned manager: to the next manager up
            m, n = (emps[m].manager_code or ""), n + 1
        keep[c] = {"code": c, "name": e.name, "grade": e.grade or "", "rank": e.grade_rank if e.grade_rank is not None else -1, "position": e.position or "",
                   "fn": fns.get(e.function_id, ""), "fid": e.function_id, "mgr": m, "t": _tkey(e.emp_type, _kind(e)), "gender": (e.gender or "")[:1].lower(),
                   "unit": e.unit_name or "", "added": e.source == "added", "saved": bool(e.hc_saved)}
    gone = {c: {"why": w, "name": emps[c].name, "reason": emps[c].hc_reason or "", "date": (emps[c].hc_date if w == "saved" else emps[c].resigned_on) or ""}
            for c, w in out_of.items()}
    return keep, gone


def _sides(db):
    """As Is and To Be on the same population. People added in the portal (missing from the HR file) are part of the
    As Is too, where they are now; resigned people and people no longer in the portal are left out of both, so only
    the restructuring itself shows as a change. Headcount saved roles stay in the As Is (they are what is saved)."""
    A = _asis(db)
    B, gone = _tobe(db)
    drop = {c for c, g in gone.items() if g["why"] == "resigned"} | {c for c in A if c not in B and c not in gone}
    for c in drop:
        if c in A:
            up = A[c]["mgr"]
            for k in A.values():
                if k["mgr"] == c:
                    k["mgr"] = up
            del A[c]
    for c, p in B.items():
        if c not in A:
            A[c] = dict(p)
    _settle_functions(db, A, B)
    return A, B, {c: g for c, g in gone.items() if g["why"] == "saved"}


def _settle_functions(db, A, B):
    """Only unit transitions move staff between functions: a head whose team moved with them to another function,
    ticked in Optimization (all of them until the admin ticks). Anyone else in another function in the Current
    State (a small adjustment) counts in their Proposed function in both states. fn0 keeps the HR file's function."""
    for p in A.values():
        p.setdefault("fn0", p["fn"])
    kb: Dict[str, List[str]] = {}
    for c, p in B.items():
        if p.get("mgr"):
            kb.setdefault(p["mgr"], []).append(c)
    pick = get_setting(db, "hr_unit_transitions")
    keep = set()
    for c, p in B.items():
        if c in A and A[c]["fn0"] != p["fn"] and kb.get(c) and not p.get("saved") and (pick is None or c in pick):
            st = [c]
            while st:
                x = st.pop()
                if x in keep:
                    continue
                keep.add(x)
                st.extend(kb.get(x, []))
    for c, p in A.items():
        if c in B and c not in keep and p["fn"] != B[c]["fn"]:
            p["fn"] = B[c]["fn"]


def _layers(db) -> Dict[str, int]:
    """Each person's layer as on the main dashboard (as the boss counts them): from their level in Structure &
    Benchmark (Function L2, Department L3, Unit L4, Team Lead L5, Teams L6, below Teams L7); people in functions
    without levels by how far down the reporting line they are. The top person is L1."""
    from .benchmark import level_layers
    lays = level_layers(db)
    root = get_setting(db, "root_code") or ""
    if root:
        lays[root] = 1
    return lays


def _shape(ps: Dict[str, dict], root: str, lays: Optional[Dict[str, int]] = None):
    """Direct reports, and the layer of each person for one side (lays: the level layers; the rest by depth)."""
    kids: Dict[str, List[str]] = {}
    for c, p in ps.items():
        if p["mgr"] and p["mgr"] in ps and c != root:
            kids.setdefault(p["mgr"], []).append(c)
    depth = {}
    if root in ps:
        depth[root] = 1
        stack = [root]
        while stack:
            x = stack.pop()
            for k in kids.get(x, []):
                if k not in depth:
                    depth[k] = depth[x] + 1
                    stack.append(k)
    if lays:
        depth = {c: (lays.get(c) or d) for c, d in depth.items()}
    return kids, depth


def single_report(kids, c, root="") -> bool:
    """A single-report manager, as in Opportunities: exactly one direct report, who in turn manages a team
    (an extra layer that adds an approval step without widening the span of control). The top person is not counted."""
    k = kids.get(c) or []
    return c != root and len(k) == 1 and bool(kids.get(k[0]))


def _metrics(ps, kids, depth, only=None, root="") -> dict:
    """Headline figures for a set of people (only: the codes to count; managers by their own function)."""
    codes = [c for c in ps if only is None or c in only]
    mgrs = [c for c in codes if kids.get(c)]
    spans = [len(kids[c]) for c in mgrs]
    lay = {}
    for c in codes:
        if c in depth:
            lay[depth[c]] = lay.get(depth[c], 0) + 1
    typ = {k: 0 for k in ("fte", "dc", "ftc", "dw")}
    gen = {"m": 0, "f": 0, "": 0}
    for c in codes:
        typ[ps[c]["t"]] = typ.get(ps[c]["t"], 0) + 1
        g = ps[c]["gender"]
        gen[g if g in ("m", "f") else ""] += 1
    bands = {b[0]: sum(1 for s in spans if b[1] <= s <= b[2]) for b in BANDS}
    grades: Dict[str, list] = {}
    for c in codes:
        g = ps[c]["grade"] or "Not set"
        r = grades.setdefault(g, [ps[c]["rank"] if ps[c]["rank"] is not None else -1, 0])
        r[1] += 1
    return {"headcount": len(codes), "managers": len(mgrs), "avg_span": round(sum(spans) / len(mgrs), 1) if mgrs else 0,
            "layers": max(lay) if lay else 0, "narrow": sum(1 for s in spans if s <= 2), "single": sum(1 for c in mgrs if single_report(kids, c, root)), "wide": sum(1 for s in spans if s > 15),
            "by_layer": {str(k): v for k, v in sorted(lay.items())}, "types": typ, "gender": gen, "bands": bands,
            "not_connected": sum(1 for c in codes if c not in depth),
            "grades": [{"g": g, "rank": r, "n": n} for g, (r, n) in sorted(grades.items(), key=lambda x: (-x[1][0], x[0]))]}


def compare(db: Session, fn: Optional[str] = None, scope: Optional[set] = None) -> dict:
    """fn: one function; scope: the functions this login may see (None: all)."""
    root = get_setting(db, "root_code") or ""
    A, B, gone = _sides(db)
    lays = _layers(db)
    ka, da = _shape(A, root, lays)
    kb, db_ = _shape(B, root, lays)
    fs = {fn} if fn else (set(scope) if scope is not None else None)
    isin = (lambda name: name in fs) if fs is not None else (lambda name: True)
    inf = lambda p: isin(p["fn"])
    onlyA = {c for c, p in A.items() if inf(p)}
    onlyB = {c for c, p in B.items() if inf(p) and not p.get("saved")}   # a headcount saved role is not counted in the To Be
    nm = lambda c: (B.get(c) or A.get(c) or {}).get("name", "") if c else ""

    def row(c, **x):
        p = B.get(c) or A.get(c)
        return {"code": c, "name": p["name"], "grade": p["grade"], "rank": p["rank"], "position": p["position"], "function": p["fn"], **x}

    both = [c for c in A if c in B and (c in onlyA or c in onlyB)]
    ch = {"line": [], "function": [], "grade": [], "title": [], "span": [], "layer": [], "saved": [], "resigned": [], "added": [], "removed": [], "tbh": [],
          "single": [], "fn_added": [], "fn_removed": [], "hiring_removed": []}
    for c in sorted(both, key=lambda c: (B[c]["fn"], B[c]["name"])):
        a, b = A[c], B[c]
        if (a["mgr"] or "") != (b["mgr"] or "") and c != root:
            ch["line"].append(row(c, frm=nm(a["mgr"]) or "—", to=nm(b["mgr"]) or "—", frm_code=a["mgr"], to_code=b["mgr"]))
        if a["fn"] != b["fn"]:
            ch["function"].append(row(c, frm=a["fn"] or "—", to=b["fn"] or "—"))
        if (a["grade"] or "") != (b["grade"] or "") and a["grade"] and b["grade"] and b["grade"] != "-":
            ch["grade"].append(row(c, frm=a["grade"], to=b["grade"], up=(b["rank"] or 0) > (a["rank"] or 0)))
        if (a["position"] or "").strip().lower() != (b["position"] or "").strip().lower() and b["position"]:
            ch["title"].append(row(c, frm=a["position"] or "—", to=b["position"]))
        na, nb = len(ka.get(c, [])), len(kb.get(c, []))
        if na != nb:
            ch["span"].append(row(c, frm=na, to=nb))
        sa_, sb_ = single_report(ka, c, root), single_report(kb, c, root) and not b.get("saved")
        if b.get("saved") and sa_:   # a single-report manager whose role is saved: fixed by the restructure
            ch["single"].append(row(c, frm=f"1 ({nm(ka[c][0])})", to="Role removed", fixed=True))
        elif sa_ or sb_:   # single-report managers (as in Opportunities), As Is and To Be
            only_a, only_b = (ka.get(c) or [""])[0] if na == 1 else "", (kb.get(c) or [""])[0] if nb == 1 else ""
            ch["single"].append(row(c, frm=f"{na} ({nm(only_a)})" if sa_ else na, to=f"{nb} ({nm(only_b)})" if sb_ else nb, fixed=not sb_))
        if c in da and c in db_ and da[c] != db_[c]:
            ch["layer"].append(row(c, frm=f"L{da[c]}", to=f"L{db_[c]}"))
    for c in sorted(onlyA, key=lambda c: A[c]["name"]):   # single-report managers whose role was removed
        if c not in B and single_report(ka, c, root):
            ch["single"].append(row(c, frm=f"1 ({nm(ka[c][0])})", to="Role removed" if c in gone else "Not in the To Be", fixed=True))
    for c, g in sorted(gone.items(), key=lambda x: x[1]["name"]):
        if c in A and c in onlyA:
            ch["saved" if g["why"] == "saved" else "resigned"].append(row(c, reason=g["reason"], date=g["date"], reports=len(ka.get(c, []))))
        elif c not in A and g["why"] == "saved":
            emp = db.get(models.Employee, c)
            if emp and isin(B.get(c, {}).get("fn")):
                ch["saved"].append({"code": c, "name": emp.name, "grade": emp.grade or "", "position": emp.position or "", "function": "", "reason": g["reason"], "date": g["date"], "reports": 0})
    portal = {c for (c,) in db.query(models.Employee.code)}
    for c in sorted(onlyB, key=lambda c: (B[c]["fn"], B[c]["name"])):
        if c not in A:
            ch["added"].append(row(c, to=nm(B[c]["mgr"]), why="Added in the portal" if B[c]["added"] else "In the HR data, not in the As Is"))
    for c in sorted(onlyA, key=lambda c: A[c]["name"]):
        if c not in portal:
            ch["removed"].append(row(c, frm=nm(A[c]["mgr"])))
    fnames = {f.id: f.name for f in db.query(models.Function)}
    for v in db.query(models.Vacancy):
        open_ = 0 if v.removed else (v.count or 1) - min(v.filled or 0, v.count or 1)
        if open_ > 0 and isin(fnames.get(v.function_id)):
            ch["tbh"].append({"code": "", "name": v.position or "Position", "grade": v.grade or "", "position": v.position or "", "function": fnames.get(v.function_id, ""),
                              "emp_type": v.emp_type, "count": open_, "to": nm(v.manager_code), "kind": vac_kind_label(v.kind),
                              "vk": v.kind or "new", "unit": v.unit or "", "note": v.note or ""})
    for v in db.query(models.Vacancy).filter(models.Vacancy.removed == True):  # noqa: E712   hiring asked to be removed
        if isin(fnames.get(v.function_id)):
            ch["hiring_removed"].append({"code": "", "name": v.position or "Position", "grade": v.grade or "", "position": v.position or "", "function": fnames.get(v.function_id, ""),
                                         "emp_type": v.emp_type, "count": (v.count or 1) - min(v.filled or 0, v.count or 1), "to": nm(v.manager_code),
                                         "kind": vac_kind_label(v.kind), "vk": v.kind or "new", "reason": v.removed_reason or "", "date": v.removed_on or ""})
    # headcount saved: employee roles marked saved, and vacant positions whose hiring was removed
    ch["saved_all"] = [dict(x, what="Employee role", n=1) for x in ch["saved"]] + \
        [{"code": "", "name": x["name"], "grade": x["grade"], "position": x["position"], "function": x["function"], "what": "Hiring removed · " + x["kind"],
          "reason": x["reason"], "date": x["date"], "reports": "", "n": x["count"] or 1} for x in ch["hiring_removed"]]
    fa = {}
    for c in onlyA:
        fa[A[c]["fn"]] = fa.get(A[c]["fn"], 0) + 1
    fb = {}
    for c in onlyB:
        fb[B[c]["fn"]] = fb.get(B[c]["fn"], 0) + 1
    for n in sorted(set(fb) - set(fa) - {""}):
        ch["fn_added"].append({"code": "", "name": n, "grade": "", "position": "", "function": n, "frm": 0, "to": fb[n]})
    for n in sorted(set(fa) - set(fb) - {""}):
        ch["fn_removed"].append({"code": "", "name": n, "grade": "", "position": "", "function": n, "frm": fa[n], "to": 0})
    tg = {}
    for x in ch["grade"]:   # taggings corrected: grade corrected (titles have their own card)
        t = tg.setdefault(x["code"], {**{k: x[k] for k in ("code", "name", "grade", "position", "function")}, "frm": [], "to": []})
        t["frm"].append(str(x["frm"])); t["to"].append(str(x["to"]))
    ch["tagging"] = [{**t, "frm": " · ".join(t["frm"]), "to": " · ".join(t["to"])} for t in tg.values()]
    ma, mb = _metrics(A, ka, da, onlyA, root), _metrics(B, kb, db_, onlyB, root)
    opt, repl = _optimisation(db, A, B, ka, kb, da, onlyA, onlyB, isin, row, nm)
    tbh_n = sum(x["count"] for x in ch["tbh"])
    # by function
    allnames = sorted({p["fn"] for p in A.values()} | {p["fn"] for p in B.values()} - {""})
    if scope is not None:
        allnames = [n for n in allnames if n in scope]
    names = [n for n in allnames if isin(n)]
    byfn = []
    cnt = lambda key, n: sum(1 for x in ch[key] if x["function"] == n)
    for n in names:
        sa = {c for c, p in A.items() if p["fn"] == n}
        sb = {c for c, p in B.items() if p["fn"] == n and not p.get("saved")}
        x, y = _metrics(A, ka, da, sa, root), _metrics(B, kb, db_, sb, root)
        if not (x["headcount"] or y["headcount"]):
            continue
        byfn.append({"function": n, "asis": {k: x[k] for k in ("headcount", "managers", "avg_span", "layers", "narrow")},
                     "tobe": {k: y[k] for k in ("headcount", "managers", "avg_span", "layers", "narrow")},
                     "saved": cnt("saved", n), "line": cnt("line", n), "moved": sum(1 for z in ch["function"] if z["to"] == n or z["frm"] == n),
                     "tbh": sum(z["count"] for z in ch["tbh"] if z["function"] == n)})
    cards = {"layers": {"asis": ma["layers"], "tobe": mb["layers"]}, "span": {"asis": ma["avg_span"], "tobe": mb["avg_span"], "narrow_asis": ma["narrow"], "narrow_tobe": mb["narrow"]},
             "functions": {"changed": len(ch["function"]), "added": len(ch["fn_added"]), "removed": len(ch["fn_removed"])},
             "single": {"asis": ma["single"], "tobe": mb["single"]}, "tagging": len(ch["line"]), "titles": len(ch["title"]), "saved": sum(x["n"] for x in ch["saved_all"]),
             "saved_roles": len(ch["saved"]), "saved_vac": sum(x["n"] for x in ch["saved_all"]) - len(ch["saved"])}
    return {"opt": opt, "repl": repl, "cards": cards, "units": [], "asis": ma, "tobe": mb, "tbh": tbh_n, "changes": ch, "counts": {k: (tbh_n if k == "tbh" else len(v)) for k, v in ch.items()},
            "by_function": byfn, "meta": meta(db), "functions": allnames,
            "fn": fn or ""}


def _optimisation(db, A, B, ka, kb, da, onlyA, onlyB, isin, row, nm):
    """Span of Control Optimization, and the replacement / new headcount positions."""
    emps = {e.code: e for e in db.query(models.Employee)}
    fnames = {f.id: f.name for f in db.query(models.Function)}
    vacs = [v for v in db.query(models.Vacancy) if isin(fnames.get(v.function_id))]
    open_ = lambda v: 0 if v.removed else (v.count or 1) - min(v.filled or 0, v.count or 1)
    by_staff = {v.replaces_code: v for v in vacs if v.replaces_code}
    # 1. delayering: L6 staff who had direct reports in the current state and have none in the proposed
    delayer = [row(c, frm=len(ka.get(c, [])), to=0) for c in sorted(onlyA, key=lambda c: A[c]["name"])
               if da.get(c) == 6 and ka.get(c) and c in B and not B[c].get("saved") and not kb.get(c)]
    # 2. unit transitions: a team that moved to another function with its head (the top of each moved block)
    pick = get_setting(db, "hr_unit_transitions")
    units = []
    for c in B:
        f0 = lambda x: A[x].get("fn0", A[x]["fn"])
        if c not in A or f0(c) == B[c]["fn"] or not kb.get(c) or B[c].get("saved"):
            continue
        p = B[c]["mgr"]
        if p in A and p in B and f0(p) != B[p]["fn"] and B[p]["fn"] == B[c]["fn"]:
            continue   # their manager moved with them: counted at the top of the block
        if not (isin(f0(c)) or isin(B[c]["fn"])):
            continue
        n, st = 0, list(kb.get(c, []))
        while st:
            x = st.pop()
            if not B[x].get("saved"):
                n += 1
            st.extend(kb.get(x, []))
        units.append(row(c, unit=B[c]["unit"] or A[c]["unit"] or B[c]["position"], frm=f0(c), to=B[c]["fn"], staff=n + 1,
                         selected=pick is None or c in pick))
    units.sort(key=lambda x: x["name"])
    # 4. staff exit candidates: headcount saved with no replacement; 7. post-retirement: contract (DC) staff surrendered and replaced
    exit_, pr = [], []
    for c, e in sorted(emps.items(), key=lambda x: x[1].name):
        if not e.hc_saved or e.resigned or c not in A or not isin(A[c]["fn"]):
            continue
        v = by_staff.get(c)
        if not v:
            exit_.append(row(c, reason=e.hc_reason or "", date=e.hc_date or "", t=_tkey(e.emp_type, _kind(e))))
        elif e.is_dc:
            pr.append(row(c, to=v.position or "", to_grade=v.grade or "", reason=e.hc_reason or ""))
    trade = [row(c) for c, e in sorted(emps.items(), key=lambda x: x[1].name) if e.trade_realign and not e.resigned and c in B and isin(B[c]["fn"])]
    # 3. geographic consolidation: units (a head and their team) marked to move to another region
    geo = []
    for c, e in sorted(emps.items(), key=lambda x: x[1].name):
        if not e.geo_to or e.resigned or c not in B or not isin(B[c]["fn"]):
            continue
        team, st = [c], list(kb.get(c, []))
        while st:
            x = st.pop()
            if not B[x].get("saved"):
                team.append(x)
            st.extend(kb.get(x, []))
        cur = {}
        for x in team:
            rg = (emps[x].region or "Not set") if x in emps else "Not set"
            cur[rg] = cur.get(rg, 0) + 1
        geo.append(row(c, unit=B[c]["unit"] or B[c]["position"], staff=len(team), frm=", ".join(f"{k} ({v})" for k, v in sorted(cur.items(), key=lambda x: -x[1])),
                       regions=sorted(cur), to=e.geo_to))
    # replacement positions (normal / special / post-retirement) and the new headcount
    def vrow(v, **x):
        return {"code": "", "name": v.position or "Position", "grade": v.grade or "", "position": v.position or "", "function": fnames.get(v.function_id, ""),
                "emp_type": v.emp_type or "FTE", "count": open_(v), "to": nm(v.manager_code) or "", "unit": v.unit or "", "note": v.note or "", **x}
    normal, special, post, new = [], [], [], []
    for v in sorted(vacs, key=lambda v: (fnames.get(v.function_id, ""), v.position or "")):
        if open_(v) <= 0:
            continue
        if v.kind != "replacement":
            new.append(vrow(v))
            continue
        e = emps.get(v.replaces_code) if v.replaces_code else None
        if not e:
            normal.append(vrow(v))
            continue
        r = vrow(v, staff=e.name, staff_code=e.code, staff_grade=e.grade or "", staff_position=e.position or "")
        r["pr"] = bool(e.is_dc)
        special.append(r)   # special replacements include the post-retirement (PR contract) ones
    from . import benchmark as bm_
    opt = {"max_layers": bm_.settings(db).get("max_layers", 5), "geo": geo, "geo_staff": sum(g["staff"] for g in geo),
           "geo_from": sorted({r for g in geo for r in g["regions"]}), "geo_to": sorted({g["to"] for g in geo}),
           "delayering": delayer, "units": units, "units_n": sum(1 for u in units if u["selected"]), "units_staff": sum(u["staff"] for u in units if u["selected"]),
           "exit": exit_, "pr": pr, "trade": trade}
    n = lambda rows: sum(r["count"] for r in rows)
    repl = {"normal": normal, "special": special, "post": post, "new": new, "n_normal": n(normal), "n_special": n(special), "n_post": n(post), "n_new": n(new)}
    return opt, repl


# ------------------------------------------------------------------ organogram data (the dashboard's /api/org layout)
def dept_units(db: Session, A: Dict[str, dict], B: Dict[str, dict], fs: Optional[set]) -> list:
    """Headcount and work volume by Department and Unit (the heads tagged in Structure & Benchmark), To Be against As Is.
    Everyone belongs to the nearest Department / Unit head above them (or is one)."""
    from . import benchmark as bm
    lv = {c: p.get("level") for c, p in bm.compute(db)["people"].items()}
    calc = None
    vol, acts = {}, {}
    try:
        from .logic import Calc
        calc = Calc(db)
        for w in db.query(models.WorkItem):
            d = calc.days.get(w.frequency or "Daily", 1.0) or 1.0
            vol[w.employee_code] = vol.get(w.employee_code, 0.0) + float(w.volume or 0) / d
            acts[w.employee_code] = acts.get(w.employee_code, 0) + 1
    except Exception:
        pass

    def heads(ps, c):
        dep = uni = None
        x, n = c, 0
        while x and x in ps and n < 60:
            l = lv.get(x)
            if l == "unit" and not uni and not dep:
                uni = x
            if l == "department" and not dep:
                dep = x
                break
            x, n = ps[x]["mgr"], n + 1
        return dep, uni

    rows = {}
    for side, ps in (("asis", A), ("tobe", B)):
        for c, p in ps.items():
            if (fs is not None and p["fn"] not in fs) or (side == "tobe" and p.get("saved")):
                continue
            dep, uni = heads(ps, c)
            if not dep and not uni:
                continue
            key = (dep or "", uni or "")
            r = rows.setdefault(key, {"dep": dep, "unit": uni, "asis": 0, "tobe": 0, "fte": 0, "ftc": 0, "managers": 0, "vol": 0.0, "acts": 0, "fn": p["fn"]})
            r[side] += 1
            if side == "tobe":
                r["fte" if p["t"] in ("fte", "dc") else "ftc"] += 1
                r["vol"] += vol.get(c, 0.0)
                r["acts"] += acts.get(c, 0)
    kidsB = {}
    for c, p in B.items():
        kidsB.setdefault(p["mgr"], []).append(c)
    for (dep, uni), r in rows.items():
        r["managers"] = 0
    who = lambda c: {"code": c, "name": (B.get(c) or A.get(c) or {}).get("name", ""), "position": (B.get(c) or A.get(c) or {}).get("position", "")} if c else None
    out = {}
    for (dep, uni), r in rows.items():
        d = out.setdefault(dep or "", {"head": who(dep), "function": r["fn"], "asis": 0, "tobe": 0, "fte": 0, "ftc": 0, "vol": 0.0, "acts": 0, "units": []})
        for k in ("asis", "tobe", "fte", "ftc", "vol", "acts"):
            d[k] += r[k]
        if uni:
            d["units"].append({"head": who(uni), "asis": r["asis"], "tobe": r["tobe"], "fte": r["fte"], "ftc": r["ftc"], "vol": round(r["vol"], 1), "acts": r["acts"]})
    res = []
    for k, d in out.items():
        d["vol"] = round(d["vol"], 1)
        d["units"].sort(key=lambda u: -u["tobe"])
        if not d["head"]:
            d["head"] = {"code": "", "name": "Units without a department", "position": ""}
        res.append(d)
    return sorted(res, key=lambda d: (d["function"], -d["tobe"]))


def org_payload(db: Session, side: str, scope: Optional[set] = None) -> dict:
    """scope: the functions this login may see (None: all). Their people are sent, with the managers above them
    as context (shown, not counted), as on the main dashboard for a login limited to some functions."""
    root = get_setting(db, "root_code") or ""
    A, B, gone = _sides(db)
    ps = A if side == "asis" else B
    other = B if side == "asis" else A
    kids, depth = _shape(ps, root, _layers(db))
    fn_rows = db.query(models.Function).order_by(models.Function.name).all()
    names = [f.name for f in fn_rows]
    ids = [f.id for f in fn_rows]
    types = [f.org_type or "" for f in fn_rows]
    for p in ps.values():   # As Is function names not (or no longer) in the portal
        if p["fn"] and p["fn"] not in names:
            names.append(p["fn"])
            ids.append(-1000 - len(names))
            types.append("")
    fidx = {n: i for i, n in enumerate(names)}
    nm = lambda c: (B.get(c) or A.get(c) or {}).get("name", "")
    marks = {}
    for c, p in ps.items():
        o = other.get(c)
        if side == "asis":
            if c in gone:
                marks[c] = {"c": "gone", "t": "Headcount saved" if gone[c]["why"] == "saved" else "Resigned"}
            elif not o:
                marks[c] = {"c": "gone", "t": "Not in the portal"}
            elif (o["mgr"] or "") != (p["mgr"] or "") and c != root:
                marks[c] = {"c": "mv", "t": "Moves to " + (nm(o["mgr"]) or "—")}
            elif o["fn"] != p["fn"]:
                marks[c] = {"c": "mv", "t": "Moves to " + o["fn"]}
        else:
            if p.get("saved"):
                marks[c] = {"c": "gone", "t": "Headcount saved"}
            elif not o:
                marks[c] = {"c": "new", "t": "Added" if p.get("added") else "Not in the As Is"}
            elif (o["mgr"] or "") != (p["mgr"] or "") and c != root:
                marks[c] = {"c": "mv", "t": "Was under " + (nm(o["mgr"]) or "—")}
            elif o["fn"] != p["fn"]:
                marks[c] = {"c": "mv", "t": "Was in " + (o["fn"] or "—")}
    rows = []
    notes = dict(db.query(models.Employee.code, models.Employee.org_note).filter(models.Employee.org_note.isnot(None)))
    emp_by = {e.code: e for e in db.query(models.Employee)}
    replaced = {c for (c,) in db.query(models.Vacancy.replaces_code).filter(models.Vacancy.replaces_code.isnot(None))}
    hide_top = not get_setting(db, "show_top_grade")   # the top person's grade is hidden on the charts, as on the dashboard
    for c, p in ps.items():
        t = p["t"]
        g = "-" if hide_top and c == root else p["grade"]
        ee = emp_by.get(c)
        rows.append([c, p["name"], g, fidx.get(p["fn"], -1), p["mgr"] if p["mgr"] in ps else "", p["position"], 1 if t in ("fte", "dc") else 0,
                     p["gender"], p["rank"], 0, 0, 1 if p.get("added") else 0, 0, (ee.region or "") if ee else "", (ee.service_role or "") if ee else "", 0, p["unit"], depth.get(c), 1 if t == "dc" else 0, 1 if t == "dw" else 0, notes.get(c, "") if side == "tobe" else "",
                     (2 if c in replaced else 1) if c in gone else 0])
    if scope is not None:
        by = {r[0]: r for r in rows}
        keep = {r[0]: 0 for r in rows if ps[r[0]]["fn"] in scope}
        for c in list(keep):
            x, n = by[c], 0
            while x[4] and x[4] in by and n < 60:
                x, n = by[x[4]], n + 1
                keep.setdefault(x[0], 1)
        rows = []
        for c, ctx in keep.items():
            r = list(by[c])
            if ctx:
                r[12] = 1
                r[20] = ""   # no notes on context people
            rows.append(r)
        marks = {c: v for c, v in marks.items() if keep.get(c) == 0}
    return {"functions": names, "function_ids": ids, "function_types": types,
            "fields": ["code", "name", "grade", "f", "manager", "position", "fte", "gender", "rank", "external", "exclude", "added", "context",
                       "region", "service_type", "resigned", "unit", "layer", "dc", "dw", "note", "saved"],
            "people": rows, "root_code": root, "group_label": get_setting(db, "group_label") or "COSO", "import": {}, "scoped": scope is not None, "unit_scoped": False, "saved_uncounted": side == "tobe",
            "marks": marks}


def asis_export(db: Session) -> bytes:
    """The As Is in the HR master file layout, to correct in Excel and upload again."""
    from openpyxl import Workbook
    ensure(db)
    wb = Workbook()
    ws = wb.active
    ws.title = "As Is"
    ws.append(["N Employee No", "N Employee Name", "N Employee Grade", "N Function", "N-1 Manager Number", "N Position Name", "N Gender", "Unit", "Type", "Contract / Daily Wager", "Source", "Note"])
    for a in db.query(models.AsIsEmp).order_by(models.AsIsEmp.function, models.AsIsEmp.name):
        ws.append([a.code, a.name, a.grade_raw or a.grade, a.function, a.manager_code or "", a.position, {"m": "Male", "f": "Female"}.get((a.gender or "")[:1], ""),
                   a.unit, a.emp_type, {"dc": "Contract", "dw": "Daily Wager"}.get(a.kind or "", ""), a.source, a.note])
    for col, w in zip("ABCDEFGHIJKL", (14, 30, 16, 32, 16, 34, 9, 24, 7, 18, 9, 30)):
        ws.column_dimensions[col].width = w
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()

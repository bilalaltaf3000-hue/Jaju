// Builds the organisation model from /api/org. Everything (layers, spans, teams) is computed
// from employee code + N-1 manager code only.
export const PAL = ['#00796B','#3F6F7C','#A88D57','#5E8F87','#6A7D96','#8F6F5E','#0E5A50','#7E9C6A','#4F8A9A','#5F8A66','#8C7A9B','#2F4F6B','#9DB3AE','#B59C6B','#2E8B7E','#6B7B4F','#9A7B66','#4A6178']   // muted: teal, slate, bronze, sage
// the three employee types: FTE, DC (retired, rehired on contract; the admin can rename it) and FTC
export const fmt = n => Number(n) ? Number(n).toLocaleString('en-US') : '-'   // a dash for zero, everywhere
// a volume or other measure: at most two decimals (32.3333 shows as 32.33)
// volumes in short form: 950, 1.5K, 150K, 1M, 12.5M (exact figures in the tooltips); below 1,000 up to `dec` decimals
export const vfmt = (n, dec = 0) => {
  const v = Number(n) || 0
  if (!v) return '-'
  const a = Math.abs(v)
  const u = a >= 1e9 ? ['B', 1e9] : a >= 1e6 ? ['M', 1e6] : a >= 1e3 ? ['K', 1e3] : null
  if (!u) return a < 1 ? v.toLocaleString('en-US', { maximumFractionDigits: Math.max(dec, 1) }) : Math.round(v).toLocaleString('en-US')
  const x = v / u[1]
  return (Math.abs(x) >= 100 ? Math.round(x) : Math.round(x * 10) / 10) + u[0]
}
export const num2 = v => v === null || v === undefined || v === '' ? '' : Number(v).toLocaleString('en-US', { maximumFractionDigits: 2 })
export const short = (s, n = 26) => (s || '').length > n ? s.slice(0, n - 1) + '…' : (s || '')

// spanType 'FTE' / 'FTC': spans and teams count only that type of direct report (every manager stays)
export function buildOrg(data, includeFlagged, senior = 68, spanType = '') {
  const F = data.functions
  const P = data.people.map((a, i) => ({ i, id: a[0], n: a[1] || a[0], g: a[2], f: a[3], mc: a[4], pos: a[5], fte: a[6] === 1, sex: a[7], rk: a[8], ext: a[9] === 1, exc: a[10] === 1, added: a[11] === 1, ctx: a[12] === 1, rg: a[13] || '', st: a[14] || '', rs: a[15] === 1, lay: a[17] || null, dc: a[18] === 1, dw: a[19] === 1, note: a[20] || '', hs: a[21] >= 1, rp: a[21] === 2, kids: [] }))
  const byId = new Map(P.map(p => [p.id, p]))
  const ROOT = byId.get(data.root_code) || P[0]
  P.forEach(p => { p.m = -1; if (p !== ROOT && p.mc && byId.has(p.mc)) { p.m = byId.get(p.mc).i; P[p.m].kids.push(p) } })
  const hsOut = !!data.saved_uncounted   // HR Dashboard To Be: headcount saved roles are shown (cut) but not counted
  const counted = p => !p.ctx && !p.rs && !(hsOut && p.hs) && (includeFlagged || !p.exc)
  const cT = spanType ? (p => counted(p) && (spanType === 'FTE' ? p.fte : !p.fte)) : counted
  // depth
  ROOT.d = 0; const q = [ROOT]
  for (let h = 0; h < q.length; h++) q[h].kids.forEach(k => { k.d = q[h].d + 1; q.push(k) })
  const orphans = P.filter(p => p.d === undefined)
  orphans.forEach(p => { p.d = -1 })
  // the layer shown everywhere: by level in a function tagged for the grade benchmark (a Department head is Layer 3),
  // otherwise by the reporting depth (the top person is Layer 1); ld is the same, counted from 0
  P.forEach(p => { p.ly = p.lay || (p.d >= 0 ? p.d + 1 : -1); p.ld = p.ly - 1 })
  const scoped = !!data.scoped
  // team sizes (post-order over BFS order)
  for (let j = q.length - 1; j >= 0; j--) {
    const x = q[j]
    x.nk = x.kids.filter(cT).length
    x.team = x.kids.reduce((s, k) => s + (cT(k) ? 1 : 0) + k.team, 0)
    x.depthBelow = x.kids.length ? 1 + Math.max(...x.kids.map(k => k.depthBelow)) : 0
  }
  orphans.forEach(p => { p.nk = p.kids.length; p.team = p.team || 0; p.depthBelow = p.depthBelow || 0 })
  P.forEach(p => p.kids.sort((a, b) => b.rk - a.rk || b.team - a.team || a.n.localeCompare(b.n)))
  const C = P.filter(counted)
  const MGR = C.filter(p => p.nk > 0)
  const total = C.length, fteN = C.filter(p => p.fte).length, ftcN = total - fteN
  const maxL = Math.max(0, ...C.map(p => p.d))
  const narrow = MGR.filter(p => p.nk <= 2 && p !== ROOT)
  const wide = MGR.filter(p => p.nk > 15)
  const cross = C.filter(p => p.m >= 0 && P[p.m] !== ROOT && P[p.m].f !== p.f)
  const biggest = MGR.length ? MGR.reduce((a, b) => b.nk > a.nk ? b : a) : ROOT
  const seniorNoTeam = C.filter(p => p.rk >= senior && !p.nk)
  const fstats = F.map((name, f) => {
    const ps = C.filter(p => p.f === f); const ms = ps.filter(p => p.nk)
    return { f, name, hc: ps.length, fte: ps.filter(p => p.fte).length, ftc: ps.filter(p => !p.fte).length, mg: ms.length,
      span: ms.length ? ms.reduce((s, m) => s + m.nk, 0) / ms.length : 0, layers: ps.length ? Math.max(...ps.map(p => p.ly)) : 0,   // the deepest layer (the top person is Layer 1)
      narrow: ms.filter(m => m.nk <= 2 && m !== ROOT).length,
      head: ROOT.f === f && !ROOT.ctx ? ROOT : ROOT.kids.filter(k => k.f === f).sort((a, b) => b.team - a.team || (b.rk ?? -9) - (a.rk ?? -9))[0] || ps.sort((a, b) => a.d - b.d)[0] }
  }).filter(s => s.hc > 0).sort((a, b) => b.hc - a.hc)
  const FCOL = []; F.forEach((_, f) => { FCOL[f] = PAL[f % PAL.length] })
  F.forEach((_, f) => { if (!FCOL[f]) FCOL[f] = '#7D9490' })
  const avgSpan = MGR.filter(m => m !== ROOT).length ? MGR.filter(m => m !== ROOT).reduce((s, m) => s + m.nk, 0) / MGR.filter(m => m !== ROOT).length : 0
  // the top person and each function's head (the direct report of the top who leads the largest team)
  const headIds = new Set([ROOT.i, ...fstats.map(s => s.head ? s.head.i : null).filter(i => i !== null)])
  const groupLabel = data.group_label || 'COSO'
  const FT = data.function_types || []   // Division / Department / Unit (grade benchmark tagging), blank when not tagged
  return { FT, groupLabel, selection: data.selection || null, scoped, F, fids: data.function_ids, P, byId, ROOT, C, MGR, total, fteN, ftcN, maxL, narrow, wide, cross, biggest, seniorNoTeam, fstats, FCOL, avgSpan, orphans, senior, counted, headIds, includeFlagged, excluded: P.filter(p => !p.ctx && !p.rs && p.exc), resigned: P.filter(p => !p.ctx && p.rs), imp: data.import || {}, empType: data.empType || '', spanType }
}

// Limit the organisation to the selected functions (function ids). People in those functions are counted;
// managers above them are kept as context so the chart stays connected to the top. Empty = everything.
export function scopeData(data, ids) {
  if (!data || !ids || !ids.length) return data
  const want = new Set(ids.map(id => data.function_ids.indexOf(id)).filter(i => i >= 0))
  const rows = data.people
  const by = new Map(rows.map(r => [r[0], r]))
  const keep = new Map()
  rows.forEach(r => { if (want.has(r[3]) && r[12] !== 1) keep.set(r[0], 0) })
  for (const code of [...keep.keys()]) {
    let x = by.get(code), n = 0
    while (x && x[4] && by.has(x[4]) && n++ < 60) { x = by.get(x[4]); if (!keep.has(x[0])) keep.set(x[0], 1); if (x[0] === data.root_code) break }
  }
  if (by.has(data.root_code) && !keep.has(data.root_code)) keep.set(data.root_code, 1)
  const people = [...keep.entries()].map(([code, ctx]) => { const r = by.get(code).slice(); if (ctx) r[12] = 1; return r })
  return { ...data, people, scoped: true, selection: ids }
}

// Limit the organisation to some units (unit names). People in those units are counted; their managers
// upwards stay as context (shown, not counted), so a function head is context, not part of a unit.
export function unitData(data, units) {
  if (!data || !units || !units.length) return data
  const want = new Set(units)
  const by = new Map(data.people.map(r => [r[0], r]))
  const keep = new Map()
  data.people.forEach(r => { if (r[12] !== 1 && want.has(r[16] || '')) keep.set(r[0], 0) })
  for (const code of [...keep.keys()]) {
    let x = by.get(code), n = 0
    while (x && x[4] && by.has(x[4]) && n++ < 60) { x = by.get(x[4]); if (!keep.has(x[0])) keep.set(x[0], 1); if (x[0] === data.root_code) break }
  }
  if (by.has(data.root_code) && !keep.has(data.root_code)) keep.set(data.root_code, 1)
  const people = [...keep.entries()].map(([code, ctx]) => { const r = by.get(code).slice(); if (ctx) r[12] = 1; return r })
  return { ...data, people, scoped: true, units: [...want] }
}
// the units in the organisation data (counted people only), optionally within some functions (function ids)
export function unitsIn(data, fids) {
  if (!data) return []
  const want = fids && fids.length ? new Set(fids.map(id => data.function_ids.indexOf(id))) : null
  const s = new Set()
  data.people.forEach(r => { if (r[12] !== 1 && r[16] && (!want || want.has(r[3]))) s.add(r[16]) })
  return [...s].sort((a, b) => a.localeCompare(b))
}

// Limit the organisation to FTE or FTC staff. Their managers of the other type stay as context
// (shown, not counted) so every reporting line still reaches the top.
export function typeData(data, et) {
  if (!data || !et) return data
  const want = r => r[12] !== 1 && (et === 'FTE' ? r[6] === 1 : r[6] !== 1)
  const by = new Map(data.people.map(r => [r[0], r]))
  const keep = new Map()
  data.people.forEach(r => { if (want(r)) keep.set(r[0], 0) })
  for (const code of [...keep.keys()]) {
    let x = by.get(code), n = 0
    while (x && x[4] && by.has(x[4]) && n++ < 60) { x = by.get(x[4]); if (!keep.has(x[0])) keep.set(x[0], 1); if (x[0] === data.root_code) break }
  }
  if (by.has(data.root_code) && !keep.has(data.root_code)) keep.set(data.root_code, 1)
  const people = data.people.filter(r => keep.has(r[0])).map(r => { if (!keep.get(r[0])) return r; const c = r.slice(); c[12] = 1; return c })
  return { ...data, people, empType: et }
}

// Most senior grade first; outsourced and unverified grades last
export const gradeSort = (a, b) => (b.rk ?? -9) - (a.rk ?? -9) || String(a.g).localeCompare(String(b.g))
export const pct = (n, d) => d ? Math.round(n / d * 100) : 0
export const pcs = (n, d) => pct(n, d) ? pct(n, d) + '%' : '-'   // a percentage, or a dash for zero
export const hrs = n => Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })
export const TYPE_COL = { Service: 'var(--svc)', Support: 'var(--sup)', Both: 'var(--both)', '': 'var(--none)' }
export const typeLabel = t => t || 'Not yet recorded'

# Version 2: what changed and how to update

## New in 2.11

To update the VM, follow **deploy/UPDATE_TO_2.11_VM.md**. It backs up first, replaces the code only and keeps the database.

- **Nature of Work** replaces "Processing mode / Activity handling":
  - The options are renamed Manual → **Core Physical**, File Based → **System Based**, System Based → **Straight Through Processing (STP)**. Existing activities are converted once on the first start.
  - **Admin → Lists → Nature of Work**: rename the heading, and add, rename or remove options. Removing an option that is in use asks which option its activities move to.
  - Templates downloaded before a rename still import correctly, including the old "Activity handling" templates.
- **Dashboard title** names the login's functions (up to four, otherwise "N Functions") and units, instead of "All my functions". The function drop-down shows one function at a time.
- **Resigned employees:**
  - When someone is marked resigned (Admin → Employees, or a data transfer or master import), their direct reports move permanently to the resigned person's line manager.
  - **Admin → Settings → Hide resigned employees everywhere** is on by default. They are left out of the dashboards, organogram, insights, lists and exports, but stay visible in Admin → Employees.
- **Admin → Activity Categories (new):**
  - Every category written, with activities, employees, functions and units.
  - Filters: function, unit, region, FTE / FTC, service / support and search.
  - **Possible Duplicates** suggests near-identical spellings.
  - Tick categories and **Merge** (or **Rename**) them into one standard name. The merge applies to the current filter and adds the name to the standard list. **Undo Last Merge** reverses it.
  - **View** shows sample activities.
- **Activity Themes:** create themes in Admin → Activity Categories and put categories under them. Activity Insights shows an **Activity Themes** chart, and each theme opens its activities. The Excel export has an "Activity themes" sheet and a theme column on activities and categories. Themes are **hidden until the admin turns them on**: tick *Show on Activity Insights* in Admin → Activity Categories, or use Admin → Settings → Activity Themes. While they are off, nothing about themes is shown on Activity Insights or in the export.
- **Unit logins and the unit filter:**
  - A dashboard login can be limited to units of a function: Admin → Users → Edit access, tick the units. It sees and exports only those units. The function head appears for context and is not counted.
  - A **unit filter** appears at the top once one or more functions are picked and those functions have units. It is not shown for COSO (all functions). A login that sees only one function gets it straight away.
- **Activity Insights layout:**
  - When themes are on, **Activity Themes comes first**, then Activity Category. Clicking a theme lists its categories, each with employees and activities, and each category opens its detailed activities.
  - **Admin → Settings** (or the Activity Categories page) has two switches: *Show activity themes* (off by default) and *Show the Activity Category panel* (on by default).
  - The second volume chart is by **Activity Theme** when themes are shown, otherwise by Activity Category.
  - Volume figures are labelled **Avg** (Avg Daily Volume).
  - "Activities Recorded" is now **Activities**.
  - The explanatory notes ("Based on N activities with volume…", "Not recorded for N% of activities") are removed.
- **Activities split by volume:** Activity Insights has two boxes, **Volume Based Activities** and **Non Volume Based Activities**. Each opens its activities, with a *Volume Based / Non Volume Based / All* choice at the top.
- **Search activities:** the activities window has a search box (employee, code, description, process, product, channel, category or theme; every word typed must match). It searches within the theme or category that is open.
- **Theme or category, everywhere categories are listed:** the Activities box, View All Categories, and the employee popups (Activity Insights ranking) all open the same browser. With **By Theme** ticked it goes theme → its categories → detailed activities; unticked it goes category → detailed activities. A path at the top (All Themes › theme › category) goes back a step. The tick appears when themes are switched on.
- **Employee Activities:** the employee popup has an **All themes** filter next to the categories (choosing a theme narrows the categories), and each activity shows its theme above its category. Activity lists elsewhere also show the theme above the category.
- **Fix (Excel review upload):** when an employee had several activities with the same product, process, channel, frequency and volume, a sorted file could put one row's changes on a look-alike activity. Rows are now paired with the activity whose original description and category match, and position only breaks ties. **deploy/restore_from_backup.py** puts back descriptions (or other fields) of one function from a backup database, by activity ID.
- **Admin → Activity Categories → Review in Excel (new):** *Download Activities* gives one row per activity with its Activity ID, employee, product, process, channel, and the three columns to edit in green: **Activity description**, **Activity category** and **Activity theme** (a Themes sheet lists the themes). Edit them in Excel and click *Upload Changes*: a preview shows how many descriptions, categories and themes change, new themes, categories given more than one theme (the one used most wins) and rows that no longer match. Nothing changes until *Apply Changes*; *Undo Last Upload* puts everything back. Blank cells leave the portal's value as it is. The **Excel export** works too: its Employee activities sheet now carries an Activity ID, and an older export without it (including one made with version 2.10) is matched by employee and the activity's details (product, process, channel, frequency, volume, time), so sorting or filtering the rows in Excel is fine; rows that match nothing are left out and listed. The preview also checks completeness: how many of the portal's activities the file covers, activities not in the file, and activities that would still have no theme. **Revised columns (recommended)**: leave the exported columns as they are and add columns headed **Revised description**, **Revised category**, **Revised frequency**, **Revised volume**, **Revised nature** (Nature of Work) and **Theme**; a value in a revised column replaces the portal's, a blank leaves it. The original columns are then used only to find each activity, so every row matches. Frequencies and Nature of Work must be one of the portal's options (old names such as Manual are understood); anything else, and volumes that are not numbers, are listed in the preview and left as they are. **Merging activities in Excel**: delete the extra rows and edit the remaining one (description, category, volume); a changed volume is applied, and the row is still found by its product, process, channel and frequency. Activities whose rows were deleted stay in the portal unless the admin ticks *Also remove these activities* in the preview (only for employees in the file; Undo Last Upload brings them back). A theme column can be added by hand (headed *Theme* or *Activity theme*).
- **Dashboard → Activities (new section, before Opportunities):** an executive view of the activity themes (up to 20): one row per theme with its **employees**, **activities** and **average daily volume** (with its share of the total) as bars, and an Avg Daily Volume box on top. Click a column heading to rank by it. A filter switches between *All Activities*, *Volume Based Activities* and *Non Volume Based Activities* (the split bar on top does the same). Clicking a theme opens its categories, then the detailed activities. Until themes are switched on, the chart shows the 20 largest activity categories.
- **Volumes with two decimals at most:** an average volume such as 32.3333222 shows as 32.33 in activity lists, employee popups, data capture and the Excel export.
- **Every activity drill-down uses themes:** clicking a function bar, the Nature of Work ring, Frequency of Work, Automation, a volume bar or a unit opens the same theme → category → activities browser, with search. Only a click on one category goes straight to its activities.
- **Employee PDF:** each activity shows its theme above its category while themes are on.
- **Theme colours** are the same on every page (each theme keeps its colour from its place in the admin's theme list).
- **Dashboard:** "Share of Employees" is removed from the FTE and FTC boxes.
- **Themes instead of categories on the dashboard pages:** with *Show Themes* on and *Show Categories* off (Admin → Settings), the dashboard pages show only themes: no Activity Category panel or box, activity lists show the theme instead of the category, the Employee Activities popup has a theme filter (no category filter) and counts themes, and the activities window has no By Theme tick. Data capture, the templates and the exports keep the category; the admin sets each category's theme in Admin → Activity Categories. The theme lists show the 10 largest themes (View All for the rest), and a theme opens its activities directly.
- **Admin → Labels (new):** rename the page titles, sidebar items, boxes and chart headings of the Dashboard, Activity Insights and Geographical Spread without a code change. A blank box, or Reset, goes back to the standard text.
- **Daily Volume** in Activity Insights: the volume per working day by function (or by unit when one function is selected) and by category, from the activities that have a volume. Start and end of month peaks are not counted.
- **Share Feedback → Employee Change:**
  - POCs can ask to **re-tag** (new manager, function or unit), **remove** or **add** an employee, picking from their own function and units only.
  - The admin applies or rejects it in **Admin → Feedback**, where reporting-line requests from Data Capture also appear on top.
- **Clean-up:**
  - Activity Insights no longer shows "per employee" averages or "with activities recorded".
  - The sidebar's small "Insights" label is gone, and Geographical Spread follows Employee Activities.
  - Service or Support no longer shows "Not yet marked"; the two shares make 100%.
  - Employees by Region shows the top 10 with **View All Regions**.

## New in 2.10

- **Service or support is set with the activities.** It moved from step 1 to step 2: at the top of each employee in Activities, choose **Service** or **Support** next to their name. Step 1 is back to units and regions only. In step 2, the employee list can be filtered to **Service / support not set**. When activities are copied to a colleague who is not yet marked, the colleague gets the same type.
- **Hidden fields are hidden everywhere.** Fields set to Hidden in Admin → Data capture fields are now also left out of the activity lists on the dashboard (category drill-downs, automation and processing-mode lists, the employee popup) and of the Employee activities page. With several functions selected (or COSO), a field is left out when it is hidden in every function that has activities, even if some activities still hold older values in it.
- **Remove activities in one step.** Activities has a **Remove activities** button: tick one employee, several, or Tick all shown (with search and an FTE / FTC filter), then confirm. Units, regions and service or support are kept.
- **Opportunities:** selecting an employee in a finding's list opens their reporting line popup (the employee highlighted, their managers above and their direct reports below) instead of leaving the dashboard.
- **Employee activities:** selecting an employee opens their activities in a popup, with their type, service or support, unit, region and manager on top; filters by category, frequency, processing mode and automation (the ones not hidden), a search box, and **Previous / Next** (or the arrow keys) to move through the list without closing it. Esc closes only the top popup.
- **Units are optional everywhere.** A blank unit is no longer shown as "Not set". In Employee activities, the Unit column and filter appear only when the function uses units, and the popup shows the unit only when there is one. Data capture no longer needs a unit to mark a function Complete; the review only mentions missing units once some employees in the function have one.
- **Geographical spread has its own page** (sidebar, under Insights), and is no longer a section of the dashboard (Opportunities is now section 6; the dashboard's section bar links to the new page). It follows the function filter and adds All staff / FTE / FTC and All work / Service / Support filters. It shows key figures (employees, regions, largest region, share of the top three, FTC share or employees without a region), headcount by region (FTE and FTC), each region's share of the workforce, a card per region (FTE / FTC and service / support mix, and its three largest functions) and a functions-by-region table. Every figure opens the employees by grade.
- **Activity insights has its own page** (sidebar, under Insights), moved out of the dashboard. It has All staff / FTE / FTC and All work / Service / Support filters, a headline band (employees covered, activities, categories, manual processing, automation candidates), the main activity categories, processing mode, the automation opportunity, the frequency of work, coverage by function, and the employees with the most activities. Every figure opens the activities behind it.
- **Dashboard redesign:** a headline band on top (total workforce, FTE, FTC, managers with the average span, layers, service and support), with links to Activity insights and Geographical spread; a section bar that stays at the top while you scroll; and a new **Workforce by grade** chart, with outsourced staff shown apart so they do not dwarf the graded structure. Sections: 1 Organogram, 2 Workforce by grade, 3 Layers and spans, 4 Service and support, 5 Opportunities.
- **Geographical spread:** a region where no one is marked service or support yet says so, instead of showing 0 / 0, and partly marked regions show how many are not yet marked.
- **Grades:** shown without their code ("070 VP" shows as "VP"). Outsourced staff ("Outsourced Staff", "000-Outsourced" and so on) show as grade **FTC** and are counted as FTC. Grade "000" shows as **External** and the person is flagged external. Existing employees are corrected on the next start and after every master sheet import; changes made by hand in Admin, Employees are kept. FTE and FTC are no longer spelled out as "permanent" and "contract".
- **Workforce by grade removed** from the dashboard; the figures in the headline band open the same breakdown. Sections: 1 Organogram, 2 Layers and spans, 3 Service and support, 4 Opportunities.
- **Employee popups** (from any figure): the heading follows the tab (for example "FTE by grade", "FTE by function", "FTE: employees"). Every number in the grade, function and region tables opens the employees it counts, and selecting an employee opens their reporting line chart with them highlighted. In the employee list, the top person and the function heads come first, most senior grade first, then everyone else by grade (no tag is shown).
- **Function head:** the employee lists that open from a figure no longer tag anyone as "Function head". Where the portal still identifies the head (data capture and Employee activities), it is the most senior person of the function reporting to the top who leads a team, so a secretary or adviser reporting to the top is no longer taken for the head.
- **Dashboard headline:** service and support are shown as two labelled figures, one under the other.
- **Set for several employees at once** (Data capture, step 1, Everyone): unit, region, service or support, and FTE / FTC. For each, choose the value and who it applies to: the employees ticked, everyone shown by the filters (for example all FTC staff), everyone not yet set, or the whole function. Applying to everyone shown or the whole function asks to confirm first. A type changed here is kept when the master sheet is imported again. The list also has a Service / support column and a "Not marked service / support" filter.
- **Presentation-ready pages:** explanatory sentences and hints are removed from the Dashboard, Organogram explorer, Activity insights, Geographical spread and Employee activities (headings, figures and short labels only). Opportunity cards show the finding, the count and the next step.
- **Consistent capitalisation:** employee names are shown in title case ("BILAL ALTAF", "KAmrAN" become "Bilal Altaf", "Kamran"); positions and units written all in capitals or all in lower case are put in title case; activity text (category, description, process, product, channel) written all in capitals or all in lower case is put in sentence case, with banking acronyms such as KYC, LC, MIS and SWIFT kept in capitals. Text that already mixes capitals is left as written. Existing data is corrected on the next start, and new entries and imports as they are saved.
- **Activity insights** no longer shows coverage (employees or functions without activities): the coverage-by-function panel is removed, the headline shows the number of employees with activities, and category shares are of those employees. The exports follow.
- **Activity category and product suggestions** now include every category and product already written in any function (categories also include the admin's list), one spelling each. A POC in one function typing "MIS" is offered "MIS and Reporting" written by another function.
- **Function filter is a drop-down:** "Function: COSO ▾" at the top of every insight page. Open it to search, tick one or several functions, or choose COSO for the whole group; the names of the selected functions show beside it, with "Show COSO" to go back.
- **Grade of the top of the organisation hidden:** shown as "-" on every page and export. To show it again: **Admin → Settings → Grade of the top of the organisation**.
- **Wording and clean-up:** "workforce" is now "employees" throughout (pages and exports); the "HBL · Operations Services workforce" line is removed from the headline bands; "below …" is removed under Layers; Headcount by layer is removed (the span of control chart takes the full width); Geographical spread shows Employees, Regions and FTC share only (Largest region and Top three regions removed).
- **Overwrite or append when copying.** When you copy activities to colleagues who already have activities (or copy into an employee who already has some), you are asked first: **Overwrite all** removes their current activities and gives them the copied ones; **Append** adds the copied activities, without duplicating ones they already share.

### Review round (President & CEO presentation)

- **Dashboard opens clean:** the headline band, then four cards: **Organogram**, **Layers and Spans**, **Service or Support** and **Opportunities**. A section appears only when its card is clicked (click again to close). Sections are marked with bullets, not numbers.
- **Headline band:** titled "Operations Services" (COSO removed); Total employees without a %; Layers now come before Managers; **Service or Support** shows the count and % of each. The Activity insights and Geographical spread buttons are removed (both are in the sidebar). The function filter no longer says "Function" when COSO is selected, as COSO is not a function.
- **Organogram on the dashboard:** titled "Organogram" only, with no side panel, so the chart gets the full width. Click a function head: the chart shows the top person, that head and the head's direct reports, everything else hidden, and fits itself to the window. Click a direct report to go one layer further down; click the highlighted person to step back up. The Top of organisation, Expand one more level and Collapse buttons are removed.
- **Layers and Spans:** "Function-Wise Layer"; the Total row is on top; with FTE / FTC selected the headings read "FTE's Managers" / "FTC's Managers"; gaps inside a function's layers show "-". The Span of Control chart shows the number of managers above each bar.
- **Service or Support** (was Service and support): By Function has its total on top.
- **Structure Opportunities and Gaps:** new All staff / FTE / FTC filter. With FTE or FTC selected, spans and findings count only that type of direct report, so you can see whether a wide span comes from FTC staff.
- **Activity Insights:** the "Processing mode" heading is removed from the chart. Two new charts by function: **Activities by Function** (split into manual, file based and system based) and **Service or Support Work by Function**. Click a bar to open those activities.
- **Dashes instead of zeros** throughout the portal (tables, percentages, figures).
- **Title case** for headings, card titles, column headings and the sidebar.
- The "Employee and process intelligence" subtitle is removed from the sidebar.
- **Employee activities PDF:** **Export PDF** on the Employee Activities page exports the employees listed (the filters apply), with a cover page and a table of contents (also as PDF bookmarks), then one section per employee. **Export PDF** in an employee's popup exports that employee alone. Each section shows the employee's details, their organogram (the line from the top, the employee highlighted and their direct reports), then their activities. Hidden fields and the hidden top grade are respected.
- **Dashboard organogram:** after clicking a function head, **Expand one more level** and **Collapse** appear, so the head's whole structure opens without clicking each person. The chart zooms out further to keep an expanded team in view.
- **Opportunities:** "Single-report managers" no longer says "pass-through layers".
- **Layers and Spans:** the Average Span of Control strip is removed. The Function-Wise Layer table and the Span of Control chart each have their own All staff / FTE / FTC filter.
- **FTE / FTC by grade:** the top of the organisation shows as **COSO** in the grade list (instead of "-"). Everywhere else the hidden grade stays "-".
- **Activity Insights:** the Service or Support Work by Function chart is removed (service and support are on the main dashboard).
- **Employee Activities:** the function drop-down has **All functions**, with a Function column. The page-level Export PDF is offered for one function at a time; an employee's own Export PDF works in either view.
- **PDF export is faster** (about three times for large exports).
- **"Employees" everywhere:** "Headcount", "staff", "people" and "workforce" are replaced by "employees" on every page and in every export (for example the Employees column, "All employees" filters, Employees by Region, Service / Support Employees). The Excel template's **Staff** sheet is now **Employees**, and "Staff processing time" is now "Employee processing time"; templates downloaded earlier still upload as before.
- **Dashboard organogram:** no FTE / FTC filter; clicking the top person always returns to the plain view.
- **HBL logo** replaces the green HBL box in the sidebar and on the sign-in page. The sidebar is dark in both themes, so it always shows the white logo; the sign-in card shows the green logo in the light theme and the white logo in the dark theme. To change a logo, replace frontend/public/logo-light.png (green, for light backgrounds) or logo-dark.png (white, for dark backgrounds), or the same files in backend/static.
- **Organogram:** the Organogram Explorer page is removed (the dashboard organogram and the reporting-line popup remain), as are Open Full Organogram, Fit to Screen (the chart fits itself, also when the window changes size) and the "…, N direct reports, N in total" line. The top person and their direct reports show no FTE / FTC tag.
- **Layers:** the top of the organisation (layer 0) is no longer counted as a layer, in the total and for each function.
- **Top of each insight page:** the thick green band is replaced by a row of dark green figure tiles, each with an icon and a small infographic (share rings, a layer graphic, a service / support meter). Dashboard: Total Employees, FTE, FTC, Layers, Managers, Service or Support. Activity Insights: Employees, Activities Recorded (per employee as a whole number), Activity Categories, Automation Candidates. Geographical Spread: Employees, Regions, FTC Share. Dashboard: Total Employees, FTE, FTC, Layers, Managers, Service or Support. Activity Insights: Employees, Activities Recorded, Activity Categories (with the most common category), Automation Candidates. Geographical Spread: Employees, Regions, FTC Share.
- **Activity Insights:** "Main Activity Categories" is now "Activity Category"; the Manual Processing figure is removed from the top (it is in the processing-mode chart); the work filter reads Service, Support, All.
- **No capitals:** nothing is shown in upper case; labels, headings, table headings, tabs and buttons use Title Case.
- **Feedback:** every login has **Share Feedback** in the sidebar: choose a topic (Change Request, Issue, Suggestion, Other) and the page, write the feedback, and see your earlier feedback with its status and any reply. The admin reads it in **Admin → Feedback**, sets a status (New, Under Review, Done, Not Planned), replies, deletes, or downloads everything as CSV.
- **Add and remove employees (admin):** Admin → Employees has **Add Employee** for someone not in the master sheet (kept at every import). Opening an employee shows **Remove Employee**: their activities are deleted and their direct reports move to their manager, after a confirmation. A removed employee stays out when the master sheet is imported again, and anyone the sheet shows reporting to them reports to their manager instead. **Removed by Admin** (in the list filter) shows who was removed, with **Allow Back**. To keep someone's records, mark them Resigned instead. The top of the organogram cannot be removed.
- **Moving from a PC to the VM:** see deploy/MOVE_TO_VM.md.

## New in 2.9

- **Service or support only.** "Both" is removed. Each employee is service staff or support staff. On the first start, anyone marked Both is set to the kind most of their earlier activities had; where that is unclear they show as **Not yet marked** for the POC to set in step 1.
- **Hidden fields stay hidden on the dashboard.** A field set to Hidden in **Admin → Data capture fields** for every selected function (for example automation opportunity) is no longer shown on the dashboard or in the exports. The same applies to a field nobody has filled in.
- **Empty columns are dropped.** If no employee in the selection has a unit, the Unit column disappears from Employees by number of activities. Region and Type of work work the same way.
- **FTE / FTC filter** (All staff, FTE, FTC) on the right of three dashboard sections: Function-wise layers, Service and support, and Activities. In Activities it also applies to the categories, the employee ranking and every list that opens from them.
- **FTE / FTC filter on the organogram:** the Organogram explorer (People view, Classic chart and Whole organisation) and dashboard section 1 have All staff / FTE / FTC. With a filter on, only that type of staff is counted and shown; managers of the other type stay in grey so every reporting line still reaches the top.
- **Organogram explorer and Reporting line** show the structure only. Recorded activities are on the Dashboard and Employee activities pages. Employees marked exclude from count, or resigned, are tagged on the organogram cards.
- **Span of control by type of direct report** (Function-wise layers): the FTE / FTC filter now counts each manager's FTE or FTC direct reports only, so you can see whether a wide span comes from contract staff. A strip under the table compares the average span counting all, FTE only and FTC only reports (select one to filter the section). For managers with more than 15 direct reports, it also shows the FTC share of their teams and how many would be within 15 counting FTE only.
- **Opportunities** lists show the position and grade of both the employee and their manager (for example, same-grade reporting lines), on the dashboard and in the exports.
- **Wording:** "How the work is done" is now **Processing mode**, and "Manual handling" is **Manual processing**.
- **Average span** is shown as a whole number everywhere, including the exports.

## New in 2.8

**Service or support is now the employee's, not the activity's**

- In **Data capture, step 1**, each employee is marked **Service** or **Support** (Both was removed in 2.9), next to their unit and region. Setting it for a manager carries down to their team, as units and regions do. In **Everyone**, tick several employees and set them at once, or set everyone not yet marked.
- Activities no longer ask for service or support (the field is gone from the form, the table view and the Excel template). The template's Staff sheet has a **Service / support** column instead.
- On the first start, each employee is marked from the activities already recorded: only service activities make them Service, only support makes them Support, both kinds make them Both. POCs can change it.

**Resigned employees**

- **Admin → Employees**: tick **Resigned** (with the last working day). The employee stops being counted on every dashboard and export and disappears from data capture; their records are kept, and unticking restores them. The organogram still shows them, marked Resigned, so their team stays connected until their reporting line is changed.
- The Employees list has a **Show** filter: Everyone, Resigned, Marked exclude from count, Edited by admin.

**Reporting line requests**

- In **Data capture, step 1, Everyone**, each employee has **Request change** under their manager. The POC picks the new manager (or enters the code of a manager in another function) and a reason.
- The admin approves or rejects it in **Admin → Requests** (renamed from Re-tagging requests), which now shows both kinds of request: reporting line and function. An approved reporting line is kept when the master sheet is imported again. Circular reporting lines are blocked.

**Excluded employees**

- Employees marked **exclude from count** are now left out of the dashboard figures by default. A note at the top of the dashboard says how many there are, with **View** (the list) and **Count them** (include them). The sidebar switch is gone.

**FTE and FTC filters**

- Data capture: FTE / FTC filter in step 1 (Everyone), in the employee list of step 2, and in **Copy these activities to colleagues** (with Tick all shown). Employee activities has the same filter.

**Dashboard redesign**

- **4 Service and support**: headcount by type of work (Service, Support, Both, Not yet marked) with one bar, and a by-function table. Every figure opens the grade-wise breakup.
- **5 Activities** (new): a strip of key figures (employees covered, activities, categories, manual handling, automation candidates), the main activity categories ranked by the number of employees who perform them (no activity counts), how the work is done, the automation opportunity, the ten employees with the most activities (View all for the full list), and coverage by function.
- Blank units and other empty values are left blank instead of showing "-". The employee popup lists their categories without counts.
- Sections are renumbered: 6 Geographical spread, 7 Opportunities. Exports follow the same changes.

Nothing new to install; database changes are applied automatically on start.

## What changed

**Dashboard (one page, replaces Overview, Structure health, Workforce mix and Function profiles)**

- A function filter bar on top: **COSO** (the whole group) on the first line, then every function in ascending order on the lines below, all visible without scrolling. Select one function or several; selecting COSO clears the others. The same selection applies to the Organogram explorer, Employee activities and the Export button.
- Sections, in order:
  1. Organogram and total direct reports
  2. Total workforce, FTE and FTC. Select any figure for its grade-wise breakup, with tabs by function, by region and the list of employees.
  3. Function-wise layers, with the headcount at each layer, plus span of control
  4. Service and support: staff by Service / Support / Both, daily workload, activity handling, automation opportunity, a by-function table, and activity categories that expand to show the full descriptions
  5. Workforce geographical spread: each region's total, FTE, FTC, Service, Support, Both and not yet marked. Every figure opens its grade-wise breakup.
  6. Structure opportunities and gaps: the same findings as before, reworded

**Data capture (per employee, as in the Excel template)**

- Step 1, Staff, units and regions: set each employee's unit and region. Setting a manager's unit or region carries down to their team; anyone set individually keeps their own. Units are suggested as you type.
- Step 2, Activities: one card per activity with these fields: Function and Unit (automatic, from step 1), Product, Process name, Channel, Activity description, Activity category, Service or Support, Frequency (daily / weekly / fortnightly / monthly), Avg volume, Peak volume at start and end of month (average per day), Activity handling (Manual / File Based / System Based), Staff processing time (min), Total staff processing time (calculated) and Automation opportunity (Yes / No).
- **Products:** an activity can cover several products. Type each one and press Enter; they show as tags.
- **All fields optional:** every field is shown and none is mandatory, because the same employee can have activities with and without volumes or times. POCs fill in what applies and leave the rest blank.
- **Field settings by function:** in **Admin → Data capture fields**, set each field as Required, Optional or Hidden, for all functions (the default) or for one function. A function with its own settings is marked "own settings"; **Use the default for this function** undoes that.
- **Frequencies:** in **Admin → Lists**, add, rename or remove frequencies (for example Quarterly), each with its working days in one period. The working days per week and per month that used to be in Settings now live here. A frequency in use cannot be removed, and renaming one updates its activities.
- **Form or Table view:** the Table view shows an employee's activities as an Excel-like grid, edited in place.
- **Excel template:** **Excel template** downloads every employee of the function with their current activities. It includes drop-down lists and looks up the employee's name from the code. Fill it in and use **Upload filled template**: check the file first, then import. Each employee's activities in the file replace their current ones.
- Product, Process, Channel and Category suggest earlier entries as you type, so a category written once can be picked for other activities.
- **Copy these activities to colleagues** and **Copy activities from a colleague**. When copying, volumes can be kept the same, entered per region, or left empty.
- Same activity, different volume by region: **Compare and set volumes** lists every colleague who has the activity. Set a volume for a whole region, then adjust individuals. **Apply these details to all** pushes a change in the description, time and other details to every copy.
- Step 3, Review: lists missing units, regions and details, employees without activities, and utilisation above 125% or below 50%. There is no submission: POCs can keep editing, and the status shows Not started, In progress or Complete (every employee has a unit, a region and activities, with nothing missing).
- Function heads are listed first in every employee list. The function head covers all units, so no unit is asked for them.
- **Reporting line** for every employee: from Employee activities, data capture, the dashboard popups and the Organogram explorer. It shows the chart of everyone they report to up to the top, the employee highlighted, and their direct reports, with key facts and their recorded activities. Expand further levels, or click a manager on the line to centre the chart on them.
- Every organogram chart has a **Full screen** button (Esc to return), for large expanded teams.

**Time-based figures off by default**

- Man-hours, FTE equivalents and utilisation are hidden for now: on the dashboard, the employee pages, the data capture summaries and the PDF, PowerPoint and HTML exports. The figures count activities instead.
- The dashboard's Service and support section adds **Employees by number of activities**, most first. Select an employee to see their activity categories, then a category to see the detailed activities with full descriptions.
- Volumes and processing times are still recorded, and the Excel workbook still contains them.
- To bring the time figures back later: **Admin → Settings → Time-based figures**, then refresh the page.

**Other**

- **Employee activities** page: shows the activity category, with a **Show full description** button so long paragraphs stay tidy.
- **Admin → Employees**: search any employee and change their name, position, grade, type, function (optionally moving their whole team), who they report to (circular reporting lines are blocked), unit, region and flags. These changes are kept when the master sheet is imported again; **Follow the master sheet again** undoes that for one employee.
- **Admin → Data transfer**: export the data of all functions, or of selected functions, to Excel, and import it on another installation (see below).
- **Admin → Lists** (categories, regions and frequencies) replaces the Categories and regions tab.
- **Admin → Capture progress** tracks every function (Not started / In progress / Complete). **Admin → Settings** adds working days per week and month (5 and 22), and the name of the group in the filter (COSO).
- **Import:** a Region, Location or City column in the master sheet fills in regions automatically. The column is optional.
- **Exports** (PDF, PowerPoint, HTML, Excel) include service and support, geographical spread and employee activities. The Excel workbook has an **Employee activities** sheet in the template layout.
- **Server errors** are now written to the log (`journalctl -u ops-portal`).
- **No new Python packages:** `requirements.txt` and the `wheels` folder are unchanged.

**Existing data is kept.** Employees, logins, regions and flags are untouched. On the first start, any activities entered in the old unit and process screens are converted into one row per employee. The fields the old version did not have (category, Service or Support, handling, automation) are then flagged as missing for the POC to complete.

---

## Test on Windows first

Your existing folder (for example `C:\ops-portal`) has the virtual environment `backend\.venv` and your data in `backend\data`. Keep both.

1. Stop the portal: close its window, or press Ctrl+C in it.
2. Back up `backend\data`: copy the folder somewhere safe.
3. Unzip the new `ops-portal.zip` into a temporary folder, for example `C:\ops-portal-new`.
4. In `C:\ops-portal`, delete these three folders: `backend\app`, `backend\static` and `frontend`.
5. Copy those three folders from `C:\ops-portal-new\ops-portal` into the same places in `C:\ops-portal`. Also copy `README.md` and `UPDATE_v2.md`.
6. Double-click `run_windows.bat`. No packages are installed, because the requirements have not changed.
7. Open http://127.0.0.1:8000 and press **Ctrl+F5** once to load the new screens.

To test from a clean start instead: stop the portal, rename `backend\data` to `backend\data-old`, then start it again. A new admin password is printed in the window. Import the master sheet again.

Things worth checking before showing your boss:

- COSO, then one function, then two functions in the filter bar; **Expand one more level** in the organogram
- Each Total / FTE / FTC figure, and each region figure, opens the grade-wise breakup
- In Data capture step 1, set a unit for a manager and see the team follow; in step 2, record two or three activities for one employee
- Copy them to colleagues in another region, choosing **Enter a volume for each region**
- Open **Compare and set volumes**
- Download a PDF and an Excel export

---

## Update the RHEL 9 VM

Follow **Updating to a new version** in the installation guide as written: stop, back up, copy `backend/app`, `backend/static`, `frontend` and `wheels`, then `pip install` (nothing new is installed) and start. Database changes are applied automatically on start. Afterwards, check the log once:

```bash
journalctl -u ops-portal -n 30 --no-pager
```

If you had activities in the old screens, it shows a line saying how many were converted. Ask users to press Ctrl+F5 after the update.

---

## Moving your data from your PC to the VM

**Option A: copy the database (complete, recommended).** It moves everything: data, logins, settings and history. The database file works the same on Windows and Linux.

1. On your PC, stop the portal.
2. Copy `backend\data\portal.db` and `backend\data\secret.key` to the VM with WinSCP, into `/root`.
3. On the VM, stop the portal and back up the current database:
   ```bash
   systemctl stop ops-portal
   sudo -u opsportal /data/opt/ops-portal/deploy/backup_db.sh
   ```
4. Copy the two files into place, give them to the service account, and start the portal again:
   ```bash
   cp /root/portal.db /root/secret.key /data/opt/ops-portal/backend/data/
   chown opsportal:opsportal /data/opt/ops-portal/backend/data/portal.db /data/opt/ops-portal/backend/data/secret.key
   restorecon -R /data/opt/ops-portal/backend/data
   systemctl start ops-portal
   ```
5. Sign in with your PC's admin password.

**Option B: Excel (if the database copy fails, or you want only some functions).**

1. On your PC, go to **Admin → Data transfer**. Choose **Export all functions**, or export single functions.
2. On the VM, go to **Admin → Import** and import the same employee master sheet.
3. On the VM, go to **Admin → Data transfer**, choose the exported workbook, select **Check the file**, then select **Import**.

What the Excel file carries and what it doesn't:

- **Carried:** units, regions, every activity (copies stay linked), function and reporting line changes, employees added by functions, and the calculation settings.
- **Not carried:** logins. Create them again on the VM in Admin → Users.

Importing the same file twice gives the same result, because each employee's activities are replaced, not added. The workbook is also a readable backup, and it can be corrected in Excel before importing.

"""The CHRO executive report (PDF): As Is against To Be on a few pages."""
import io
from datetime import datetime

from .logic import _DC_LABEL
from .security import get_setting

TEAL = "#00665B"


def messages(d: dict) -> list:
    """The key messages, as on the dashboard."""
    a, b, c, out = d["asis"], d["tobe"], d["counts"], []
    f1 = lambda v: f"{v:,.1f}" if isinstance(v, float) else f"{v:,}"
    dh = b["headcount"] - a["headcount"]
    out.append(f"Headcount {'falls' if dh < 0 else 'rises'} from {a['headcount']:,} to {b['headcount']:,} ({dh:+,})" + (f", with {c['saved']:,} employee roles saved in the restructure." if c["saved"] else ".") if dh else f"Headcount stays at {b['headcount']:,}.")
    k = d.get("cards") or {}
    if k.get("saved_vac"):
        out.append(f"Headcount saved: {k['saved']:,} in all ({k.get('saved_roles', 0):,} employee roles, {k['saved_vac']:,} positions whose hiring was removed).")
    if a["avg_span"] != b["avg_span"]:
        out.append(f"Average span of control {'widens' if b['avg_span'] > a['avg_span'] else 'narrows'} from {f1(a['avg_span'])} to {f1(b['avg_span'])}.")
    if a["narrow"] != b["narrow"]:
        out.append(f"Managers with only 1–2 direct reports: {a['narrow']:,} → {b['narrow']:,}.")
    if a["managers"] != b["managers"]:
        out.append(f"{abs(b['managers'] - a['managers']):,} {'fewer' if b['managers'] < a['managers'] else 'more'} managers ({a['managers']:,} → {b['managers']:,}).")
    if a["layers"] != b["layers"]:
        out.append(f"The deepest layer moves from L{a['layers']} to L{b['layers']}.")
    if c["line"]:
        out.append(f"{c['line']:,} reporting lines changed" + (f" and {c['function']:,} people changed function." if c["function"] else "."))
    if not d.get("fn") and d["by_function"]:
        top = max(d["by_function"], key=lambda f: f["line"] + f["saved"] + f["moved"])
        if top["line"] + top["saved"] + top["moved"]:
            out.append(f"Most change is in {top['function']} ({top['line'] + top['saved'] + top['moved']:,} changes).")
    if d.get("tbh"):
        out.append(f"{d['tbh']:,} positions are to be hired, taking the planned headcount to {b['headcount'] + d['tbh']:,}.")
    if d.get("benchmark") and d["benchmark"]["above"]:
        out.append(f"{d['benchmark']['above']:,} people are above the max grade of their level.")
    return out


def build(db, d: dict, by: str) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    teal = colors.HexColor(TEAL)
    ink, ink2, line, soft = colors.HexColor("#13302c"), colors.HexColor("#5d7570"), colors.HexColor("#dfe8e5"), colors.HexColor("#eef6f4")
    good, bad = colors.HexColor("#2E7D5B"), colors.HexColor("#B4472F")
    H1 = ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=20, leading=24, textColor=ink)
    H2 = ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=12.5, leading=16, textColor=teal, spaceBefore=10, spaceAfter=5)
    P = ParagraphStyle("p", fontName="Helvetica", fontSize=9, leading=12, textColor=ink)
    S = ParagraphStyle("s", fontName="Helvetica", fontSize=8, leading=10.5, textColor=ink2)
    C = ParagraphStyle("c", fontName="Helvetica", fontSize=8, leading=10, textColor=ink)
    a, b, m = d["asis"], d["tobe"], d.get("meta") or {}
    scope = d.get("fn") or ((get_setting(db, "labels") or {}).get("dash.title") or "Operations Services")
    n0 = lambda v: f"{v:,}" if isinstance(v, int) else (f"{v:,.1f}" if isinstance(v, float) else str(v))

    def delta(x, y, better_low=False):
        if not isinstance(x, (int, float)) or not isinstance(y, (int, float)) or x == y:
            return "–", ink2
        dv = y - x
        txt = (f"{dv:+,}" if isinstance(dv, int) else f"{dv:+,.1f}")
        good_dir = (dv < 0) if better_low else (dv > 0)
        return txt, good if good_dir else bad

    def table(rows, widths, head=True, num_from=1, zebra=True, extra=None):
        t = Table(rows, colWidths=widths, repeatRows=1 if head else 0)
        st = [("FONT", (0, 0), (-1, -1), "Helvetica", 8.5), ("TEXTCOLOR", (0, 0), (-1, -1), ink), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
              ("ALIGN", (num_from, 0), (-1, -1), "RIGHT"), ("BOTTOMPADDING", (0, 0), (-1, -1), 4), ("TOPPADDING", (0, 0), (-1, -1), 4),
              ("LINEBELOW", (0, 0), (-1, -1), 0.4, line)]
        if head:
            st += [("BACKGROUND", (0, 0), (-1, 0), teal), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 8.5)]
        if zebra:
            st += [("BACKGROUND", (0, i), (-1, i), soft) for i in range(2 if head else 1, len(rows), 2)]
        t.setStyle(TableStyle(st + (extra or [])))
        return t

    from reportlab.graphics.shapes import Drawing, Line, Rect, String
    BEFORE, AFTER, DOWN, UP = colors.HexColor("#B5C3C0"), colors.HexColor("#008C78"), colors.HexColor("#E0702F"), colors.HexColor("#008C78")

    def bridge_chart(w, h=150):
        c = d["counts"]
        steps = [("As Is", a["headcount"], "t"), ("Saved", -c["saved"], ""), ("Resigned", -c["resigned"], ""), ("Not in portal", -c["removed"], "")]
        if d.get("fn"):
            fnn = d["fn"]
            steps += [("Moved out", -sum(1 for x in d["changes"]["function"] if x["frm"] == fnn), ""), ("Moved in", sum(1 for x in d["changes"]["function"] if x["to"] == fnn), "")]
        steps += [("Added", c["added"], "")]
        tot = sum(v for _, v, _ in steps)
        if tot != b["headcount"]:
            steps.append(("Other", b["headcount"] - tot, ""))
        steps.append(("To Be", b["headcount"], "t"))
        if d.get("tbh"):
            steps += [("To be hired", d["tbh"], ""), ("Planned", b["headcount"] + d["tbh"], "t")]
        steps = [s for s in steps if s[2] == "t" or s[1]]
        dr = Drawing(w, h)
        run, bars = 0, []
        for lab, v, k in steps:
            if k == "t":
                bars.append((lab, v, k, 0, v)); run = v
            else:
                bars.append((lab, v, k, run, run + v)); run += v
        hi = max(max(x[3], x[4]) for x in bars)
        lo = min(x[1] for x in bars if x[2] == "t") * 0.92
        base = max(0, int(lo // 50) * 50)
        top, bot = h - 16, 26
        y = lambda v: bot + (top - bot) * (v - base) / max(1, hi - base)
        bw = w / len(bars)
        dr.add(Line(0, y(base), w, y(base), strokeColor=ink2, strokeWidth=0.5))
        for i, (lab, v, k, f, t) in enumerate(bars):
            x0 = i * bw + bw * 0.18
            y0, y1 = (y(base), y(v)) if k == "t" else (y(min(f, t)), y(max(f, t)))
            dr.add(Rect(x0, y0, bw * 0.64, max(1.5, y1 - y0), fillColor=BEFORE if k == "t" else (DOWN if v < 0 else UP), strokeColor=None))
            dr.add(String(x0 + bw * 0.32, max(y0, y1) + 4, f"{v:,}" if k == "t" else f"{v:+,}", fontName="Helvetica-Bold", fontSize=7.5, textAnchor="middle", fillColor=ink))
            dr.add(String(x0 + bw * 0.32, 12, lab, fontName="Helvetica", fontSize=7, textAnchor="middle", fillColor=ink2))
        if base:
            dr.add(String(0, y(base) + 3, f"axis from {base:,}", fontName="Helvetica", fontSize=6, fillColor=ink2))
        return dr

    def grouped_chart(w, cats, xa, xb, h=130):
        dr = Drawing(w, h)
        mx = max([1] + xa + xb)
        top, bot = h - 14, 18
        y = lambda v: bot + (top - bot) * v / mx
        gw = w / len(cats)
        dr.add(Line(0, bot, w, bot, strokeColor=ink2, strokeWidth=0.5))
        for i, cat in enumerate(cats):
            cx = i * gw + gw / 2
            bwid = min(16, gw * 0.3)
            dr.add(Rect(cx - bwid - 1, bot, bwid, y(xa[i]) - bot, fillColor=BEFORE, strokeColor=None))
            dr.add(Rect(cx + 1, bot, bwid, y(xb[i]) - bot, fillColor=AFTER, strokeColor=None))
            dr.add(String(cx + 1 + bwid / 2, y(xb[i]) + 3, f"{xb[i]:,}", fontName="Helvetica-Bold", fontSize=7, textAnchor="middle", fillColor=ink))
            dr.add(String(cx, 6, cat, fontName="Helvetica", fontSize=7, textAnchor="middle", fillColor=ink2))
        return dr

    def pyramid_chart(w, rows, rh=13):
        h = 14 + len(rows) * rh
        dr = Drawing(w, h)
        mid, lab = w / 2, 14
        mx = max([1] + [max(r[1], r[2]) for r in rows])
        sc = lambda v: (mid - lab - 26) * v / mx
        dr.add(String(mid - lab - 2, h - 9, "As Is", fontName="Helvetica-Bold", fontSize=7, textAnchor="end", fillColor=ink2))
        dr.add(String(mid + lab + 2, h - 9, "To Be", fontName="Helvetica-Bold", fontSize=7, fillColor=ink2))
        for i, (l, x, yv) in enumerate(rows):
            yy = h - 14 - (i + 1) * rh + 2
            dr.add(Rect(mid - lab - sc(x), yy, sc(x), rh - 4, fillColor=BEFORE, strokeColor=None))
            dr.add(Rect(mid + lab, yy, sc(yv), rh - 4, fillColor=AFTER, strokeColor=None))
            dr.add(String(mid, yy + 2.5, l, fontName="Helvetica-Bold", fontSize=7, textAnchor="middle", fillColor=ink2))
            dr.add(String(mid - lab - sc(x) - 3, yy + 2.5, f"{x:,}", fontName="Helvetica", fontSize=6.5, textAnchor="end", fillColor=ink))
            dr.add(String(mid + lab + sc(yv) + 3, yy + 2.5, f"{yv:,}", fontName="Helvetica", fontSize=6.5, fillColor=ink))
        return dr

    def legend(items):
        dr = Drawing(W, 12)
        x = 0
        for lab, col in items:
            dr.add(Rect(x, 2, 8, 8, fillColor=col, strokeColor=None))
            dr.add(String(x + 11, 3, lab, fontName="Helvetica", fontSize=7.5, fillColor=ink2))
            x += 16 + len(lab) * 4.2
        return dr

    out = io.BytesIO()
    doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm, topMargin=16 * mm, bottomMargin=16 * mm,
                            title="HR Dashboard Report", author=by)
    W = A4[0] - 32 * mm

    def foot(c, dc):
        c.saveState()
        c.setFont("Helvetica", 7.5)
        c.setFillColor(ink2)
        c.drawString(16 * mm, 9 * mm, f"HR Dashboard Report · {scope} · {datetime.now():%d %b %Y}")
        c.drawRightString(A4[0] - 16 * mm, 9 * mm, f"Page {dc.page}")
        c.restoreState()

    els = [Paragraph("HR Dashboard Report", H1), Spacer(1, 3),
           Paragraph(f"{scope} · As Is: {m.get('file') or 'HR master file'}{' (' + str(m.get('edits')) + ' corrections)' if m.get('edits') else ''} · To Be: the portal on {datetime.now():%d %b %Y}", S),
           Spacer(1, 8)]
    # headline figures
    rows = [["", "As Is", "To Be", "Change"]]
    spec = [("Headcount", "headcount", True), ("Managers", "managers", True), ("Average span of control", "avg_span", False),
            ("Layers (deepest)", "layers", True), ("Managers with 1–2 direct reports", "narrow", True), ("Managers with more than 15", "wide", True)]
    ext = []
    for i, (lab, k, low) in enumerate(spec, 1):
        dv, col = delta(a[k], b[k], low)
        rows.append([lab, n0(a[k]), n0(b[k]), dv])
        ext.append(("TEXTCOLOR", (3, i), (3, i), col))
    cnt = d["counts"]
    rows.append(["Positions to be hired", "", n0(d.get("tbh") or 0), ""])
    msgs = messages(d)
    if msgs:
        els += [Paragraph("Key messages", H2)] + [Paragraph("•&nbsp;&nbsp;" + t, P) for t in msgs] + [Spacer(1, 4)]
    k = d["cards"]
    red = lambda x, y: max(0, (x or 0) - (y or 0))
    crow = [["", "Result", "As Is → To Be"],
            ["Layers reduction", n0(red(k["layers"]["asis"], k["layers"]["tobe"])), f"L{k['layers']['asis']} → L{k['layers']['tobe']} (deepest layer)"],
            ["Span reduction (managers with 1–2 reports)", n0(red(k["span"]["narrow_asis"], k["span"]["narrow_tobe"])), f"{k['span']['narrow_asis']:,} → {k['span']['narrow_tobe']:,} · average span {k['span']['asis']} → {k['span']['tobe']}"],
            ["Functions changed", n0(k["functions"]["changed"]), "employees whose function changed"],
            ["Single-report managers reduced", n0(red(k["single"]["asis"], k["single"]["tobe"])), f"{k['single']['asis']:,} → {k['single']['tobe']:,} (one direct report who manages a team)"],
            ["Functional titles changed", n0(k.get("titles", 0)), "position (designation) changed"],
            ["Taggings corrected", n0(k["tagging"]), "line managers changed"],
            ["Headcount saved", n0(k["saved"]), f"{n0(k.get('saved_roles', k['saved']))} employee roles removed, {n0(k.get('saved_vac', 0))} positions with hiring removed"]]
    els += [Paragraph("Restructure at a glance", H2), table(crow, [W * .42, W * .16, W * .42], num_from=1, extra=[("FONT", (1, 1), (1, -1), "Helvetica-Bold", 10), ("TEXTCOLOR", (1, 1), (1, -1), teal), ("ALIGN", (2, 0), (2, -1), "LEFT")])]
    els += [Paragraph("Organisation", H2), table(rows, [W * .46, W * .18, W * .18, W * .18], extra=ext + [("FONT", (3, 1), (3, -1), "Helvetica-Bold", 8.5)])]
    # changes
    lab = [("line", "Reporting line changes"), ("function", "Functions changed"), ("span", "Span of control changes (managers)"), ("layer", "Layer changes (people)"),
           ("grade", "Grade changes"), ("title", "Title changes"), ("saved", "Headcount saved (employee roles and hiring removed)"), ("tbh", "Positions to be hired")]
    rows = [["Change", "Count"]] + [[t, n0(d["cards"]["saved"] if k == "saved" else cnt.get(k, 0))] for k, t in lab]
    els += [Paragraph("Changes done", H2), table(rows, [W * .7, W * .3])]
    # spans and layers
    bands = list(a["bands"].keys())
    lays = sorted({int(x) for x in list(a["by_layer"]) + list(b["by_layer"])})
    sp = grouped_chart(W * .5, bands, [a["bands"][k] for k in bands], [b["bands"][k] for k in bands])
    ly = pyramid_chart(W * .46, [(f"L{l}", a["by_layer"].get(str(l), 0), b["by_layer"].get(str(l), 0)) for l in lays])
    pair = Table([[Paragraph("Span of control (managers by direct reports)", H2), Paragraph("People by layer", H2)], [sp, ly]], colWidths=[W * .52, W * .48])
    pair.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
    els += [KeepTogether([pair, legend([("As Is", BEFORE), ("To Be", AFTER)])])]
    # workforce mix
    tn = {"fte": "FTE", "dc": _DC_LABEL[0], "ftc": "FTC", "dw": _DC_LABEL[1]}
    rows = [["Type", "As Is", "To Be", "Change"]] + [[tn[k], n0(a["types"].get(k, 0)), n0(b["types"].get(k, 0)), delta(a["types"].get(k, 0), b["types"].get(k, 0))[0]]
                                                    for k in ("fte", "dc", "ftc", "dw") if a["types"].get(k) or b["types"].get(k)]
    rows += [["Women", n0(a["gender"]["f"]), n0(b["gender"]["f"]), delta(a["gender"]["f"], b["gender"]["f"])[0]]]
    els += [KeepTogether([Paragraph("Workforce mix", H2), table(rows, [W * .4, W * .2, W * .2, W * .2])])]
    if d.get("benchmark"):
        bm = d["benchmark"]
        rows = [["Grade benchmark (To Be)", "People"], ["Below benchmark", n0(bm["room"])], ["At max benchmark", n0(bm["at"])], ["Above benchmark", n0(bm["above"])],
                ["Permanent staff on a layer beyond Teams", n0(bm["extra"])]]
        els += [KeepTogether([Paragraph("Grade benchmark", H2), table(rows, [W * .7, W * .3])])]
    # by function
    if len(d["by_function"]) > 1:
        els += [PageBreak(), Paragraph("By function", H2)]
        rows = [["Function", "Headcount", "Managers", "Avg span", "Layers", "Saved", "Line changes", "To hire"]]
        for f in d["by_function"]:
            x, y = f["asis"], f["tobe"]
            rows.append([Paragraph(f["function"], C), f"{n0(x['headcount'])} → {n0(y['headcount'])}", f"{n0(x['managers'])} → {n0(y['managers'])}",
                         f"{n0(x['avg_span'])} → {n0(y['avg_span'])}", f"{x['layers']} → {y['layers']}", n0(f["saved"]) if f["saved"] else "–",
                         n0(f["line"]) if f["line"] else "–", n0(f["tbh"]) if f["tbh"] else "–"])
        els += [table(rows, [W * .25, W * .13, W * .11, W * .12, W * .08, W * .08, W * .13, W * .09])]
    # lists
    ch = d["changes"]
    sv = ch.get("saved_all") or ch["saved"]
    if sv:
        els += [Paragraph(f"Headcount saved ({sum(x.get('n', 1) for x in sv):,})", H2)]
        rows = [["Employee / position", "Saved as", "Grade", "Function", "Reason", "Date"]] + [[Paragraph(f"{x['name']}<br/><font color='#5d7570' size='7'>{x['position'] if x.get('code') else ''}</font>", C),
                 Paragraph(x.get("what", "Employee role") + (f" ({x['n']})" if x.get("n", 1) > 1 else ""), C), x["grade"], Paragraph(x["function"], C), Paragraph(x.get("reason") or "", C), x.get("date") or ""] for x in sv[:120]]
        els += [table(rows, [W * .26, W * .16, W * .08, W * .2, W * .2, W * .1], num_from=9)]
    if ch["line"]:
        els += [Paragraph(f"Reporting line changes ({len(ch['line'])}{', first 150 shown' if len(ch['line']) > 150 else ''})", H2)]
        rows = [["Employee", "Function", "As Is manager", "To Be manager"]] + [[Paragraph(x["name"], C), Paragraph(x["function"], C), Paragraph(x["frm"], C), Paragraph(x["to"], C)] for x in ch["line"][:150]]
        els += [table(rows, [W * .27, W * .25, W * .24, W * .24], num_from=9)]
    if ch["function"]:
        els += [Paragraph(f"Function changes ({len(ch['function'])})", H2)]
        rows = [["Employee", "From", "To"]] + [[Paragraph(x["name"], C), Paragraph(x["frm"], C), Paragraph(x["to"], C)] for x in ch["function"][:150]]
        els += [table(rows, [W * .34, W * .33, W * .33], num_from=9)]
    doc.build(els, onFirstPage=foot, onLaterPages=foot)
    return out.getvalue()

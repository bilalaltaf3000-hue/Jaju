"""Work summaries: the bank's on-premise AI writes, for each employee, a short summary of the work captured in the
portal, with their volume-based and non-volume-based work. Written in the background by the admin (like Role
Overlap) and saved, so the organogram pop-up opens at once. A summary is out of date when the activities change."""
import hashlib
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from typing import Dict, List, Optional

from sqlalchemy.orm import Session

from . import models, roleai
from .db import SessionLocal

log = logging.getLogger("ops.empsum")

MIN_ACTS = 2          # fewer activities: the figures and lists only, no AI paragraph
MAX_ACTS = 45         # activities in one request (the largest volumes first)

SYSTEM = ("You are an operations analyst in a bank. You summarise what one employee does, only from the job activities "
          "given to you. Do not invent tasks, systems, volumes or numbers that are not in the activities. "
          "Answer with JSON only, no other text.")


def acts_of(db: Session, codes) -> Dict[str, List[dict]]:
    out: Dict[str, List[dict]] = {}
    q = db.query(models.WorkItem).filter(models.WorkItem.employee_code.in_(list(codes) or ["-"])).order_by(
        models.WorkItem.employee_code, models.WorkItem.sort, models.WorkItem.id)
    for w in q:
        out.setdefault(w.employee_code, []).append({
            "id": w.id, "desc": (w.description or "").strip(), "cat": (w.category or "").strip(), "process": (w.process or "").strip(),
            "freq": w.frequency or "", "volume": float(w.volume or 0)})
    return out


def acts_hash(acts: List[dict]) -> str:
    h = hashlib.sha256()
    for a in sorted(acts, key=lambda a: a["id"]):
        h.update(f"{a['id']}|{a['desc']}|{a['cat']}|{a['freq']}|{a['volume']:g}\n".encode())
    return h.hexdigest()[:40]


def _vol(a):
    return f"{a['volume']:g} {a['freq'].lower()}".strip()


def prompt(e: models.Employee, acts: List[dict]) -> (str, Dict[str, int]):
    acts = sorted(acts, key=lambda a: -a["volume"])[:MAX_ACTS]
    ids, lines = {}, []
    lines.append(f"Employee: {e.position or 'no position'}, grade {e.grade or '-'}.")
    lines.append("Their activities (V = volume-based, with the volume and how often; N = no volume):")
    for n, a in enumerate(acts, 1):
        tag = f"A{n}"
        ids[tag] = a["id"]
        kind = f"V | Volume: {_vol(a)}" if a["volume"] > 0 else f"N | {a['freq'] or 'no frequency'}"
        extra = " | ".join(x for x in (a["cat"], a["process"]) if x)
        lines.append(f"{tag} | {kind} | {extra + ' | ' if extra else ''}{a['desc'][:350] or '(no description)'}")
    lines += ["", "Tasks:",
              "1. summary: two or three sentences, in plain English, on what this employee does. Cover the volume-based work "
              "(mention the main volumes as given, for example 'about 120 a month') and the non-volume-based work.",
              "2. items: for every activity, a short phrase of at most 9 words that says what is done, starting with a verb.",
              "", 'Answer JSON: {"summary": "...", "items": [{"a": "A1", "text": "Approves maintenance requests"}]}']
    return "\n".join(lines), ids


def write_one(db: Session, cfg, e: models.Employee, acts: List[dict]) -> models.EmpSummary:
    h = acts_hash(acts)
    row = db.get(models.EmpSummary, e.code) or models.EmpSummary(code=e.code)
    if len(acts) < MIN_ACTS:
        row.summary, row.items = "", []
    else:
        p, ids = prompt(e, acts)
        ans = roleai.chat_json(cfg, p, SYSTEM)
        items = []
        for x in ans.get("items") or []:
            if isinstance(x, dict) and str(x.get("a", "")).strip() in ids and str(x.get("text") or "").strip():
                items.append({"id": ids[str(x["a"]).strip()], "text": str(x["text"]).strip()[:120]})
        row.summary, row.items = str(ans.get("summary") or "").strip()[:1200], items
    row.acts_hash, row.n_acts, row.model, row.at = h, len(acts), cfg["model"], datetime.utcnow()
    db.merge(row)
    return row


# ---------------------------------------------------------------- the background run
def start(db: Session, function_id: Optional[int], only_changed: bool, user) -> models.RoRun:
    with roleai._lock:
        if roleai.busy(db):
            raise roleai.AiError("The AI is busy with another run (Role Overlap or work summaries). Wait for it to finish, or stop it.")
        cfg = roleai.settings(db)
        run = models.RoRun(function_id=function_id, kind="summary", status="queued", model=cfg["model"], started_by=user.username,
                           current="changed" if only_changed else "all")
        db.add(run)
        db.commit()
        import threading
        threading.Thread(target=_run, args=(run.id, only_changed), daemon=True, name=f"empsum-{run.id}").start()
        return run


def _run(run_id: int, only_changed: bool):
    db = SessionLocal()
    try:
        run = db.get(models.RoRun, run_id)
        cfg = roleai.settings(db)
        q = db.query(models.Employee).filter(models.Employee.resigned == False)  # noqa: E712
        if run.function_id:
            q = q.filter(models.Employee.function_id == run.function_id)
        emps = {e.code: e for e in q}
        acts = acts_of(db, emps)
        have = {s.code: s.acts_hash for s in db.query(models.EmpSummary)}
        todo = [c for c, a in acts.items() if a and (not only_changed or have.get(c) != acts_hash(a))]
        run.status, run.total, run.current = "running", len(todo), ""
        db.commit()
        snap = {c: (emps[c].code, emps[c].position, emps[c].grade) for c in todo}
    except Exception as ex:   # noqa: BLE001
        log.exception("work summaries %s could not start", run_id)
        roleai._update(run_id, status="failed", error=str(ex)[:2000], finished_at=datetime.utcnow())
        db.close()
        return
    db.close()
    done = failed = 0
    errors: List[str] = []

    class E:   # a plain copy for the worker threads
        def __init__(self, t):
            self.code, self.position, self.grade = t

    def work(code):
        e = E(snap[code])
        if len(acts[code]) < MIN_ACTS:
            return code, None
        p, ids = prompt(e, acts[code])
        return code, (roleai.chat_json(cfg, p, SYSTEM), ids)

    try:
        with ThreadPoolExecutor(max_workers=cfg["concurrency"]) as ex:
            futs = [ex.submit(work, c) for c in todo]
            for f in as_completed(futs):
                if run_id in roleai._cancel:
                    for j in futs:
                        j.cancel()
                    break
                try:
                    code, res = f.result()
                    s = SessionLocal()
                    try:
                        row = s.get(models.EmpSummary, code) or models.EmpSummary(code=code)
                        if res is None:
                            row.summary, row.items = "", []
                        else:
                            ans, ids = res
                            items = [{"id": ids[str(x["a"]).strip()], "text": str(x["text"]).strip()[:120]} for x in (ans.get("items") or [])
                                     if isinstance(x, dict) and str(x.get("a", "")).strip() in ids and str(x.get("text") or "").strip()]
                            row.summary, row.items = str(ans.get("summary") or "").strip()[:1200], items
                        row.acts_hash, row.n_acts, row.model, row.at = acts_hash(acts[code]), len(acts[code]), cfg["model"], datetime.utcnow()
                        s.merge(row)
                        s.commit()
                    finally:
                        s.close()
                    done += 1
                except Exception as e:   # noqa: BLE001
                    failed += 1
                    if len(errors) < 5:
                        errors.append(str(e)[:300])
                if (done + failed) % 3 == 0 or done + failed == len(todo):
                    roleai._update(run_id, done=done, failed=failed)
        st = "cancelled" if run_id in roleai._cancel else ("failed" if todo and failed == len(todo) else "done")
        roleai._update(run_id, status=st, done=done, failed=failed, finished_at=datetime.utcnow(), current="",
                       error=("Every AI request failed. " if st == "failed" else "") + "\n".join(errors))
    except Exception as ex:   # noqa: BLE001
        log.exception("work summaries %s failed", run_id)
        roleai._update(run_id, status="failed", error=str(ex)[:2000], finished_at=datetime.utcnow(), done=done, failed=failed)
    finally:
        roleai._cancel.discard(run_id)

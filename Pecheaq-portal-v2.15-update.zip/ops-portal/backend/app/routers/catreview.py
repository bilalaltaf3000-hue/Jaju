"""Admin: review the activity categories written by every function, merge duplicates into one standard name
(with undo), and group categories under activity themes."""
import re
from datetime import datetime
from typing import Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..security import audit, get_setting, require_admin, set_setting

router = APIRouter(prefix="/api/admin")
NO_THEME = "No Theme"
_STOP = {"and", "of", "the", "for", "to", "in", "on", "a", "an", "with"}


def theme_map(db: Session) -> Dict[str, str]:
    """category (lower case) -> theme."""
    return dict(get_setting(db, "category_themes") or {})


def theme_list(db: Session) -> List[str]:
    return list(get_setting(db, "themes") or [])


def theme_of(category: str, tm: Dict[str, str]) -> str:
    return tm.get(" ".join((category or "").split()).lower(), "")


def dup_key(name: str) -> str:
    """A loose key so that near-identical spellings fall together: case, '&' / 'and', punctuation, plurals."""
    s = (name or "").lower().replace("&", " and ")
    s = re.sub(r"[^a-z0-9 ]+", " ", s)
    words = []
    for w in s.split():
        if w in _STOP:
            continue
        if len(w) > 3 and w.endswith("ies"):
            w = w[:-3] + "y"
        elif len(w) > 3 and w.endswith("s") and not w.endswith("ss"):
            w = w[:-1]
        if w.endswith("ing") and len(w) > 5:
            w = w[:-3]
        words.append(w)
    return " ".join(sorted(words))


class Filt(BaseModel):
    functions: List[int] = []
    units: List[str] = []
    region: str = ""
    emp_type: str = ""
    role: str = ""


def _items(db: Session, f: Filt):
    """The activities in scope of the filter, with their employees."""
    q = db.query(models.Employee)
    if f.functions:
        q = q.filter(models.Employee.function_id.in_(f.functions))
    emps = {}
    for e in q:
        if e.resigned:
            continue
        if f.units and (e.unit_name or "") not in f.units:
            continue
        if f.region and (e.region or "") != f.region:
            continue
        if f.emp_type in ("FTE", "FTC") and e.emp_type != f.emp_type:
            continue
        if f.role in ("Service", "Support") and e.service_role != f.role:
            continue
        emps[e.code] = e
    codes = list(emps)
    items = []
    for i in range(0, len(codes), 500):
        items += db.query(models.WorkItem).filter(models.WorkItem.employee_code.in_(codes[i:i + 500])).all()
    return emps, items


def _filt(functions: str, units: List[str], region: str, emp_type: str, role: str) -> Filt:
    return Filt(functions=[int(x) for x in functions.split(",") if x.strip().isdigit()], units=[u for u in units if u],
                region=region or "", emp_type=emp_type or "", role=role or "")


@router.get("/category-review")
def review(functions: str = Query(""), units: List[str] = Query([]), region: str = Query(""), emp_type: str = Query(""),
           role: str = Query(""), user=Depends(require_admin), db: Session = Depends(get_db)):
    f = _filt(functions, units, region, emp_type, role)
    emps, items = _items(db, f)
    fnames = {x.id: x.name for x in db.query(models.Function)}
    tm = theme_map(db)
    std = {c.name.lower() for c in db.query(models.Category)}
    cats: Dict[str, dict] = {}
    for w in items:
        name = " ".join((w.category or "").split())
        if not name:
            continue
        c = cats.setdefault(name.lower(), {"name": name, "activities": 0, "emps": set(), "fns": set(), "units": set()})
        c["activities"] += 1
        e = emps[w.employee_code]
        c["emps"].add(e.code)
        c["fns"].add(fnames.get(e.function_id, ""))
        if e.unit_name:
            c["units"].add(e.unit_name)
    rows = []
    for k, c in cats.items():
        rows.append({"name": c["name"], "activities": c["activities"], "employees": len(c["emps"]),
                     "functions": sorted(x for x in c["fns"] if x), "units": sorted(c["units"]),
                     "theme": tm.get(k, ""), "standard": k in std, "key": dup_key(c["name"])})
    rows.sort(key=lambda r: (-r["activities"], r["name"].lower()))
    groups: Dict[str, list] = {}
    for r in rows:
        if r["key"]:
            groups.setdefault(r["key"], []).append(r["name"])
    suggested = [v for v in groups.values() if len(v) > 1]
    # options for the filters
    all_emps = [e for e in db.query(models.Employee) if not e.resigned]
    unit_opts = sorted({e.unit_name for e in all_emps if e.unit_name and (not f.functions or e.function_id in f.functions)})
    region_opts = sorted({e.region for e in all_emps if e.region})
    last = get_setting(db, "last_category_merge") or None
    efn = {e.code: e.function_id for e in all_emps}
    fn_acts: Dict[int, int] = {}
    for (code,) in db.query(models.WorkItem.employee_code):
        if code in efn:
            fn_acts[efn[code]] = fn_acts.get(efn[code], 0) + 1
    return {"categories": rows, "suggested": suggested, "themes": theme_list(db), "show_themes": bool(get_setting(db, "show_themes")), "show_categories": get_setting(db, "show_categories") is not False, "no_activities": sum(1 for w in items if not (w.category or "").strip()),
            "units": unit_opts, "regions": region_opts,
            "functions": [{"id": i, "name": n, "activities": fn_acts.get(i, 0)} for i, n in sorted(fnames.items(), key=lambda kv: kv[1])],
            "last_merge": {"to": last["to"], "from": last["from"], "count": len(last["changes"]), "at": last["at"]} if last else None}


@router.get("/category-samples")
def samples(name: str, functions: str = Query(""), units: List[str] = Query([]), region: str = Query(""), emp_type: str = Query(""),
            role: str = Query(""), user=Depends(require_admin), db: Session = Depends(get_db)):
    emps, items = _items(db, _filt(functions, units, region, emp_type, role))
    fnames = {x.id: x.name for x in db.query(models.Function)}
    key = " ".join(name.split()).lower()
    out = []
    for w in items:
        if " ".join((w.category or "").split()).lower() == key:
            e = emps[w.employee_code]
            out.append({"employee": e.name, "function": fnames.get(e.function_id, ""), "unit": e.unit_name or "",
                        "description": (w.description or "").strip(), "process": w.process or "", "product": w.product or ""})
            if len(out) >= 25:
                break
    return out


class MergeIn(Filt):
    names: List[str]
    to: str


@router.post("/category-merge")
def merge(body: MergeIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Rename the chosen categories to one standard name, for the activities in scope of the filter. The admin's
    standard category list gets the new name; a theme of the merged categories carries over to it."""
    to = " ".join((body.to or "").split())[:200]
    if not to:
        raise HTTPException(400, "Type or choose the standard name.")
    keys = {" ".join(n.split()).lower() for n in body.names if n and n.strip()}
    if not keys:
        raise HTTPException(400, "Tick at least one category.")
    emps, items = _items(db, body)
    changes = []
    for w in items:
        k = " ".join((w.category or "").split()).lower()
        if k in keys and (w.category or "") != to:
            changes.append([w.id, w.category or ""])
            w.category = to
    if not changes:
        raise HTTPException(400, "No activities in the current filter use these categories.")
    tm = theme_map(db)
    tk = to.lower()
    if not tm.get(tk):
        carried = next((tm[k] for k in keys if tm.get(k)), "")
        if carried:
            tm[tk] = carried
            set_setting(db, "category_themes", tm)
    added = not db.query(models.Category).filter(models.Category.name == to).first()
    if added:
        db.add(models.Category(name=to, sort=99))
    # standard names that were merged away are no longer offered (undo brings them back)
    removed = []
    for k in keys - {tk}:
        for c in db.query(models.Category).all():
            if c.name.lower() == k:
                removed.append([c.name, c.sort])
                db.delete(c)
    set_setting(db, "last_category_merge", {"to": to, "from": sorted({n.strip() for n in body.names}), "changes": changes,
                                             "removed_std": removed, "added_std": added,
                                             "at": datetime.now().strftime("%d %b %Y %H:%M"), "by": user.username})
    audit(db, user, "category_merge", f"{', '.join(sorted(keys))} -> {to}: {len(changes)} activities")
    db.commit()
    return {"ok": True, "activities": len(changes), "to": to}


@router.post("/category-undo")
def undo(user=Depends(require_admin), db: Session = Depends(get_db)):
    last = get_setting(db, "last_category_merge")
    if not last:
        raise HTTPException(400, "There is no merge to undo.")
    back = dict((int(i), old) for i, old in last["changes"])
    n = 0
    ids = list(back)
    for i in range(0, len(ids), 500):
        for w in db.query(models.WorkItem).filter(models.WorkItem.id.in_(ids[i:i + 500])):
            if " ".join((w.category or "").split()).lower() == last["to"].lower():
                w.category = back[w.id]
                n += 1
    for name, sort in last.get("removed_std") or []:
        if not db.query(models.Category).filter(models.Category.name == name).first():
            db.add(models.Category(name=name, sort=sort if sort is not None else 99))
    if last.get("added_std"):
        db.flush()
        still = any(" ".join((w.category or "").split()).lower() == last["to"].lower() for w in db.query(models.WorkItem.category).distinct())
        if not still:
            for c in db.query(models.Category).filter(models.Category.name == last["to"]):
                db.delete(c)
    set_setting(db, "last_category_merge", None)
    audit(db, user, "category_undo", f"{last['to']}: {n} activities restored")
    db.commit()
    return {"ok": True, "activities": n}


# ---------------------------------------------------------------- activity themes
class ThemeIn(BaseModel):
    name: Optional[str] = None
    new_name: Optional[str] = None


@router.get("/themes")
def themes(user=Depends(require_admin), db: Session = Depends(get_db)):
    tm = theme_map(db)
    return [{"name": t, "categories": sum(1 for v in tm.values() if v == t)} for t in theme_list(db)]


@router.post("/themes")
def add_theme(body: ThemeIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    n = " ".join((body.name or "").split())[:80]
    if not n:
        raise HTTPException(400, "Type the theme name.")
    ts = theme_list(db)
    if n.lower() in [t.lower() for t in ts] or n.lower() == NO_THEME.lower():
        raise HTTPException(409, "This theme already exists.")
    set_setting(db, "themes", ts + [n])
    audit(db, user, "theme_add", n)
    db.commit()
    return themes(user, db)


@router.patch("/themes")
def rename_theme(body: ThemeIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    old, new = (body.name or "").strip(), " ".join((body.new_name or "").split())[:80]
    ts = theme_list(db)
    if old not in ts:
        raise HTTPException(404, "Unknown theme.")
    if not new:
        raise HTTPException(400, "Type the new name.")
    if new != old and new.lower() in [t.lower() for t in ts if t != old]:
        raise HTTPException(409, "Another theme has this name.")
    set_setting(db, "themes", [new if t == old else t for t in ts])
    set_setting(db, "category_themes", {k: (new if v == old else v) for k, v in theme_map(db).items()})
    audit(db, user, "theme_rename", f"{old} -> {new}")
    db.commit()
    return themes(user, db)


@router.delete("/themes")
def remove_theme(body: ThemeIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Remove a theme; its categories go back to No Theme."""
    old = (body.name or "").strip()
    ts = theme_list(db)
    if old not in ts:
        raise HTTPException(404, "Unknown theme.")
    set_setting(db, "themes", [t for t in ts if t != old])
    set_setting(db, "category_themes", {k: v for k, v in theme_map(db).items() if v != old})
    audit(db, user, "theme_remove", old)
    db.commit()
    return themes(user, db)


class AssignIn(BaseModel):
    names: List[str]
    theme: str = ""


@router.post("/category-theme")
def assign(body: AssignIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Put categories under a theme (an empty theme takes them out of their theme)."""
    th = (body.theme or "").strip()
    if th and th not in theme_list(db):
        raise HTTPException(400, "Unknown theme.")
    tm = theme_map(db)
    for n in body.names:
        k = " ".join((n or "").split()).lower()
        if not k:
            continue
        if th:
            tm[k] = th
        else:
            tm.pop(k, None)
    set_setting(db, "category_themes", tm)
    audit(db, user, "category_theme", f"{len(body.names)} categories -> {th or NO_THEME}")
    db.commit()
    return {"ok": True}

"""HR decisions: recorded per function by the admin or a login with decisions access, and seen only by them."""
import io
import re
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..security import audit, current_user

router = APIRouter(prefix="/api/decisions")
STATUSES = ["Recommended", "Approved", "Implemented", "On hold"]


def require_decisions(user=Depends(current_user)):
    if user.role != "admin" and not user.can_decisions:
        raise HTTPException(403, "You do not have access to recommendations. Ask the admin.")
    return user


def require_emp_changes(user=Depends(current_user)):
    if user.role != "admin" and not user.can_emp_changes:
        raise HTTPException(403, "You do not have access to Employee Changes. Ask the admin.")
    return user


class DecisionIn(BaseModel):
    function_id: Optional[int] = None
    decided_on: Optional[str] = None
    subject: str
    details: str = ""
    status: str = "Recommended"


def _clean(db, body: DecisionIn) -> dict:
    subj = " ".join((body.subject or "").split())[:250]
    if len(subj) < 3:
        raise HTTPException(400, "Write a short subject for the decision.")
    if body.function_id is not None and not db.get(models.Function, body.function_id):
        raise HTTPException(400, "Unknown function.")
    d = (body.decided_on or "").strip()[:10]
    if d and not re.match(r"^\d{4}-\d{2}-\d{2}$", d):
        raise HTTPException(400, "The date must be a date (YYYY-MM-DD).")
    if body.status not in STATUSES:
        raise HTTPException(400, "Status must be one of: " + ", ".join(STATUSES) + ".")
    return {"function_id": body.function_id, "decided_on": d or None, "subject": subj, "details": (body.details or "").strip()[:10000], "status": body.status}


def _out(x: models.Decision, fnames):
    return {"id": x.id, "function_id": x.function_id, "function": fnames.get(x.function_id, "") if x.function_id else "",
            "decided_on": x.decided_on or "", "subject": x.subject or "", "details": x.details or "", "status": {"Decided": "Approved"}.get(x.status or "", x.status or "Recommended"),
            "recorded_by": x.recorded_name or x.recorded_by or "", "recorded_user": x.recorded_by or "", "recorded_at": x.created_at.isoformat(timespec="minutes") if x.created_at else "",
            "updated_by": x.updated_by or "", "updated_at": x.updated_at.isoformat(timespec="minutes") if x.updated_at else ""}


def _rows(db, function_id):
    q = db.query(models.Decision)
    if function_id:
        q = q.filter(models.Decision.function_id == function_id)
    return sorted(q, key=lambda x: (x.decided_on or "", x.id), reverse=True)


@router.get("")
def list_decisions(function_id: Optional[int] = Query(None), user=Depends(require_decisions), db: Session = Depends(get_db)):
    fnames = {f.id: f.name for f in db.query(models.Function)}
    rows = _rows(db, function_id)
    counts = {}
    for (fid,) in db.query(models.Decision.function_id):
        counts[fid or 0] = counts.get(fid or 0, 0) + 1
    return {"rows": [_out(x, fnames) for x in rows], "statuses": STATUSES,
            "functions": [{"id": i, "name": n, "decisions": counts.get(i, 0)} for i, n in sorted(fnames.items(), key=lambda kv: kv[1].lower())],
            "general": counts.get(0, 0), "total": sum(counts.values())}


@router.post("")
def add_decision(body: DecisionIn, user=Depends(require_decisions), db: Session = Depends(get_db)):
    x = models.Decision(**_clean(db, body), recorded_by=user.username, recorded_name=user.full_name or user.username)
    db.add(x)
    audit(db, user, "decision_add", x.subject)
    db.commit()
    return {"id": x.id}


@router.patch("/{did}")
def edit_decision(did: int, body: DecisionIn, user=Depends(require_decisions), db: Session = Depends(get_db)):
    x = db.get(models.Decision, did)
    if not x:
        raise HTTPException(404, "Decision not found.")
    if user.role != "admin" and x.recorded_by != user.username:
        raise HTTPException(403, "Only the person who recorded it, or the admin, can change this decision.")
    for k, v in _clean(db, body).items():
        setattr(x, k, v)
    x.updated_by, x.updated_at = user.full_name or user.username, datetime.utcnow()
    audit(db, user, "decision_edit", x.subject)
    db.commit()
    return {"ok": True}


@router.delete("/{did}")
def delete_decision(did: int, user=Depends(require_decisions), db: Session = Depends(get_db)):
    x = db.get(models.Decision, did)
    if not x:
        raise HTTPException(404, "Decision not found.")
    if user.role != "admin" and x.recorded_by != user.username:
        raise HTTPException(403, "Only the person who recorded it, or the admin, can delete this decision.")
    audit(db, user, "decision_delete", x.subject)
    db.delete(x)
    db.commit()
    return {"ok": True}


@router.get("/export")
def export_decisions(function_id: Optional[int] = Query(None), user=Depends(require_decisions), db: Session = Depends(get_db)):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    fnames = {f.id: f.name for f in db.query(models.Function)}
    wb = Workbook()
    ws = wb.active
    ws.title = "Recommendations"
    head = ["Date", "Function", "Subject", "Recommendation", "Status", "Recorded by", "Recorded on"]
    ws.append(head)
    for x in _rows(db, function_id):
        o = _out(x, fnames)
        ws.append([o["decided_on"], o["function"] or "All functions", o["subject"], o["details"], o["status"], o["recorded_by"], o["recorded_at"].replace("T", " ")])
    for i, wd in enumerate([12, 30, 40, 80, 13, 22, 17], 1):
        c = ws.cell(1, i)
        c.font, c.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="00796B")
        ws.column_dimensions[c.column_letter].width = wd
    for row in ws.iter_rows(min_row=2, min_col=3, max_col=4):
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.freeze_panes = "A2"
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    audit(db, user, "decision_export", fnames.get(function_id, "all functions"))
    db.commit()
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="recommendations_{datetime.now():%Y%m%d_%H%M}.xlsx"'})

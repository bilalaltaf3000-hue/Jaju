"""HR changes: what differs from the HR master sheet, for HR to update their record, function by function:
reporting line changes, function changes, employees added on request of functions (working, not in the HR record),
employees marked resigned, and the positions to be hired. Seen by the admin and the logins with HR access."""
import io
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..security import audit
from .decisions import require_emp_changes
from ..security import require_admin
from ..cache import cached_json
from ..logic import vac_kind_label

router = APIRouter(prefix="/api/hr")


def _data(db, function_id):
    fns = {f.id: f.name for f in db.query(models.Function)}
    emps = {e.code: e for e in db.query(models.Employee)}
    nm = lambda c: emps[c].name if c in emps else ""
    infn = lambda *ids: not function_id or function_id in ids
    when = {}
    for r in db.query(models.RetagRequest):   # who approved a change and when (when it came through a request)
        if r.status == "Approved":
            when[(r.code, r.kind or "function")] = (r.resolved_by or "", r.resolved_at.strftime("%Y-%m-%d") if r.resolved_at else "")
    base = lambda e: {"code": e.code, "name": e.name, "grade": e.grade or "", "position": e.position or "", "emp_type": e.emp_type,
                      "function": fns.get(e.function_id, ""), "unit": e.unit_name or ""}
    reporting, function, added, resigned = [], [], [], []
    for e in sorted(emps.values(), key=lambda e: (fns.get(e.function_id, ""), e.name)):
        if e.source == "added":
            if infn(e.function_id):
                added.append(dict(base(e), manager=nm(e.manager_code), manager_code=e.manager_code or "", added_by=e.added_by or "",
                                  added_at=e.added_at.strftime("%Y-%m-%d") if e.added_at else "", resigned=bool(e.resigned)))
            continue
        if e.resigned and infn(e.function_id):
            resigned.append(dict(base(e), resigned_on=e.resigned_on or "", manager=nm(e.manager_code)))
        hm = e.hr_manager_code
        if hm != "?" and (hm or None) != (e.manager_code or None) or (hm == "?" and "manager" in (e.overrides or [])):
            if infn(e.function_id, e.hr_function_id):
                by, on = when.get((e.code, "manager"), ("", ""))
                reporting.append(dict(base(e), hr_manager_code="" if hm == "?" else (hm or ""), hr_manager="Not known yet" if hm == "?" else nm(hm),
                                      manager_code=e.manager_code or "", manager=nm(e.manager_code), approved_by=by, approved_on=on,
                                      resigned=bool(e.resigned)))
        hf = e.hr_function_id
        if hf is not None and hf != e.function_id and (hf != -1 or "function" in (e.overrides or [])):
            if infn(e.function_id, hf):
                by, on = when.get((e.code, "function"), ("", ""))
                function.append(dict(base(e), hr_function="Not known yet" if hf == -1 else fns.get(hf, ""), approved_by=by, approved_on=on))
    names = {c: e.name for c, e in emps.items()}
    tbh = []
    pos = {v.id: v.position for v in db.query(models.Vacancy)}
    for v in db.query(models.Vacancy):
        open_ = 0 if v.removed else (v.count or 1) - min(v.filled or 0, v.count or 1)
        if open_ > 0 and infn(v.function_id):
            tbh.append({"id": v.id, "function": fns.get(v.function_id, ""), "position": v.position or "", "grade": v.grade or "", "emp_type": v.emp_type,
                        "open": open_, "count": v.count or 1, "unit": v.unit or "",
                        "reports_to": f"{pos.get(v.parent_id, '')} (vacant)" if v.parent_id else (names.get(v.manager_code, "") or "Function head"),
                        "note": v.note or "", "kind": vac_kind_label(v.kind)})
    tbh.sort(key=lambda r: (r["function"], r["position"]))
    return {"reporting": reporting, "function": function, "added": added, "resigned": resigned, "tbh": tbh,
            "functions": [{"id": i, "name": n} for i, n in sorted(fns.items(), key=lambda kv: kv[1].lower())],
            "hr_unknown": sum(1 for e in emps.values() if e.source == "master" and (e.hr_manager_code == "?" or e.hr_function_id == -1))}


@router.get("/changes")
@cached_json
def changes(function_id: Optional[int] = Query(None), user=Depends(require_emp_changes), db: Session = Depends(get_db)):
    return _data(db, function_id)


@router.get("/changes/export")
def export(function_id: Optional[int] = Query(None), user=Depends(require_emp_changes), db: Session = Depends(get_db)):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    d = _data(db, function_id)
    wb = Workbook()
    wb.remove(wb.active)
    sheets = [("Reporting line changes", d["reporting"], [("Employee code", "code"), ("Name", "name"), ("Grade", "grade"), ("Position", "position"), ("Function", "function"),
                                                         ("Manager as per HR", "hr_manager"), ("HR manager code", "hr_manager_code"), ("Manager now", "manager"),
                                                         ("Manager code now", "manager_code")]),
              ("Function changes", d["function"], [("Employee code", "code"), ("Name", "name"), ("Grade", "grade"), ("Position", "position"),
                                                   ("Function as per HR", "hr_function"), ("Function now", "function")]),
              ("Not in HR record", d["added"], [("Employee code", "code"), ("Name", "name"), ("Grade", "grade"), ("Type", "emp_type"), ("Position", "position"), ("Function", "function"),
                                                ("Unit", "unit"), ("Manager", "manager"), ("Manager code", "manager_code"), ("Added on", "added_at")]),
              ("Marked resigned", d["resigned"], [("Employee code", "code"), ("Name", "name"), ("Grade", "grade"), ("Type", "emp_type"), ("Position", "position"),
                                                  ("Function", "function"), ("Manager", "manager"), ("Resigned on", "resigned_on")]),
              ("To be hired", d["tbh"], [("Function", "function"), ("Position", "position"), ("Vacancy", "kind"), ("Type", "emp_type"), ("Grade", "grade"), ("Open positions", "open"),
                                          ("Reports to", "reports_to"), ("Unit", "unit"), ("Note", "note")])]
    for title, rows, cols in sheets:
        ws = wb.create_sheet(title)
        ws.append([h for h, _ in cols])
        for r in rows:
            ws.append([r.get(k, "") for _, k in cols])
        for i in range(1, len(cols) + 1):
            c = ws.cell(1, i)
            c.font, c.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="00796B")
            ws.column_dimensions[c.column_letter].width = 24 if i > 1 else 14
        ws.freeze_panes = "A2"
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    audit(db, user, "employee_changes_export", str(function_id or "all functions"))
    db.commit()
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="employee_changes_{datetime.now():%Y%m%d_%H%M}.xlsx"'})



# the HR master sheet's columns, used when no sheet has been imported since version 2.12 (the sheet's own are kept at import)
DEFAULT_HEADER = ["N Employee No", "N Employee Name", "N Employee Grade", "N Gender", "N Position Name", "N Job Name", "N Group", "N Function",
                  "Direct Span of Control", "Layers", "Hierarchy Path", "N Division"] + \
                 [f"N-{n} Manager {k}" for n in range(1, 8) for k in ("Number", "Name", "Grade")] + \
                 ["N-7 Manager Number.1", "N-7 Manager Name.1", "N-7 Manager Grade.1", "Comments"]
ROLE = {"n employee no": "code", "n employee name": "name", "n employee grade": "grade", "n gender": "gender", "n position name": "position",
        "n function": "function", "direct span of control": "span", "layers": "layers", "hierarchy path": "path",
        "n group": "group", "n division": "division"}
GENDER = {"m": "Male", "f": "Female"}


@router.get("/changes/master")
def export_master(function_id: Optional[int] = Query(None), user=Depends(require_emp_changes), db: Session = Depends(get_db)):
    """The full employee sheet in the HR master sheet's own layout (every column, in its order), as it is in the portal
    now: working employees, employees marked resigned, employees added (not in the HR record) and the
    positions to be hired. Two columns at the end say what changed (Portal Change) and from what to what (Change Details).
    Changed cells are shaded. Rows without a change keep the HR sheet's values as they were."""
    import re
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from ..security import get_setting
    header = get_setting(db, "hr_sheet_header") or DEFAULT_HEADER
    norm = [re.sub(r"\s+", " ", (h or "").strip().lower()) for h in header]
    col = {}
    for i, h in enumerate(norm):
        if h in ROLE and ROLE[h] not in col:
            col[ROLE[h]] = i
    levels = []   # [(number col, name col, grade col)] for N-1, N-2, ... in the sheet's order
    for i, h in enumerate(norm):
        m = re.match(r"^n-\d+ manager (number|name|grade)", h)
        if not m:
            continue
        if m.group(1) == "number":
            levels.append([i, None, None])
        elif levels:
            levels[-1][1 if m.group(1) == "name" else 2] = i
    fns = {f.id: f.name for f in db.query(models.Function)}
    hrn = {f.id: f.hr_name or f.name for f in db.query(models.Function)}   # the sheet uses HR's function names
    emps = {e.code: e for e in db.query(models.Employee)}
    vacs = {v.id: v for v in db.query(models.Vacancy)}
    W = len(header)

    def hr(e, role):   # the value in the employee's HR row
        r = e.hr_row if e is not None else None
        i = col.get(role) if isinstance(role, str) else role
        return r[i] if r and i is not None and i < len(r) else None

    def own(e, field, role, portal):   # the HR sheet's value, unless changed here (or not in the sheet)
        return portal if (field in (e.overrides or []) or not e.hr_row) else hr(e, role)

    nm = lambda e: own(e, "name", "name", e.name)
    gr = lambda e: own(e, "grade", "grade", e.grade_raw or ("" if e.grade == "Not verified" else e.grade or ""))

    def chain_from(code):
        """[(code, name, grade)] from this manager up: the portal's reporting line, then above the portal's top
        person the line in that person's HR row. Also the number of portal managers in it."""
        out, seen, last = [], set(), None
        while code and code in emps and code not in seen and len(out) < 40:
            seen.add(code)
            x = emps[code]
            out.append((code, nm(x), gr(x)))
            last, code = x, x.manager_code
        inside = len(out)
        if last is not None and last.hr_row:
            if code and hr(last, levels[0][0] if levels else None) != code:
                out.append((code, "", ""))
            else:
                for a, b, c in levels:
                    if hr(last, a):
                        out.append((hr(last, a), hr(last, b) if b is not None else "", hr(last, c) if c is not None else ""))
        elif code:
            out.append((code, "", ""))
        return out, inside

    kids = {}
    for e in emps.values():
        if not e.resigned and e.manager_code:
            kids[e.code] = kids.get(e.code, 0)
            kids[e.manager_code] = kids.get(e.manager_code, 0) + 1

    def hr_line(code):   # the reporting line by the HR sheet's own manager links (within the portal)
        out, seen = [], set()
        while code and code in emps and code not in seen and len(out) < 40:
            seen.add(code)
            out.append(code)
            code = emps[code].hr_manager_code if emps[code].source != "added" else emps[code].manager_code
            if code == "?":
                return None
        return out

    def build(base, name, grade, gender, position, fname, mgr_code, span, extra_top=None, hr_mgr=None):
        """One row in the sheet's layout. base: the HR row to start from (or None)."""
        row = list(base or []) + [None] * W
        row = row[:W]
        chain, inside = chain_from(mgr_code)
        if extra_top:
            chain, inside = extra_top + chain, inside + len(extra_top)
        vals = {"name": name, "grade": grade, "gender": gender, "position": position, "function": fname, "span": span, "layers": inside,
                "path": " -> ".join([name] + [c[1] or c[0] for c in chain[:inside]])}
        for k, v in vals.items():
            if k in col:
                row[col[k]] = v
        if base and hr_line(hr_mgr) == [x[0] for x in chain[:inside]]:
            # nothing changed here along the line (by HR's own manager links): keep the line, layers and path as HR wrote them
            if True:
                for k in ("layers", "path"):
                    if k in col and col[k] < len(base):
                        row[col[k]] = base[col[k]]
                if "span" in col and col["span"] < len(base) and str(base[col["span"]] or 0) == str(span):
                    row[col["span"]] = base[col["span"]]
                return row
        for n, (a, b, c) in enumerate(levels):
            x = chain[n] if n < len(chain) else (None, None, None)
            row[a] = x[0] or None
            if b is not None:
                row[b] = x[1] or None
            if c is not None:
                row[c] = x[2] or None
        return row

    infn = lambda *ids: not function_id or function_id in ids
    rows = []   # (sort key, row, change, details, kind, original row)
    for e in emps.values():
        if not infn(e.function_id, e.hr_function_id):
            continue
        ov = e.overrides or []
        g = own(e, "gender", "gender", GENDER.get(e.gender or "", ""))
        row = build(e.hr_row, nm(e), gr(e), g, own(e, "position", "position", e.position or ""), hrn.get(e.function_id, ""),
                    e.manager_code, kids.get(e.code, 0), hr_mgr=e.hr_manager_code if e.source != "added" else None)
        row[col.get("code", 0)] = e.code
        change, det = [], []
        if e.source == "added":
            change.append("Added")
            det.append(f"Not in HR record; added{' by ' + e.added_by if e.added_by else ''}{' on ' + e.added_at.strftime('%Y-%m-%d') if e.added_at else ''}")
            boss = emps.get(e.manager_code)
            for k in ("group", "division"):   # the same group and division as the manager
                if k in col and row[col[k]] is None and boss is not None:
                    row[col[k]] = hr(boss, k)
        else:
            hm, hf = e.hr_manager_code, e.hr_function_id
            if (hm != "?" and (hm or None) != (e.manager_code or None)) or (hm == "?" and "manager" in ov):
                change.append("Line manager changed")
                was = "not known" if hm == "?" else (f"{hm} {nm(emps[hm])}" if hm in emps else (hm or "none"))
                now = f"{e.manager_code} {nm(emps[e.manager_code])}" if e.manager_code in emps else (e.manager_code or "none")
                det.append(f"Line manager: {was} -> {now}")
            if hf is not None and hf != e.function_id and (hf != -1 or "function" in ov):
                change.append("Function changed")
                det.append(f"Function: {'not known' if hf == -1 else fns.get(hf, '')} -> {fns.get(e.function_id, '')}")
        if e.resigned:
            change.insert(0, "Resigned")
            det.insert(0, f"Resigned{' on ' + e.resigned_on if e.resigned_on else ''}")
        kind = "resigned" if e.resigned else "added" if e.source == "added" else "master"
        key = (0, e.hr_row_no, "") if e.hr_row_no is not None and e.source != "added" else (1, 0, f"{fns.get(e.function_id, '')}|{e.code}")
        rows.append((key, row, change, det, kind, e.hr_row if e.source != "added" else None))
    # positions to be hired: one row for each open position
    depth = {}
    for c in emps:
        n, m = 0, emps[c].manager_code
        while m in emps and n < 40:
            n, m = n + 1, emps[m].manager_code
        depth[c] = n
    head_of = {}
    for e in emps.values():
        if not e.resigned and (e.function_id not in head_of or depth[e.code] < depth[head_of[e.function_id]]):
            head_of[e.function_id] = e.code
    openn = lambda v: 0 if v.removed else (v.count or 1) - min(v.filled or 0, v.count or 1)
    for v in sorted(vacs.values(), key=lambda v: (fns.get(v.function_id, ""), v.position or "")):
        if openn(v) <= 0 or not infn(v.function_id):
            continue
        top, p, start, n = [], v, None, 0
        while p.parent_id in vacs and n < 30:
            n += 1
            pv = vacs[p.parent_id]
            if openn(pv) > 0:
                top.append(("", "To be hired: " + (pv.position or ""), pv.grade or ""))
                p = pv
                continue
            who = [x for x in (pv.filled_log or []) if x.get("code") in emps]
            if who:
                start = who[-1]["code"]
                break
            p = pv
        if start is None:
            start = p.manager_code if p.manager_code in emps else head_of.get(v.function_id)
        for k in range(openn(v)):
            row = build(None, "To be hired", v.grade or "", "", v.position or "", hrn.get(v.function_id, ""), start, 0, extra_top=top)
            row[col.get("code", 0)] = None
            if "comments" in norm:
                row[norm.index("comments")] = v.note or None
            det = f"{v.emp_type}" + (f", position {k + 1} of {openn(v)}" if openn(v) > 1 else "")
            rows.append(((3, 0, f"{fns.get(v.function_id, '')}|{v.position}|{k}"), row, ["To be hired"], [det], "tbh", None))
    rows.sort(key=lambda r: r[0])

    wb = Workbook()
    ws = wb.active
    ws.title = "Employee Layers"
    ws.append(list(header) + ["Portal Change", "Change Details"])
    shade = {"changed": PatternFill("solid", fgColor="FFF2CC"), "added": PatternFill("solid", fgColor="E2EFDA"),
             "resigned": PatternFill("solid", fgColor="F8D7DA"), "tbh": PatternFill("solid", fgColor="FCE4D6")}
    for _, row, change, det, kind, orig in rows:
        ws.append(row + ["; ".join(change) or None, "; ".join(det) or None])
        r = ws.max_row
        if kind in ("added", "resigned", "tbh"):
            for i in range(1, W + 3):
                ws.cell(r, i).fill = shade[kind]
        elif orig and change:
            for i in range(W):
                o = orig[i] if i < len(orig) else None
                if str(o if o is not None else "").strip() != str(row[i] if row[i] is not None else "").strip():
                    ws.cell(r, i + 1).fill = shade["changed"]
            for i in (W + 1, W + 2):
                ws.cell(r, i).fill = shade["changed"]
    for i, h in enumerate(header, 1):
        c = ws.cell(1, i)
        c.font = Font(bold=True)
        ws.column_dimensions[c.column_letter].width = 60 if norm[i - 1] == "hierarchy path" else 16 if norm[i - 1] in ("direct span of control", "layers", "n gender") else 22
    for i in (W + 1, W + 2):
        c = ws.cell(1, i)
        c.font, c.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="00796B")
        ws.column_dimensions[c.column_letter].width = 30 if i == W + 1 else 60
    ws.freeze_panes = "C2"
    ws.auto_filter.ref = f"A1:{ws.cell(1, W + 2).column_letter}{ws.max_row}"
    k = wb.create_sheet("Key")
    for t, f in [("Yellow cell", "changed"), ("Green row", "added"), ("Red row", "resigned"), ("Orange row", "tbh")]:
        k.append([t, {"changed": "Line manager changed or function changed: the changed cells", "added": "Added: working, not in the HR record",
                      "resigned": "Resigned", "tbh": "To be hired (a position, not an employee)"}[f]])
        k.cell(k.max_row, 1).fill = shade[f]
    k.append([])
    k.append(["Portal Change is one of: Line manager changed, Function changed, Resigned, Added, To be hired."])
    k.column_dimensions["A"].width, k.column_dimensions["B"].width = 16, 60
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    audit(db, user, "full_sheet_export", str(function_id or "all functions"))
    db.commit()
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="employee_list_portal_{datetime.now():%Y%m%d_%H%M}.xlsx"'})


@router.post("/reference")
async def hr_reference(file: UploadFile = File(...), apply: bool = Form(False), user=Depends(require_admin), db: Session = Depends(get_db)):
    """Keep the HR master sheet as the reference to compare with, without importing it (changes no employee)."""
    from ..importer import load_hr_reference
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Please choose the HR employee sheet (.xlsx).")
    try:
        out = load_hr_reference(db, await file.read(), apply)
    except ValueError as e:
        db.rollback()
        raise HTTPException(400, str(e))
    if apply:
        audit(db, user, "hr_reference", f"{file.filename}: HR values kept for {out['matched']} employees (nothing else changed)")
        db.commit()
    else:
        db.rollback()
    return out

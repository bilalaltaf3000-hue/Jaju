"""Consistent capitalisation for names and recorded text.

The master sheet and POCs write the same things in many ways ("BILAL ALTAF", "kamran", "KAmrAN";
"LC ISSUANCE CHECKING", "kyc verification"). Names are shown in title case; free text is left as
written when it already mixes cases, and fixed when it is all capitals or all lower case. Short
all-capital words in an all-capital text (LC, KYC, ATM) are kept as acronyms."""
import re

# banking and operations acronyms, written in capitals wherever they appear
ACRONYMS = {"kyc", "aml", "cft", "lc", "lcs", "bg", "mis", "swift", "atm", "atms", "pos", "sbp", "hbl", "hr", "sme", "cnic", "nadra",
            "rtgs", "ibft", "eft", "fx", "ctr", "str", "otc", "adc", "cdm", "som", "eom", "sla", "kpi", "kpis", "mt", "mt103", "mt202",
            "iban", "otp", "ivr", "crm", "cbs", "t24", "pkr", "usd", "fcy", "lcy", "cpu", "ftc", "fte", "poc", "pocs", "coso",
            "ceo", "coo", "cfo", "evp", "svp", "vp", "avp", "pso", "rda", "nrp", "ebp", "edd", "cdd", "pep", "peps", "fatca", "crs",
            "ofac", "uae", "uk", "sop", "sops", "bcp", "ecib", "cib", "ndr"}
SMALL = {"a", "an", "and", "as", "at", "by", "for", "from", "in", "into", "of", "on", "or", "per", "the", "to", "via", "with", "&"}


def _clean(s) -> str:
    return " ".join(str(s or "").split())


def _letters(s):
    return [c for c in s if c.isalpha()]


def _acr(s: str) -> str:
    """Known acronyms in capitals: 'kyc verification' -> 'KYC verification'."""
    return re.sub(r"[A-Za-z][A-Za-z0-9]*", lambda m: m.group(0).upper() if m.group(0).lower() in ACRONYMS else m.group(0), s)


def name_case(s) -> str:
    """'BILAL ALTAF' / 'bilal altaf' / 'KAmrAN' -> 'Bilal Altaf' / 'Kamran'. Hyphen and apostrophe parts too."""
    s = _clean(s)
    if not s:
        return s
    def part(p):
        return p[:1].upper() + p[1:].lower() if p else p
    words = []
    for w in s.split(" "):
        w = "-".join("'".join(part(x) for x in h.split("'")) for h in w.split("-"))
        words.append(w)
    return " ".join(words)


def _all_upper(s):
    L = _letters(s)
    return len(L) > 3 and all(c.isupper() for c in L)


def _all_lower(s):
    L = _letters(s)
    return bool(L) and all(c.islower() for c in L)


def _acronym(w):
    core = re.sub(r"[^A-Za-z]", "", w)
    return 1 <= len(core) <= 3 and core.lower() not in SMALL


def text_case(s) -> str:
    """Sentence case for text written all in capitals; a capital first letter for text all in lower case;
    anything else is kept as written (it already has deliberate capitals)."""
    s = _clean(s)
    if not s:
        return s
    if _all_upper(s):
        out = " ".join(w if _acronym(w) else w.lower() for w in s.split(" "))
    else:
        out = s
    i = next((k for k, c in enumerate(out) if c.isalpha()), None)
    if i is not None and out[i].islower() and (_all_upper(s) or _all_lower(s) or i == 0):
        out = out[:i] + out[i].upper() + out[i + 1:]
    return _acr(out)


def title_case(s) -> str:
    """Positions: 'SENIOR OFFICER - TRADE OPS' -> 'Senior Officer - Trade Ops'; mixed text kept."""
    s = _clean(s)
    if not s or not (_all_upper(s) or _all_lower(s)):
        return _acr(s) if s else s
    up = _all_upper(s)
    words = []
    for k, w in enumerate(s.split(" ")):
        if up and _acronym(w) and len(re.sub(r"[^A-Za-z]", "", w)) <= 2 and w.lower() not in SMALL:
            words.append(w)                     # keep 2-letter acronyms such as HR, IT
        elif k and w.lower() in SMALL:
            words.append(w.lower())
        else:
            words.append(w[:1].upper() + w[1:].lower())
    return _acr(" ".join(words))


def products_case(s) -> str:
    """'lc; GUARANTEE' -> each product tag in text case."""
    if not s:
        return s
    return "; ".join(text_case(x) for x in str(s).split(";") if x.strip())

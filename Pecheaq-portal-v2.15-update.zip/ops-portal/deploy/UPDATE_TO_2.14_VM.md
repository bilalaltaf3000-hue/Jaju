# Updating the VM to version 2.14: Grade Benchmark and Layer 1

Version 2.14 adds the **Grade Benchmark**: the max grade for each level of the structure, shown on the organogram and in a new dashboard section. It also counts **Kamran Zaffar Muggo as Layer 1** everywhere.

- **2.14 contains everything in 2.13 and 2.13.1** (Role Overlap). If they are not installed yet, install this zip instead.
- **Only the portal code changes.** No pip install is needed; vLLM is not touched. The database gets two new columns automatically at start; no data changes.
- About 10 minutes. VM folder: `/data/opt/ops-portal`. Service: `ops-portal`.

---

## What is new

**The model** (at most 5 layers, the Group Head is Layer 1):

Group Head → Division → Department → Unit or Team Leader / Senior Manager / Manager → Others

**Max grade by level**, chosen by the function's permanent headcount (FTE only, not outsourced or FTC):

| Level | Function under 50 | Function 50 or more |
|---|---|---|
| Division | GM I | GM II |
| Department | DGM II | GM I |
| Unit | DGM I | DGM II |
| Team Leader / SM / Manager | SM II | DGM I |
| Others | MA II | SM I |

Below the max: **Room to grow**. At it: **At max**. Above it: **Above max** (an anomaly, with the number of notches). Only permanent staff are assessed; the Group Head is not.

- **Who sees the benchmark:** it is hidden from everyone, administrators included, until the **admin** login ticks **Grade Benchmark** for them (Admin → Users → Edit access). Only the admin login sees that tick, the Structure & Benchmark tab and can change the benchmark.
- **Admin → Structure & Benchmark** (new tab, the admin login only):
  - mark each function as a **Division**, **Department** or **Unit**; its head holds that level;
  - the levels below follow the position in the reporting line: each layer below the head is the next level (Department, Unit, Team Leader); **layer 5 and below is Others**; anyone without reports above layer 5 is the Team Leader / Senior Manager / Manager tier;
  - **Edit** on a function lists everyone in it; change anyone's level, or set it back to "From reporting line". Levels set by hand are kept against the employee number, also after an HR re-import;
  - **Their direct reports** (in Edit): for any manager, choose whether their direct reports are **Team Leaders** or **Others** (or by position). When you set someone to **Unit**, the portal asks this straight away;
  - **Check Untagged**: functions not tagged yet, and levels set by hand;
  - the **max grade table**, the **size threshold (50)** and the **max layers (5)** can be changed and saved.
- **Dashboard → Organogram → Grade Benchmark** button: every card shows its level tag (DIV, DEPT, UNIT, TEAM, OTHER), its grade against the max, and a colour: teal room to grow, blue at max, red above max. A dashed amber card is beyond the max layers. Hover a card for the rule used.
- **Dashboard → Grade Benchmark** (new section): roles assessed, above max, at max, room to grow, people beyond the max layers; a table by function (type, permanent headcount, band, mix, deepest layer / max layers); tabs listing everyone in **Opportunity to grow**, **At Max Grade** and **Above Max Grade** (click a name for the reporting line); the managers at layer 5 or below whose teams sit beyond the max layers. **Download Excel** (logins with download rights).
- **A level set on a manager carries down:** set a manager to Unit and their direct reports become Team Leader tier (or Others at layer 5); set them to Team and their team becomes Others.
- **Role Overlap changes:**
  - **COSO Overview** is now an executive page: one headline (roles to review and the indicative FTE), the four key findings, where the capacity is by function, the cases to look at first, and HR's review progress. The full table by function is under "All functions in detail".
  - **Supervisor comparison** has two tabs: **Common activities** (the supervisor and a report do the same task) and **Unique activities** (only the supervisor does it, with the team's work they oversee).
  - **Volume:** in the supervisor comparison, volume-based and non-volume-based activities are shown apart, with each activity's volume and frequency.
  - **Overseeing is not doing:** the AI is told that managing, overseeing, monitoring or authorising what a report executes is supervision, not the same work, and that checking or approving is maker-checker. Matches on activities the AI labels supervisory are not counted. Run the analysis again to apply the stronger instruction.
  - The supervisors list reads "Direct reports" and "Activities also done by the team: 8 of 11".
- **Layer 1:** the Group Head is now Layer 1 on the dashboard, organogram, reporting line, Excel, PDF and PowerPoint. The structure is the same; every layer number is one higher than before, matching the HR model of max 5 layers.

---

## Install

### 1. Copy the zip to the VM

```
scp ops-portal-v2.14-update.zip YOUR_VM_USER@hblassist.domestic.hbl.com:/tmp/
```

### 2. Back up first (do not skip)

```
sudo systemctl stop ops-portal
STAMP=$(date +%Y%m%d_%H%M)
sudo mkdir -p /data/opt/ops-portal/backups
sudo python3 -c "import sqlite3,sys; s=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); d=sqlite3.connect(sys.argv[1]); s.backup(d); d.close(); s.close(); print('database backed up')" /data/opt/ops-portal/backups/portal_before_2.14_$STAMP.db
sudo tar -czf /data/opt/ops-portal/backups/code_before_2.14_$STAMP.tgz -C /data/opt/ops-portal --exclude backend/venv --exclude backend/data --exclude backups .
sudo python3 -c "import sqlite3,glob; f=sorted(glob.glob('/data/opt/ops-portal/backups/portal_before_2.14_*.db'))[-1]; c=sqlite3.connect(f); print(f); print(c.execute('pragma integrity_check').fetchone()[0], c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities')"
```

The last command prints `ok`, then the employee and activity counts. **Write the two numbers down.**

### 3. Install the new code

```
rm -rf /tmp/ops-update && python3 -m zipfile -e /tmp/ops-portal-v2.14-update.zip /tmp/ops-update
ls /tmp/ops-update/ops-portal/backend/app/benchmark.py && echo "zip OK"
sudo rsync -a --exclude 'backend/data' --exclude 'backend/venv' --exclude 'backups' --exclude 'wheels' /tmp/ops-update/ops-portal/ /data/opt/ops-portal/
```

Without `rsync`:

```
sudo rm -rf /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo cp -r /tmp/ops-update/ops-portal/backend/app /tmp/ops-update/ops-portal/backend/static /data/opt/ops-portal/backend/
sudo cp -r /tmp/ops-update/ops-portal/deploy /data/opt/ops-portal/
```

### 4. Owner and permissions

```
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo chmod 700 /data/opt/ops-portal/backend/data
sudo chmod 600 /data/opt/ops-portal/backend/data/portal.db /data/opt/ops-portal/backend/data/secret.key
sudo chmod -R a+rX /data/opt/ops-portal/backend/app /data/opt/ops-portal/backend/static
sudo chmod 755 /data/opt/ops-portal/backend/venv/bin/*
sudo restorecon -R /data/opt/ops-portal >/dev/null 2>&1 || true
```

### 5. Start and check

```
sudo systemctl start ops-portal
sleep 8
sudo systemctl status ops-portal --no-pager | head -5
sudo journalctl -u ops-portal -n 30 --no-pager
sudo -u opsportal python3 -c "import sqlite3; c=sqlite3.connect('/data/opt/ops-portal/backend/data/portal.db'); print(c.execute('select count(*) from employees').fetchone()[0], 'employees', c.execute('select count(*) from work_items').fetchone()[0], 'activities'); print('org_type' in [r[1] for r in c.execute('pragma table_info(functions)')], 'bm_level' in [r[1] for r in c.execute('pragma table_info(employees)')])"
```

The status shows **active (running)**, the log has no `Traceback`, the counts match step 2, and the last line prints `True True`.

---

## In the browser (one time)

1. Sign in as admin, press **Ctrl+F5** once.
2. **Admin → Structure & Benchmark.** Set the **Type** of every function (Division, Department or Unit). Leave a function "Not tagged" to keep it out.
3. Check the **Max Grade by Level** table (it is filled with the values above) and **Save** if you change anything.
4. Click **Check Untagged**. Review the managers it lists; use **Edit** on a function to change anyone the portal placed wrongly.
5. **Dashboard → Organogram → Grade Benchmark**, and the new **Grade Benchmark** section.

---

## If something goes wrong

```
sudo systemctl stop ops-portal
STAMP=PUT_THE_STAMP_HERE
sudo tar -xzf /data/opt/ops-portal/backups/code_before_2.14_$STAMP.tgz -C /data/opt/ops-portal
sudo chown -R opsportal:opsportal /data/opt/ops-portal
sudo systemctl start ops-portal
```

The database does not need restoring: the two new columns are ignored by the older version.

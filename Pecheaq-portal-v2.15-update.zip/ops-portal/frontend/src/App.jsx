import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { api, filterScope, getToken, setToken, setUnauthorizedHandler } from './api.js'
import { buildOrg, scopeData, typeData, unitData, unitsIn } from './org.js'
import { setPrefs, L, LABELS } from './prefs.js'
const LABEL_KEYS = new Set(LABELS.map(x => x[1]))
import { canChro, canDash, canDecisions, canEmpChanges, canExport, canInput, canRead, canRoleOverlap } from './rights.js'
import ExportDialog from './views/ExportDialog.jsx'
import { Icon, Logo, Toast } from './ui.jsx'
import { FeedbackModal } from './views/Feedback.jsx'
import { DecisionsModal } from './views/Decisions.jsx'
import Login from './views/Login.jsx'
import Dashboard, { FilterBar, UnitFilter } from './views/Dashboard.jsx'
import Capture from './views/Capture.jsx'
import Admin from './views/Admin.jsx'
import Account from './views/Account.jsx'
import EmployeeDetails from './views/EmployeeDetails.jsx'
import ReportingLine from './views/ReportingLine.jsx'
import Regions from './views/Regions.jsx'
import Insights from './views/Insights.jsx'
import HrChanges from './views/HrChanges.jsx'
import RoleOverlap from './views/RoleOverlap.jsx'
import Chro from './views/Chro.jsx'

const NAV = [
  { v: 'dashboard', label: 'Dashboard', show: canDash },
  { v: 'chro', label: 'HR Dashboard', show: canChro },
  { v: 'activities', label: 'Activity Insights', show: canDash },
  { v: 'employees', label: 'Employee Activities', show: canRead },
  { v: 'regions', label: 'Geographical Spread', show: canDash },
  { v: 'hr', label: 'Employee Changes', show: canEmpChanges },
  { v: 'ro', label: 'Role Overlap', show: canRoleOverlap },
  { group: 'Data Input', show: canInput },
  { v: 'capture', label: 'Data Capture', show: canInput },
  { group: 'Administration', show: u => u.is_admin },
  { v: 'admin', label: 'Admin', show: u => u.is_admin },
]
const FILTERED = ['dashboard', 'org', 'activities', 'regions', 'employees']
const home = u => canDash(u) ? 'dashboard' : canChro(u) ? 'chro' : canInput(u) ? 'capture' : canRead(u) ? 'employees' : 'account'
const SEL_KEY = 'ops_portal_functions'
const UNIT_KEY = 'ops_portal_units'
const loadUnits = () => { try { return JSON.parse(localStorage.getItem(UNIT_KEY) || '[]').filter(x => typeof x === 'string') } catch { return [] } }
const loadSel = () => { try { return JSON.parse(localStorage.getItem(SEL_KEY) || '[]').filter(Number.isInteger) } catch { return [] } }

export default function App() {
  const [user, setUser] = useState(null)
  const [booting, setBooting] = useState(!!getToken())
  const [view, setView] = useState('dashboard')
  const [orgData, setOrgData] = useState(null)
  const [lookups, setLookups] = useState(null)
  const [includeFlagged, setIncFlag] = useState(() => { try { return localStorage.getItem('ops_portal_incl') === '1' } catch { return false } })
  const setIncludeFlagged = useCallback(v => { setIncFlag(v); try { localStorage.setItem('ops_portal_incl', v ? '1' : '0') } catch {} }, [])
  const [theme, setTheme] = useState(0)
  const [focus, setFocus] = useState(null)
  const [showExport, setShowExport] = useState(false)
  const [showFb, setShowFb] = useState(false)
  const [showDec, setShowDec] = useState(false)
  const [toast, setToast] = useState({ msg: '', bad: false })
  const [sel, setSelRaw] = useState(loadSel)
  const [lineCode, setLineCode] = useState(null)
  const [selU, setSelURaw] = useState(loadUnits)
  const setSelU = useCallback(v => setSelURaw(s => { const n = typeof v === 'function' ? v(s) : v; try { localStorage.setItem(UNIT_KEY, JSON.stringify(n)) } catch {} ; return n }), [])
  const notify = useCallback((msg, bad = false) => setToast({ msg, bad }), [])
  const setSel = useCallback(v => setSelRaw(s => { const n = typeof v === 'function' ? v(s) : v; try { localStorage.setItem(SEL_KEY, JSON.stringify(n)) } catch {} ; return n }), [])

  const logout = useCallback(() => { setToken(null); setUser(null); setOrgData(null) }, [])
  useEffect(() => { setUnauthorizedHandler(logout) }, [logout])

  useEffect(() => {
    if (!getToken()) return
    api('/api/auth/me').then(u => { setUser(u); setView(home(u)) }).catch(() => {}).finally(() => setBooting(false))
  }, [])

  const loadOrg = useCallback(() => {
    if (!user || !canDash(user)) return
    api('/api/org').then(setOrgData).catch(e => notify(e.message, true))
  }, [user])
  useEffect(() => {
    if (!user) return
    api('/api/lookups').then(lk => { setPrefs(lk); setLookups(lk) }).catch(() => {})
    loadOrg()
  }, [user])

  const senior = lookups?.senior_rank || 68
  const full = useMemo(() => orgData && orgData.people.length ? buildOrg(orgData, includeFlagged, senior) : null, [orgData, includeFlagged, lookups])
  // functions offered in the filter bar: everything the user can see, in ascending order
  const fnList = useMemo(() => full ? full.fstats.map(s => ({ id: full.fids[s.f], name: s.name, hc: s.hc, color: full.FCOL[s.f] })).sort((a, b) => a.name.localeCompare(b.name)) : [], [full])
  const validSel = useMemo(() => sel.filter(id => fnList.some(f => f.id === id)), [sel, fnList])
  // the unit filter: units of the selected functions. Not offered for COSO (all functions): it appears once one or
  // more functions are picked, or straight away for a login that sees a single function
  const byFunction = validSel.length > 0 || fnList.length <= 1
  const unitList = useMemo(() => byFunction ? unitsIn(orgData, validSel) : [], [orgData, validSel.join(), byFunction])
  const validU = useMemo(() => selU.filter(u => unitList.includes(u)), [selU, unitList])
  // a login limited to units: the filter is offered only when it covers more than one unit; the title names its units
  const unitLogin = !!orgData?.unit_scoped
  const showUnits = unitList.length > (unitLogin ? 1 : 0)
  const titleUnits = validU.length ? validU : unitLogin ? unitList : []
  const scoped = useMemo(() => {
    if (!orgData || !orgData.people.length) return null
    let d = validSel.length ? scopeData(orgData, validSel) : orgData
    if (validU.length) d = unitData(d, validU)
    return d
  }, [orgData, validSel.join(), validU.join()])
  const org = useMemo(() => {
    if (!scoped) return null
    return validSel.length || validU.length ? buildOrg(scoped, includeFlagged, senior) : full
  }, [scoped, includeFlagged, full])
  useEffect(() => { setFocus(null) }, [validSel.join(), validU.join()])
  // the same organisation limited to FTE or FTC staff (organogram filters)
  const orgFor = useMemo(() => {
    const cache = {}
    return et => {
      if (!et || !orgData || !orgData.people.length) return org
      if (!cache[et]) cache[et] = buildOrg(typeData(scoped, et), includeFlagged, senior)
      return cache[et]
    }
  }, [org])
  // the same organisation with spans counting only FTE or only FTC direct reports (opportunities filter)
  const orgSpan = useMemo(() => {
    const cache = {}
    return et => {
      if (!et || !orgData || !orgData.people.length) return org
      if (!cache[et]) cache[et] = buildOrg(scoped, includeFlagged, senior, et)
      return cache[et]
    }
  }, [org])

  const go = (v, personIndex, code) => {
    if (code !== undefined && org) { const p = org.byId.get(code); if (p) personIndex = p.i }
    setView(v); if (personIndex !== undefined) setFocus(personIndex); window.scrollTo(0, 0)
  }

  const toggleTheme = () => {
    const r = document.documentElement
    const dark = r.dataset.theme ? r.dataset.theme === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches
    r.dataset.theme = dark ? 'light' : 'dark'
    setTheme(t => t + 1)
  }

  if (booting) return <div className="loading">Loading…</div>
  if (!user) return <Login onLogin={(u) => { setUser(u); setView(home(u)) }} />

  const nav = NAV.filter(n => n.show(user))
  const needsOrg = ['dashboard', 'org', 'regions'].includes(view)
  const showLine = full ? code => setLineCode(code) : null
  filterScope.units = validU   // the unit filter, for the dashboard calls
  const common = { org, orgFor, orgSpan, go, notify, theme, user, lookups, reloadOrg: loadOrg, sel: validSel, units: validU, titleUnits, fnList, includeFlagged, setIncludeFlagged, showLine }
  const showBar = FILTERED.includes(view) && full && (fnList.length > 1 || showUnits)

  return (
    <div className="app">
      <aside>
        <div className="brand logo-brand"><Logo onDark /><b>Operations Services</b></div>
        <nav aria-label="Sections">
          {nav.map((n, i) => n.group ? <div key={i} className="navgroup">{n.group}</div> :
            <button key={i} aria-current={view === n.v} onClick={() => go(n.v)}>{n.v && LABEL_KEYS.has('nav.' + n.v) ? L('nav.' + n.v) : n.label}</button>)}
        </nav>
        <div className="side-foot">
          {canDecisions(user) && <button className="fbbtn" onClick={() => setShowDec(true)}><Icon name="list" size={18} />Recommendations</button>}
          <button className="fbbtn" onClick={() => setShowFb(true)}><Icon name="chat" size={18} />Share Feedback</button>
          <div className="userbox">
            <b>{user.full_name || user.username}</b>
            <div>
              {canExport(user) && <button className="sidebtn" style={{ background: 'var(--teal)', borderColor: 'var(--teal)' }} onClick={() => setShowExport(true)}>Export</button>}
              <button className="sidebtn" onClick={() => go('account')}>Change Password</button>
              <button className="sidebtn" onClick={toggleTheme}>Switch Theme</button>
              <button className="sidebtn" onClick={logout}>Sign Out</button>
            </div>
          </div>
        </div>
      </aside>
      <main>
        {showBar && <div className="fbar-wrap">{fnList.length > 1 && <FilterBar fns={fnList} sel={validSel} setSel={setSel} label={full.groupLabel} scoped={full.scoped} total={full.C.length} />}
          {showUnits && <UnitFilter units={unitList} sel={validU} setSel={setSelU} />}</div>}
        {needsOrg && !org ? (
          <div className="empty" style={{ marginTop: 40 }}>{orgData ? <><b>No employee data yet.</b><br />{user.is_admin ? 'Go to Admin, Import, and upload the employee master sheet.' : 'Ask the admin to import the employee master sheet.'}</> : 'Loading organisation…'}</div>
        ) : <>
          {view === 'dashboard' && <Dashboard {...common} />}
          {view === 'regions' && <Regions {...common} />}
          {view === 'activities' && <Insights {...common} />}
          {view === 'capture' && <Capture {...common} />}
          {view === 'admin' && <Admin {...common} />}
          {view === 'account' && <Account {...common} />}
          {view === 'employees' && <EmployeeDetails {...common} />}
          {view === 'hr' && <HrChanges {...common} />}
          {view === 'ro' && <RoleOverlap {...common} />}
          {view === 'chro' && <Chro {...common} />}
        </>}
      </main>
      {showFb && <FeedbackModal notify={notify} pages={nav.filter(n => n.label).map(n => n.label)} page={nav.find(n => n.v === view)?.label || ''} onClose={() => setShowFb(false)} />}
      {showDec && <DecisionsModal user={user} notify={notify} onClose={() => setShowDec(false)} />}
      {showExport && <ExportDialog user={user} includeFlagged={includeFlagged} sel={validSel} units={validU} fnList={fnList} groupLabel={full?.groupLabel || 'COSO'} notify={notify} close={() => setShowExport(false)} />}
      {lineCode && full && <ReportingLine key={lineCode} code={lineCode} org={full} theme={theme} lookups={lookups} onClose={() => setLineCode(null)} user={user} notify={notify} reloadOrg={loadOrg} />}
      <Toast msg={toast.msg} bad={toast.bad} onDone={() => setToast({ msg: '' })} />
    </div>
  )
}

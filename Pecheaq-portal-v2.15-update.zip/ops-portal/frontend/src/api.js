const KEY = 'ops_portal_token'
let onUnauthorized = () => {}
export const setUnauthorizedHandler = fn => { onUnauthorized = fn }
export const getToken = () => { try { return localStorage.getItem(KEY) } catch { return null } }
export const setToken = t => { try { t ? localStorage.setItem(KEY, t) : localStorage.removeItem(KEY) } catch {} }

export async function api(path, { method = 'GET', body, form } = {}) {
  const headers = {}
  const t = getToken()
  if (t) headers.Authorization = 'Bearer ' + t
  let payload
  if (form) payload = form
  else if (body !== undefined) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body) }
  const res = await fetch(path, { method, headers, body: payload })
  if (res.status === 401 && !path.includes('/auth/login')) { onUnauthorized(); throw new Error('Please sign in again.') }
  const ct = res.headers.get('content-type') || ''
  const data = ct.includes('json') ? await res.json() : await res.text()
  if (!res.ok) throw new Error((data && data.detail) ? (typeof data.detail === 'string' ? data.detail : JSON.stringify(data.detail)) : 'Request failed')
  return data
}

export async function download(path, fallbackName, method = 'GET', body) {
  const headers = { Authorization: 'Bearer ' + getToken() }
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  const res = await fetch(path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) })
  if (!res.ok) { let m = 'Download failed'; try { m = (await res.json()).detail } catch {} ; throw new Error(m) }
  const blob = await res.blob()
  const cd = res.headers.get('content-disposition') || ''
  const m = cd.match(/filename=([^;]+)/)
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = m ? m[1].replace(/"/g, '') : fallbackName
  document.body.appendChild(a); a.click(); a.remove()
  setTimeout(() => URL.revokeObjectURL(a.href), 2000)
}

// The unit filter at the top of the insight pages, added to every dashboard call ("&units=A&units=B").
export const filterScope = { units: [] }
export const unitQS = () => filterScope.units.map(u => '&units=' + encodeURIComponent(u)).join('')

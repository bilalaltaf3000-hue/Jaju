// Export the organogram as one self-contained HTML file: the people on show, a viewer (click to open teams,
// search, zoom), and the layer panel on the left. No portal or internet connection is needed to open it.
import { L } from './prefs.js'

const LNAME = { 1: 'EXCO', 2: 'Function', 3: 'Department', 4: 'Unit', 5: 'Team Lead / SM / Manager', 6: 'Teams · No Direct Reports', 7: 'FTCs only (if necessary)' }

export function exportOrgHtml(O, { root, title, vacancies, fileName }) {
  const R = root || O.ROOT
  const idx = new Map()
  const P = O.P.filter(p => !p.rs)
  P.forEach((p, i) => idx.set(p.i, i))
  const typeOf = p => p.dw ? L('dash.dw') : p.dc ? L('dash.dc') : p.fte ? 'FTE' : 'FTC'
  const people = P.map(p => [p.id, p.n, p.pos || '', p.g && p.g !== '-' ? p.g : '', typeOf(p), p.m >= 0 && idx.has(p.m) ? idx.get(p.m) : -1,
    p.ly || 0, O.F[p.f] || '', O.FCOL ? O.FCOL[p.f] || '#00796B' : '#00796B', O.counted(p) ? 1 : 0, O.FT && O.FT[p.f] ? 1 : 0, p.note || '', p.rp ? (p.dc ? 3 : 2) : p.hs ? 1 : 0])
  const byCode = new Map(P.map((p, i) => [p.id, i]))
  const vac = []
  if (vacancies) {
    const seen = new Set()
    const put = (v, mgr, parent) => {
      if (seen.has(v.id)) return; seen.add(v.id)
      vac.push({ id: v.id, pos: v.position, kind: v.kind === 'replacement' ? 'r' : v.kind === 'pending' ? 'p' : 'n', grade: v.grade || '', type: v.emp_type, open: v.open, mgr, parent,
        reps: (v.reports || []).map(r => byCode.get(r.code)).filter(x => x !== undefined) })
      ;(vacancies.byParent.get(v.id) || []).forEach(k => put(k, -1, v.id))
    }
    vacancies.byMgr.forEach((vs, code) => vs.forEach(v => put(v, byCode.has(code) ? byCode.get(code) : -1, null)))
  }
  const data = { title: title || 'Organogram', root: byCode.get(R.id) ?? 0, people, vac, at: new Date().toLocaleString('en-GB'),
    labels: { repl: L('vac.repl'), nw: L('vac.new'), pend: L('vac.pend'), lnames: LNAME } }
  const html = TEMPLATE.replace('__TITLE__', esc(data.title)).replace('"__DATA__"', JSON.stringify(data).replace(/</g, '\\u003c'))
  const a = document.createElement('a')
  a.href = URL.createObjectURL(new Blob([html], { type: 'text/html' }))
  a.download = (fileName || data.title).replace(/[^\w\- ]+/g, '').trim() + ' organogram.html'
  document.body.appendChild(a); a.click(); a.remove()
  setTimeout(() => URL.revokeObjectURL(a.href), 3000)
}
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]))

const TEMPLATE = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title><style>
:root{--bg:#EEF3F2;--surface:#fff;--ink:#0F2E2A;--ink2:#4A6561;--ink3:#7D9490;--line:#D8E3E1;--teal:#00796B;--deep:#00403A;--soft:#D5EDE9;--amber:#C98A00;--amber-soft:#FBF0D6;--blue:#2A78D6}
*{box-sizing:border-box}html,body{margin:0;height:100%;font-family:Inter,"Segoe UI",Arial,sans-serif;color:var(--ink);background:var(--bg)}
.app{display:grid;grid-template-columns:320px 1fr;height:100vh}
.side{background:var(--surface);border-right:1px solid var(--line);overflow:auto;padding:16px}
.side h1{font-size:17px;margin:0 0 2px;color:var(--deep)}.side .at{font-size:11.5px;color:var(--ink3);margin-bottom:12px}
.side input{width:100%;padding:9px 11px;border:1px solid var(--line);border-radius:9px;font:inherit;font-size:13px}
.hits{margin:6px 0 0;padding:0;list-style:none;max-height:220px;overflow:auto}.hits li{padding:6px 8px;border-radius:7px;cursor:pointer;font-size:13px}.hits li:hover{background:var(--soft)}.hits small{color:var(--ink3);display:block}
.who{margin:14px 0 8px;padding:12px;border-radius:10px;background:var(--soft)}.who b{display:block;font-size:14.5px}.who span{font-size:12.5px;color:var(--ink2)}
.ph{font-size:12px;font-weight:700;color:var(--ink3);text-transform:uppercase;letter-spacing:.05em;margin:14px 0 6px}
.st{display:grid;grid-template-columns:34px 1fr;gap:8px;align-items:center;padding:6px 8px;position:relative;margin-bottom:5px;border-radius:10px;background:color-mix(in srgb,var(--teal) calc(var(--h,0) * 100%),#fff);border:1px solid var(--line)}
.st.on{box-shadow:0 0 0 2px var(--teal) inset}.st.dk b,.st.dk span,.st.dk button{color:#fff!important}.st.dk i{background:#fff!important;color:var(--teal)!important}
.card .nt{position:absolute;left:10px;top:-9px;max-width:186px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;background:#FFF4D6;border:1px solid #C98A00;color:#7A5200;font-size:9.5px;font-weight:700;border-radius:4px;padding:0 5px;line-height:14px}
.st i{font-style:normal;font-weight:800;font-size:12px;color:var(--teal);background:var(--soft);border-radius:8px;height:28px;display:grid;place-items:center}
.st.on i{background:var(--teal);color:#fff}.st.none{opacity:.5}.st.dim i{background:#F1F5F4;color:var(--ink3)}
.st div{min-width:0}.st b{font-size:13px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.st span{font-size:11.5px;color:var(--ink3)}
.st button{all:unset;cursor:pointer;color:var(--teal);font-weight:700;font-size:13px;text-decoration:underline dotted}
.list{margin:6px 0 0;padding:0;list-style:none;border:1px solid var(--line);border-radius:9px;max-height:260px;overflow:auto}.list li{padding:6px 9px;font-size:12.5px;border-bottom:1px solid #EEF3F2;cursor:pointer}.list li:hover{background:var(--soft)}.list small{color:var(--ink3)}
.main{position:relative;overflow:hidden;cursor:grab}.main.drag{cursor:grabbing}
.bar{position:absolute;top:12px;left:12px;z-index:3;display:flex;gap:6px}.bar button{border:1px solid var(--line);background:var(--surface);border-radius:8px;padding:7px 11px;font:inherit;font-size:12.5px;cursor:pointer}.bar button:hover{border-color:var(--teal)}
.legend{position:absolute;bottom:12px;left:12px;z-index:3;display:flex;gap:12px;font-size:11.5px;color:var(--ink2);background:rgba(255,255,255,.9);padding:6px 10px;border-radius:8px}.legend i{display:inline-block;width:11px;height:11px;border-radius:3px;margin-right:4px;vertical-align:-1px;border:1.5px dashed}
#stage{position:absolute;left:0;top:0;transform-origin:0 0}
#lines{position:absolute;left:0;top:0;overflow:visible;pointer-events:none}#lines path{fill:none;stroke:#B9CBC7;stroke-width:1.3}
.card{position:absolute;width:210px;height:72px;background:var(--surface);border:1px solid var(--line);border-radius:9px;padding:8px 10px 8px 14px;cursor:pointer;box-shadow:0 1px 2px rgba(0,0,0,.04)}
.card:hover{border-color:var(--teal)}.card.sel{border:2px solid var(--teal);background:#E9F6F3}.card.line{background:#F6FAF9}
.card.hcs{border:1.5px dashed #C8553D;background:linear-gradient(to top right,transparent calc(50% - 1px),rgba(200,85,61,.7) 50%,transparent calc(50% + 1px)),#FBEDEA}.card.hcs .g{color:#C8553D;font-weight:700}
.card .fb{position:absolute;left:5px;top:8px;bottom:8px;width:3px;border-radius:2px}
.card b{display:block;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.card .p{font-size:11px;color:var(--ink2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.card .g{position:absolute;left:14px;bottom:7px;font-size:10.5px;color:var(--ink3)}.card .n{position:absolute;right:10px;bottom:7px;font-size:11px;font-weight:800;color:var(--teal)}
.card.vac{border:1.5px dashed var(--amber);background:var(--amber-soft);cursor:default}.card.vac .t{font-size:9.5px;font-weight:800;letter-spacing:.05em;text-transform:uppercase;color:var(--amber)}
.card.vac.r{border-color:var(--blue);background:#EAF2FC}.card.vac.r .t{color:var(--blue)}
.card.grp{background:#F6FAF9;border-style:dashed}.card.grp b{font-size:14px}
@media print{.side,.bar,.legend{display:none}.app{grid-template-columns:1fr}}
</style></head><body><div class="app"><aside class="side"><h1 id="ttl"></h1><div class="at" id="at"></div>
<input id="q" placeholder="Find someone: name, code or position" autocomplete="off"><ul class="hits" id="hits"></ul>
<div id="panel"></div></aside>
<div class="main" id="main"><div class="bar"><button id="b-more">Expand One More Level</button><button id="b-col">Collapse</button><button id="b-fit">Fit</button><button id="b-top">Top</button></div>
<div id="stage"><svg id="lines"></svg><div id="cards"></div></div>
<div class="legend"><span><i style="border-color:var(--amber);background:var(--amber-soft)"></i><span id="lg-n"></span></span><span><i style="border-color:var(--blue);background:#EAF2FC"></i><span id="lg-r"></span></span><span>Click a card to open or close a team · drag to move · scroll to zoom</span></div></div></div>
<script>
const D="__DATA__";
const W=210,H=72,GX=18,GY=46,LARGE=40;
const P=D.people.map((a,i)=>({i,id:a[0],n:a[1],pos:a[2],g:a[3],t:a[4],m:a[5],ly:a[6],f:a[7],c:a[8],cnt:a[9],tag:a[10],note:a[11]||'',hs:a[12]>=1,rp:a[12]>=2,pr:a[12]===3,kids:[]}));
const LC={1:'#00403A',2:'#2A78D6',3:'#6250D6',4:'#008C78',5:'#B87400',6:'#E0702F',7:'#7D9490'};
P.forEach(p=>{if(p.m>=0&&p.m!==p.i)P[p.m].kids.push(p)});
const ROOT=P[D.root]||P[0];
const vacBy=new Map(),vacKids=new Map(),under=new Set();
D.vac.forEach(v=>{if(v.parent!=null)(vacKids.get(v.parent)||vacKids.set(v.parent,[]).get(v.parent)).push(v);else if(v.mgr>=0)(vacBy.get(v.mgr)||vacBy.set(v.mgr,[]).get(v.mgr)).push(v);v.reps.forEach(r=>under.add(r))});
const kidsOf=n=>n.kids.filter(k=>!under.has(k.i));
let exp=new Set([ROOT.i]),sel=ROOT,list=null;
const $=id=>document.getElementById(id);
$('ttl').textContent=D.title;$('at').textContent='Exported '+D.at+' · '+P.filter(p=>p.cnt).length.toLocaleString()+' employees';
$('lg-n').textContent=D.labels.nw;$('lg-r').textContent=D.labels.repl;
function build(n){const o={p:n,kids:[]};const vs=vacBy.get(n.i)||[];const nk=kidsOf(n);if(!exp.has(n.i)||(!nk.length&&!vs.length))return o;
 const sub=nk.filter(k=>k.kids.length&&exp.has(k.i)),rest=nk.filter(k=>!sub.includes(k));
 const wt=rest.filter(k=>k.kids.length),nt=rest.filter(k=>!k.kids.length);let items=[...wt,...nt].map(k=>({p:k,kids:[]}));
 if(nt.length>LARGE){items=wt.map(k=>({p:k,kids:[]}));items.push({grp:true,parent:n,rest:nt,kids:[]})}
 const vb=vs.filter(v=>(vacKids.get(v.id)||[]).length||v.reps.length);items.push(...vs.filter(v=>!vb.includes(v)).map(v=>({vac:v,kids:[]})));
 if(items.length){if(!sub.length&&!vb.length&&items.length<=5)o.kids.push(...items);else o.kids.push({col:true,items,kids:[]})}
 o.kids.push(...sub.map(build));o.kids.push(...vb.map(buildVac));return o}
function buildVac(v){const o={vac:v,kids:[]};const ch=vacKids.get(v.id)||[];const es=v.reps.map(i=>P[i]);const eb=es.filter(e=>e.kids.length&&exp.has(e.i));
 const leaves=[...es.filter(e=>!eb.includes(e)).map(e=>({p:e,kids:[]})),...ch.map(k=>({vac:k,kids:[]}))];
 if(leaves.length){if(!eb.length&&leaves.length<=5)o.kids.push(...leaves);else o.kids.push({col:true,items:leaves,kids:[]})}o.kids.push(...eb.map(build));return o}
function lay(o){if(o.col){const n=o.items.length;o.cols=Math.ceil(n/5);o.rows=Math.ceil(n/o.cols);o.w=14+o.cols*W+(o.cols-1)*GX;return}
 o.kids.forEach(lay);if(!o.kids.length){o.w=W;return}if(o.kids.length===1&&o.kids[0].col){o.solo=true;o.w=Math.max(W,7+o.kids[0].w);return}
 o.w=Math.max(W,o.kids.reduce((s,k)=>s+k.w,0)+GX*(o.kids.length-1))}
function placeCol(c,x,y,top,out,ln){c.items.forEach((k,i)=>{const ci=Math.floor(i/c.rows),r=i%c.rows;k.x=x+14+ci*(W+GX);k.y=y+r*(H+12);out.push(k);ln.push('M'+(k.x-7)+','+(k.y+H/2)+'H'+k.x)});
 for(let ci=0;ci<c.cols;ci++){const sx=x+7+ci*(W+GX),last=Math.min(c.rows,c.items.length-ci*c.rows)-1;ln.push('M'+sx+','+top+'V'+(y+last*(H+12)+H/2))}
 if(c.cols>1)ln.push('M'+(x+7)+','+top+'H'+(x+7+(c.cols-1)*(W+GX)))}
function place(o,x,y,out,ln){if(o.solo){o.x=x;o.y=y;out.push(o);placeCol(o.kids[0],x+7,y+H+22,y+H,out,ln);return}
 o.x=x+(o.w-W)/2;o.y=y;out.push(o);if(!o.kids.length)return;const tot=o.kids.reduce((s,k)=>s+k.w,0)+GX*(o.kids.length-1);let cx=x+(o.w-tot)/2;const my=y+H+GY/2;
 o.kids.forEach(k=>{if(k.col){ln.push('M'+(o.x+W/2)+','+(y+H)+'V'+my+'H'+(cx+7));placeCol(k,cx,y+H+GY,my,out,ln)}else{place(k,cx,y+H+GY,out,ln);ln.push('M'+(o.x+W/2)+','+(y+H)+'V'+my+'H'+(k.x+W/2)+'V'+k.y)}cx+=k.w+GX})}
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const chain=p=>{const c=[];let x=p,n=0;while(x&&n++<80){c.unshift(x);x=x.m>=0?P[x.m]:null}return c};
let lastOut=[];
function draw(){const t=build(ROOT);lay(t);const out=[],ln=[];place(t,0,0,out,ln);lastOut=out;
 const line=new Set(chain(sel).map(p=>p.i));
 $('lines').innerHTML=ln.map(d=>'<path d="'+d+'"/>').join('');
 $('cards').innerHTML=out.map((o,k)=>{const s='left:'+o.x+'px;top:'+o.y+'px';
  if(o.vac){const v=o.vac;return '<div class="card vac '+(v.kind==='r'?'r':'')+'" style="'+s+'"><div class="t">'+esc(v.kind==='r'?D.labels.repl:v.kind==='p'?D.labels.pend:D.labels.nw)+(v.open>1?' · '+v.open+' positions':' · to be hired')+'</div><b>'+esc(v.pos)+'</b><div class="g">'+esc([v.type,v.grade].filter(Boolean).join(' · '))+'</div></div>'}
  if(o.grp)return '<div class="card grp" data-grp="'+k+'" style="'+s+'"><b>'+o.rest.length+' more</b><div class="p">'+esc(o.rest.filter(x=>x.t==='FTE').length+' FTE, '+o.rest.filter(x=>x.t!=='FTE').length+' other')+'</div><div class="n">Show list</div></div>';
  const p=o.p,nk=p.kids.length;return '<div class="card'+(p.hs?' hcs':'')+(p===sel?' sel':line.has(p.i)?' line':'')+'" data-i="'+p.i+'" style="'+s+'"><span class="fb" style="background:'+p.c+'"></span>'+(p.note?'<span class="nt" title="'+esc(p.note)+'">'+esc(p.note.length>40?p.note.slice(0,39)+'…':p.note)+'</span>':'')+'<b>'+esc(p.n)+'</b><div class="p">'+esc(p.pos||'-')+'</div><div class="g">'+esc([p.g,p.hs?(p.rp?'Replacement'+(p.pr?' · PR':''):'Surrender'):p.t].filter(Boolean).join(' · '))+'</div>'+(nk?'<div class="n">'+(exp.has(p.i)?'▴ ':'▾ ')+nk+'</div>':'')+'</div>'}).join('');
 const w=Math.max(...out.map(o=>o.x+W)),h=Math.max(...out.map(o=>o.y+H));$('lines').setAttribute('width',w);$('lines').setAttribute('height',h);panel()}
// pan / zoom
let tx=20,ty=60,sc=1;const st=$('stage'),mn=$('main');const apply=()=>st.style.transform='translate('+tx+'px,'+ty+'px) scale('+sc+')';
function fit(){const out=lastOut;if(!out.length)return;const w=Math.max(...out.map(o=>o.x+W)),h=Math.max(...out.map(o=>o.y+H));const r=mn.getBoundingClientRect();sc=Math.min(1.2,(r.width-40)/w,(r.height-110)/h);sc=Math.max(.15,sc);tx=(r.width-w*sc)/2;ty=60;apply()}
function focusCard(i){const o=lastOut.find(o=>o.p&&o.p.i===i);if(!o)return;const r=mn.getBoundingClientRect();if(sc<.6)sc=.85;tx=r.width/2-(o.x+W/2)*sc;ty=r.height/2-(o.y+H/2)*sc;apply()}
mn.addEventListener('wheel',e=>{e.preventDefault();const r=mn.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,k=Math.exp(-e.deltaY*.0015),ns=Math.min(2.2,Math.max(.12,sc*k));tx=mx-(mx-tx)*ns/sc;ty=my-(my-ty)*ns/sc;sc=ns;apply()},{passive:false});
let dr=null;mn.addEventListener('mousedown',e=>{if(e.target.closest('.bar'))return;dr={x:e.clientX,y:e.clientY,tx,ty,moved:false};mn.classList.add('drag')});
window.addEventListener('mousemove',e=>{if(!dr)return;const dx=e.clientX-dr.x,dy=e.clientY-dr.y;if(Math.abs(dx)+Math.abs(dy)>4)dr.moved=true;tx=dr.tx+dx;ty=dr.ty+dy;apply()});
window.addEventListener('mouseup',e=>{if(!dr)return;const was=dr.moved;dr=null;mn.classList.remove('drag');if(was)return;
 const c=e.target.closest('.card');if(!c)return;if(c.dataset.grp!==undefined){const o=lastOut[+c.dataset.grp];list={title:o.parent.n+': other direct reports',ps:o.rest};panel();return}
 if(c.dataset.i===undefined)return;const p=P[+c.dataset.i];if(sel===p&&p.kids.length){exp.has(p.i)?exp.delete(p.i):exp.add(p.i)}else{sel=p;if(p.kids.length)exp.add(p.i)}list=null;draw()});
function openTo(p){chain(p).forEach(x=>exp.add(x.i));sel=p;list=null;draw();setTimeout(()=>focusCard(p.i),0)}
$('b-more').onclick=()=>{const add=[];const walk=o=>{if(o.grp||o.vac)return;if(o.col){o.items.forEach(walk);return}if(exp.has(o.p.i))o.kids.forEach(walk);else if(o.p.kids.length)add.push(o.p.i)};walk(build(ROOT));add.forEach(i=>exp.add(i));draw();fit()};
$('b-col').onclick=()=>{exp=new Set(chain(sel).map(p=>p.i));draw();fit()};$('b-fit').onclick=fit;$('b-top').onclick=()=>{sel=ROOT;exp=new Set([ROOT.i]);list=null;draw();fit()};
// search
$('q').oninput=e=>{const q=e.target.value.trim().toLowerCase();if(q.length<2){$('hits').innerHTML='';return}
 const hs=P.filter(p=>(p.n+' '+p.id+' '+p.pos).toLowerCase().includes(q)).slice(0,30);
 $('hits').innerHTML=hs.map(p=>'<li data-i="'+p.i+'">'+esc(p.n)+'<small>'+esc([p.pos,p.id,p.f].filter(Boolean).join(' · '))+'</small></li>').join('')||'<li>No one matches.</li>'};
$('hits').onclick=e=>{const li=e.target.closest('li[data-i]');if(!li)return;$('hits').innerHTML='';$('q').value='';openTo(P[+li.dataset.i])};
// the layer panel
function panel(){const p=sel,ch=chain(p),at={};ch.forEach(c=>{if(c.ly>0&&!at[c.ly])at[c.ly]=c});
 const below={};const stack=[...p.kids];while(stack.length){const k=stack.pop();if(k.cnt&&k.ly>0){const b=below[k.ly]||(below[k.ly]={n:0,t:{},ps:[]});b.n++;b.ps.push(k);b.t[k.t]=(b.t[k.t]||0)+1}stack.push(...k.kids)}
 const deep=Math.max(p.ly||1,...Object.keys(below).map(Number));const bmx=Math.max(1,...Object.values(below).map(b=>b.n));const last=Math.max(p.tag?7:0,deep);
 let h='<div class="who"><b>'+esc(p.n)+'</b><span>'+esc([p.pos,p.g,p.t].filter(Boolean).join(' · '))+'</span><br><span>'+esc(p.f)+' · Layer '+(p.ly||'?')+(p.kids.length?' · '+p.kids.length+' direct reports':'')+'</span></div>';
 h+='<div class="ph">Layers of the reporting line</div>';
 for(let l=1;l<=last;l++){const c=at[l],un=l>(p.ly||0),b=below[l];const name=p.tag?D.labels.lnames[l]:'Layer '+l;
  const hh=un&&b?0.12+0.78*b.n/bmx:(!un&&c?0.12:0);h+='<div style="--h:'+hh+'" class="st'+(hh>0.6?' dk':'')+(l===p.ly?' on':'')+(un?' dim':'')+((!un&&!c)||(un&&!b)?' none':'')+'"><i>L'+l+'</i><div>';
  if(!un)h+=c?(c===p?'<b>'+esc(c.n)+'</b>':'<b><button data-go="'+c.i+'">'+esc(c.n)+'</button></b>'):'<b>–</b>';
  else h+=b?'<b><button data-lay="'+l+'">'+b.n+(b.n===1?' person':' people')+'</button></b>':'<b>–</b>';
  h+='<span>'+esc(name)+(!un&&c&&c.g?' · '+esc(c.g):'')+(un&&b?' · '+Object.entries(b.t).map(([k,v])=>v+' '+k).join(', '):'')+'</span></div></div>'}
 if(list)h+='<div class="ph">'+esc(list.title)+' ('+list.ps.length+')</div><ul class="list">'+list.ps.slice(0,600).map(x=>'<li data-go="'+x.i+'"><b>'+esc(x.n)+'</b> <small>'+esc([x.pos,x.g,x.t].filter(Boolean).join(' · '))+'</small></li>').join('')+'</ul>';
 $('panel').innerHTML=h;$('panel').querySelectorAll('[data-go]').forEach(el=>el.onclick=()=>openTo(P[+el.dataset.go]));
 $('panel').querySelectorAll('[data-lay]').forEach(el=>el.onclick=()=>{const l=+el.dataset.lay;list={title:p.n+"'s team: Layer "+l,ps:below[l].ps};panel()})}
draw();fit();
</script></body></html>`

// What a signed-in user may do, derived from /api/auth/me
export const canDash = u => !!u && (u.is_admin || (u.view_functions || []).length > 0)
export const canInput = u => !!u && (u.is_admin || (u.input_functions || []).length > 0)
export const canRead = u => canDash(u) || canInput(u)
export const canExport = u => !!u && (u.is_admin || u.can_export)
export const canDecisions = u => !!u && (u.is_admin || u.can_decisions)
export const canEmpChanges = u => !!u && (u.is_admin || u.can_emp_changes)
export const canLayers = u => !!u && (u.is_admin || u.can_layers)
export const canSummary = u => !!u && (u.is_admin || u.can_summary)
export const canBench = u => !!u && !!u.can_benchmark   // hidden from admins too unless the "admin" login ticked it
export const canChro = u => !!u && !!u.can_chro   // given by the "admin" login only
export const canRoleOverlap = u => !!u && (u.is_admin || u.can_role_overlap)
export function accessLabel(u) {
  if (u.is_admin) return 'Administrator'
  const parts = []
  const inp = u.input_functions || []
  if (inp.length) parts.push(inp.length === 1 ? `Input: ${inp[0].name}` : `Input: ${inp.length} functions`)
  if (u.sees_everything) parts.push('Dashboards: whole organisation')
  else if ((u.view_functions || []).length) parts.push(u.view_functions.length === 1 ? `Dashboards: ${u.view_functions[0].name}` : `Dashboards: ${u.view_functions.length} functions`)
  return parts.join(' · ') || 'No access'
}

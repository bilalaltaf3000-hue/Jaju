import React, { useEffect, useState } from 'react'
import VacanciesTab from './AdminVacancies.jsx'
import { api, download } from '../api.js'
import { fmt } from '../org.js'
import { EditField, Modal, Table } from '../ui.jsx'
import { EmployeesTab, TransferTab } from './AdminStaff.jsx'
import { prefs, LABELS } from '../prefs.js'
import { FeedbackAdmin } from './Feedback.jsx'
import CategoryReview from './CategoryReview.jsx'
import { ReferenceModal } from './HrChanges.jsx'
import { AiServerTab } from './RoleOverlap.jsx'
import { BenchmarkAdminTab } from './Benchmark.jsx'
import { TYPE_KEYS } from '../ui.jsx'
import { SegAdminTab } from './Segments.jsx'
import { CurrentManagersTab } from './Chro.jsx'

const TABS = ['Import', 'Capture Progress', 'Employees', 'Activity Categories', 'Data Transfer', 'Users', 'Employees and Flags', 'Lists', 'Data Capture Fields', 'Settings', 'Labels', 'Feedback', 'Audit Log', 'Vacant Positions', 'AI Server', 'Staff Segmentation', 'Structure & Benchmark', 'Current State Line Managers']

export default function Admin(props) {
  const [tab, setTab] = useState(0)
  return <section className="view on">
    <h1>Admin</h1>
    <p className="lede">Import the employee master sheet, track data capture, edit employees, move data between installations, manage logins and approve requests from functions.</p>
    <div className="tabs">{TABS.map((t, i) => t === 'Structure & Benchmark' && !props.user?.can_bm_edit ? null : <button key={t} aria-current={tab === i} onClick={() => setTab(i)}>{t}</button>)}</div>
    {tab === 0 && <ImportTab {...props} />}
    {tab === 1 && <ProgressTab {...props} />}
    {tab === 2 && <EmployeesTab {...props} />}
    {tab === 3 && <CategoryReview {...props} />}
    {tab === 4 && <TransferTab {...props} />}
    {tab === 5 && <UsersTab {...props} />}
    {tab === 6 && <PeopleTab {...props} />}
    {tab === 7 && <ListsTab {...props} />}
    {tab === 8 && <CaptureFields {...props} />}
    {tab === 9 && <SettingsTab {...props} />}
    {tab === 10 && <LabelsTab {...props} />}
    {tab === 11 && <><h2 className="rv-h2" style={{ marginTop: 0 }}>Requests from Data Capture</h2><RetagTab {...props} /><h2 className="rv-h2">Feedback and Employee Changes</h2><FeedbackAdmin {...props} /></>}
    {tab === 12 && <AuditTab {...props} />}
    {tab === 13 && <VacanciesTab {...props} />}
    {tab === 14 && <AiServerTab {...props} />}
    {tab === 15 && <SegAdminTab {...props} />}
    {tab === 16 && props.user?.can_bm_edit && <BenchmarkAdminTab {...props} />}
    {tab === 17 && <CurrentManagersTab {...props} />}
  </section>
}

function ImportTab({ notify, reloadOrg }) {
  const [refOpen, setRefOpen] = useState(false)
  const [rep, setRep] = useState(null)
  const [busy, setBusy] = useState(false)
  useEffect(() => { api('/api/admin/import-report').then(setRep).catch(() => {}) }, [])
  const upload = async e => {
    const f = e.target.files[0]; if (!f) return
    const fd = new FormData(); fd.append('file', f); setBusy(true)
    try { const r = await api('/api/admin/import', { method: 'POST', form: fd }); setRep(r); notify(`Imported ${fmt(r.rows)} employees.`); reloadOrg() }
    catch (ex) { notify(ex.message, true) } finally { setBusy(false); e.target.value = '' }
  }
  return <div className="grid g2">
    <div className="panel"><h2>Upload Employee Master Sheet</h2>
      <p className="sub">Excel (.xlsx), first sheet, with columns N Employee No, N Employee Name, N Employee Grade, N Function and N-1 Manager Number. N Gender, N Position Name and Layers are used if present, and a region column (Region, Location or City) fills in each employee's region. Re-importing updates existing employees and keeps their recorded activities, regions set by functions, flags and employees added by functions. Employees no longer in the sheet are removed with their activities.</p>
      <label className="btn pri" style={{ display: 'inline-block' }}>{busy ? 'Importing…' : 'Choose file and import'}<input type="file" accept=".xlsx,.xlsm" onChange={upload} disabled={busy} style={{ display: 'none' }} /></label>
      <h3 style={{ marginTop: 22 }}>Load HR Sheet for Reference</h3>
      <p className="sub">Not an import: reads HR's manager, function and full row for each employee already in the portal, for Employee Changes and its Full Export. No employee is added, removed or changed. Needed once, for changes made before version 2.12.</p>
      <button className="btn" onClick={() => setRefOpen(true)}>Load HR Sheet (Reference)</button>
      {refOpen && <ReferenceModal notify={notify} onClose={() => setRefOpen(false)} onDone={() => {}} />}
    </div>
    <div className="panel"><h2>Last Import</h2>
      {rep && rep.rows ? <div className="checks">
        {[`${fmt(rep.rows)} employees (${fmt(rep.fte)} FTE, ${fmt(rep.ftc)} FTC) on ${new Date(rep.at).toLocaleString()} by ${rep.by}. ${rep.created} new, ${rep.updated} updated, ${rep.removed} removed.`,
          `Top of the organisation: ${rep.root_name} (${rep.root_code}). Change it in Settings if needed.`,
          `${rep.repeated_chain_count} employees had a manager repeated in their chain${rep.repeated_chain_count ? ` (${rep.repeated_chain_managers.join(', ')})` : ''}. Ignored: hierarchy uses N-1 only.`,
          `The sheet's Layers column differed from the reporting lines for ${rep.layer_diff} employees. The portal uses its own calculation.`,
          rep.numeric_manager_fixed ? `${rep.numeric_manager_fixed} manager codes stored as numbers were matched to text codes.` : null,
          rep.self_report?.length ? `${rep.self_report.length} employees were listed as their own manager: ${rep.self_report.join(', ')}.` : null,
          rep.cycles?.length ? `${rep.cycles.length} circular reporting loops broken: ${rep.cycles.map(c => c.join(' → ')).join('; ')}.` : null,
          rep.orphans?.length ? `${rep.orphans.length} people have a manager code not found in the sheet: ${rep.orphans.slice(0, 10).map(o => `${o.name} (${o.code} → ${o.manager})`).join(', ')}.` : null,
          rep.duplicate_code_count ? `${rep.duplicate_code_count} duplicate employee codes; first row used: ${rep.duplicate_codes.slice(0, 10).join(', ')}.` : null,
          rep.added_by_functions_kept ? `${rep.added_by_functions_kept} employees added by functions were kept.` : null,
          rep.admin_changes_kept ? `${rep.admin_changes_kept} employees changed by the admin kept their edited details.` : null,
          rep.region_column ? `Regions read from the "${rep.region_column}" column for ${fmt(rep.with_region)} employees.` : 'No region column in the sheet: functions set regions in data capture.',
        ].filter(Boolean).map((c, i) => <div key={i} className="check"><i style={{ background: 'var(--teal)' }}>✓</i><span>{c}</span></div>)}
      </div> : <p className="sub">No import yet.</p>}
    </div>
  </div>
}

const TEMPLATES = [
  { k: 'poc', t: 'Function POC', d: 'Fills in one function and sees its dashboards', set: f => ({ ...f, is_admin: false, view_mode: 'input', can_export: false }) },
  { k: 'head', t: 'Function head', d: 'Fills in and sees their functions, can export', set: f => ({ ...f, is_admin: false, view_mode: 'input', can_export: true }) },
  { k: 'hr', t: 'HR / executive', d: 'Sees every dashboard, no input, can export', set: f => ({ ...f, is_admin: false, input_functions: [], view_mode: 'all', can_export: true, can_decisions: true, can_emp_changes: true, can_role_overlap: true }) },
  { k: 'hronly', t: 'HR Dashboard only', d: 'Sees only the HR Dashboard; no benchmark, no other pages', set: f => ({ ...f, is_admin: false, input_functions: [], view_mode: 'none', view_functions: [], can_export: false, can_decisions: false, can_emp_changes: false, can_role_overlap: false, can_layers: false, can_layer_edit: false, can_summary: false, can_bm_view: false, can_benchmark: false, can_bm_edit: false, can_chro: true, can_hr_bm: false, chro_mode: f.chro_mode && f.chro_mode !== 'view' ? f.chro_mode : 'all' }) },
  { k: 'admin', t: 'Administrator', d: 'Everything, including this Admin page', set: f => ({ ...f, is_admin: true, view_mode: 'all', can_export: true }) },
]
const VIEW = [['none', 'No dashboards'], ['input', 'Same functions as input'], ['selected', 'Selected functions'], ['all', 'Whole organisation']]
const blank = { username: '', full_name: '', is_admin: false, input_functions: [], view_mode: 'input', view_functions: [], view_units: [], can_export: false, can_decisions: false, can_emp_changes: false, can_role_overlap: false, can_benchmark: false, can_bm_view: false, can_chro: false, can_hr_bm: false, chro_mode: 'view', chro_functions: [], can_summary: false, can_bm_edit: false, can_layers: false, can_layer_edit: false }

function FnPicker({ fns, value, onChange, disabled }) {
  const [q, setQ] = useState('')
  const sel = new Set(value)
  const list = fns.filter(f => !q || f.name.toLowerCase().includes(q.toLowerCase()))
  return <div style={{ opacity: disabled ? 0.5 : 1 }}>
    <div className="kvline" style={{ marginBottom: 6 }}><input className="inp" placeholder="Filter functions" value={q} onChange={e => setQ(e.target.value)} disabled={disabled} style={{ flex: 1 }} />
      <button type="button" className="btn" disabled={disabled} onClick={() => onChange(fns.map(f => f.id))}>All</button><button type="button" className="btn" disabled={disabled} onClick={() => onChange([])}>None</button></div>
    <div className="scroll" style={{ maxHeight: 190, border: '1px solid var(--line)', borderRadius: 8, background: 'var(--surface)' }}>
      {list.map(f => <label key={f.id} style={{ display: 'flex', gap: 8, padding: '6px 10px', fontSize: 13, borderBottom: '1px solid var(--line)', cursor: disabled ? 'default' : 'pointer' }}>
        <input type="checkbox" disabled={disabled} checked={sel.has(f.id)} onChange={() => onChange(sel.has(f.id) ? value.filter(x => x !== f.id) : [...value, f.id])} />
        <span style={{ flex: 1 }}>{f.name}</span><span className="formula">{f.headcount}</span></label>)}
    </div></div>
}

function Preview({ f, fns }) {
  const name = id => fns.find(x => x.id === id)?.name
  const inp = f.is_admin ? fns.map(x => x.id) : f.input_functions
  const view = f.is_admin || f.view_mode === 'all' ? 'all' : f.view_mode === 'input' ? inp : f.view_mode === 'selected' ? f.view_functions : []
  const pages = []
  if (view === 'all' || view.length) pages.push('Dashboard', 'Organogram explorer')
  if (view === 'all' || view.length || inp.length) pages.push('Employee activities')
  if (inp.length) pages.push('Data capture')
  if (f.is_admin) pages.push('Admin')
  const scope = view === 'all' ? 'the whole organisation' : view.length ? view.map(name).join(', ') : null
  return <div className="msg ok" style={{ marginTop: 0 }}>
    <b>What this person will see</b>
    <div style={{ marginTop: 6 }}>{pages.length ? pages.join(' · ') : 'Nothing yet. Give input or dashboard rights.'}</div>
    <div className="formula" style={{ marginTop: 6 }}>
      {inp.length ? `Can fill in: ${f.is_admin ? 'every function' : inp.map(name).join(', ')}. ` : 'No data entry. '}
      {scope ? `Dashboards for ${scope}. ` : 'No dashboards. '}{f.can_export || f.is_admin ? 'Can export PDF, PowerPoint, HTML and Excel.' : 'Cannot export.'}</div>
  </div>
}

function UserEditor({ fns, units = {}, initial, onSave, onCancel, isSuper }) {
  const [f, setF] = useState({ ...blank, ...initial })
  const isNew = !initial?.id
  const set = (k, v) => setF(s => ({ ...s, [k]: v }))
  return <div className="panel" style={{ marginBottom: 18, borderColor: 'var(--teal)' }}>
    <div className="rhead"><h2>{isNew ? 'Create a login' : `Access for ${initial.username}`}</h2><button className="btn" onClick={onCancel}>Close</button></div>
    <p className="sub">Start from a template, then adjust.</p>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(170px,1fr))', gap: 8, marginBottom: 16 }}>
      {TEMPLATES.map(tp => <button key={tp.k} type="button" onClick={() => setF(tp.set)} style={{ all: 'unset', cursor: 'pointer', border: '1px solid var(--line)', borderRadius: 10, padding: '10px 12px', background: 'var(--surface-2)' }}>
        <b style={{ fontSize: 13.5 }}>{tp.t}</b><div className="formula">{tp.d}</div></button>)}
    </div>
    <div className="grid g2" style={{ gap: 16 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {isNew && <label className="formula">Username<input className="inp" style={{ width: '100%', marginTop: 4 }} value={f.username} onChange={e => set('username', e.target.value)} placeholder="e.g. poc.collections" /></label>}
        <label className="formula">Full name<input className="inp" style={{ width: '100%', marginTop: 4 }} value={f.full_name} onChange={e => set('full_name', e.target.value)} /></label>
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={f.is_admin} onChange={e => set('is_admin', e.target.checked)} /><span><b>Administrator</b><br /><span className="formula">Full access to everything, including logins and imports.</span></span></label>
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={f.can_export || f.is_admin} disabled={f.is_admin} onChange={e => set('can_export', e.target.checked)} /><span><b>Can export</b><br /><span className="formula">PDF, PowerPoint, HTML and Excel, limited to what they can see.</span></span></label>
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={f.can_decisions || f.is_admin} disabled={f.is_admin} onChange={e => set('can_decisions', e.target.checked)} /><span><b>Recommendations</b><br /><span className="formula">Sees and adds recommendations for each function.</span></span></label>
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={f.can_emp_changes || f.is_admin} disabled={f.is_admin} onChange={e => set('can_emp_changes', e.target.checked)} /><span><b>Employee Changes</b><br /><span className="formula">Sees the Employee Changes page (differences from the HR record) and its downloads.</span></span></label>
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={f.can_role_overlap || f.is_admin} disabled={f.is_admin} onChange={e => set('can_role_overlap', e.target.checked)} /><span><b>Role Overlap</b><br /><span className="formula">Sees the AI's Role Overlap results and reviews the cases. Only the admin runs the AI.</span></span></label>
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={f.can_layers || f.is_admin} disabled={f.is_admin} onChange={e => set('can_layers', e.target.checked)} /><span><b>Layer Panel</b><br /><span className="formula">Sees the Layers button on the organogram and the layer panel in the reporting line chart.</span></span></label>
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={!!f.can_layer_edit} disabled={!(f.can_layers || f.is_admin)} onChange={e => set('can_layer_edit', e.target.checked)} /><span><b>Edit in Layer Panel</b><br /><span className="formula">Can switch the panel to Edit and set a person's level (Function, Department, Unit, Team Lead, Teams) and what their direct reports are. Needs Layer Panel.</span></span></label>
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={!!f.can_chro || f.username === 'admin'} disabled={f.username === 'admin'} onChange={e => set('can_chro', e.target.checked)} /><span><b>HR Dashboard</b><br /><span className="formula">Sees the HR Dashboard: the restructure As Is against To Be (layers, spans, functions, single-report managers, taggings, headcount saved), the organogram and the PDF report. Administrators with it can also correct the As Is.</span></span></label>
        {!!f.can_chro && !f.is_admin && f.username !== 'admin' && <div className="fld" style={{ marginLeft: 26 }}><span className="fl">HR Dashboard shows</span>
          <select className="inp" value={f.chro_mode || 'view'} onChange={e => set('chro_mode', e.target.value)} style={{ maxWidth: 360 }}>
            <option value="view">The functions of their dashboard view</option><option value="selected">Selected functions only</option><option value="all">All functions</option></select>
          {(f.chro_mode || 'view') === 'selected' && <div style={{ marginTop: 8 }}><FnPicker fns={fns} value={f.chro_functions || []} onChange={v => set('chro_functions', v)} /></div>}
          <span className="formula">They see only these functions on the HR Dashboard: cards, organogram, lists and the PDF. Administrators always see all.</span></div>}
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={!!f.can_hr_bm || f.username === 'admin'} disabled={f.username === 'admin' || !(f.can_chro)} onChange={e => set('can_hr_bm', e.target.checked)} /><span><b>Benchmark on HR Dashboard</b><br /><span className="formula">Also sees Below / At Max / Above Benchmark on the HR Dashboard and can show the max grade on the To Be organogram. Needs HR Dashboard.</span></span></label>
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={!!f.can_bm_view || f.username === 'admin'} disabled={f.username === 'admin'} onChange={e => set('can_bm_view', e.target.checked)} /><span><b>View Benchmark</b><br /><span className="formula">Sees the View Benchmark button at the top of the dashboard: the framework of levels and max grades only, no one's grades.</span></span></label>
        <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={f.can_summary || f.is_admin} disabled={f.is_admin} onChange={e => set('can_summary', e.target.checked)} /><span><b>Work Summary</b><br /><span className="formula">Sees the summary button on organogram cards: the AI's summary of each employee's recorded work.</span></span></label>
        {isSuper && <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={!!f.can_benchmark || f.username === 'admin'} disabled={f.username === 'admin'} onChange={e => set('can_benchmark', e.target.checked)} /><span><b>Grade Benchmark</b><br /><span className="formula">Sees the grade benchmark on the dashboard and organogram. Hidden from everyone else, administrators included. Only the admin login can give it.</span></span></label>}
        {isSuper && <label style={{ display: 'flex', gap: 8, fontSize: 13.5 }}><input type="checkbox" checked={!!f.can_bm_edit || f.username === 'admin'} disabled={f.username === 'admin' || !f.is_admin || !(f.can_benchmark || f.username === 'admin')} onChange={e => set('can_bm_edit', e.target.checked)} /><span><b>Change Grade Benchmark</b><br /><span className="formula">Opens Admin, Structure & Benchmark for this administrator: function types, levels (Unit, Team Lead...) and the grade bands. Needs Administrator and Grade Benchmark ticked.</span></span></label>}
        <div><b style={{ fontSize: 13.5 }}>Dashboards</b>
          <div className="chips" style={{ marginTop: 6 }}>{VIEW.map(([k, l]) => <button key={k} type="button" className="chip" disabled={f.is_admin} aria-pressed={(f.is_admin ? 'all' : f.view_mode) === k} onClick={() => set('view_mode', k)}>{l}</button>)}</div>
          {f.view_mode === 'selected' && !f.is_admin && <div style={{ marginTop: 8 }}><FnPicker fns={fns} value={f.view_functions} onChange={v => set('view_functions', v)} /></div>}
          {f.view_mode === 'selected' && !f.is_admin && (f.view_functions || []).some(id => (units[id] || []).length) && <div className="unitpick">
            <b style={{ fontSize: 13 }}>Units (optional)</b><div className="formula">Pick units to limit a function to them. A function with no unit picked is seen whole.</div>
            {(f.view_functions || []).filter(id => (units[id] || []).length).map(id => <div key={id} style={{ marginTop: 8 }}><div className="formula" style={{ fontWeight: 650 }}>{fns.find(x => x.id === id)?.name}</div>
              <div className="chips" style={{ marginTop: 4 }}>{units[id].map(u => { const k = `${id}|${u}`, on = (f.view_units || []).includes(k)
                return <button key={k} type="button" className="chip" aria-pressed={on} onClick={() => set('view_units', on ? f.view_units.filter(x => x !== k) : [...(f.view_units || []), k])}>{u}</button> })}</div></div>)}
          </div>}
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <div><b style={{ fontSize: 13.5 }}>Input rights</b><div className="formula" style={{ marginBottom: 6 }}>Functions this person can fill in: employee regions and activities.</div>
          <FnPicker fns={fns} value={f.is_admin ? fns.map(x => x.id) : f.input_functions} disabled={f.is_admin} onChange={v => set('input_functions', v)} /></div>
        <Preview f={f} fns={fns} />
      </div>
    </div>
    <div className="row-actions" style={{ marginTop: 16 }}><button className="btn pri" onClick={() => onSave(f)}>{isNew ? 'Create login' : 'Save access'}</button><button className="btn" onClick={onCancel}>Cancel</button></div>
  </div>
}

function UsersTab({ notify, user }) {
  const [users, setUsers] = useState([])
  const [fns, setFns] = useState([])
  const [edit, setEdit] = useState(null)
  const [shown, setShown] = useState(null)
  const [q, setQ] = useState('')
  const [units, setUnits] = useState({})
  const load = () => api('/api/admin/users').then(setUsers).catch(e => notify(e.message, true))
  useEffect(() => { load(); api('/api/admin/function-units').then(setUnits).catch(() => {}); api('/api/capture/functions').then(r => setFns([...r].sort((a, b) => a.name.localeCompare(b.name)))).catch(() => {}) }, [])
  const fname = id => fns.find(f => f.id === id)?.name || '?'
  const save = async f => {
    try {
      if (!f.id) { const r = await api('/api/admin/users', { method: 'POST', body: f }); setShown(r) }
      else { await api(`/api/admin/users/${f.id}`, { method: 'PATCH', body: { full_name: f.full_name, is_admin: f.is_admin, input_functions: f.input_functions, view_mode: f.view_mode, view_functions: f.view_functions, view_units: f.view_units || [], can_export: f.can_export, can_decisions: !!f.can_decisions, can_emp_changes: !!f.can_emp_changes, can_role_overlap: !!f.can_role_overlap, can_summary: !!f.can_summary, can_layers: !!f.can_layers, can_layer_edit: !!f.can_layer_edit, can_bm_view: !!f.can_bm_view, can_chro: !!f.can_chro, can_hr_bm: !!f.can_hr_bm, chro_mode: f.chro_mode || 'view', chro_functions: f.chro_functions || [], ...(user?.is_super ? { can_benchmark: !!f.can_benchmark, can_bm_edit: !!f.can_bm_edit } : {}) } }); notify('Access saved.') }
      setEdit(null); load()
    } catch (e) { notify(e.message, true) }
  }
  const act = async (u, body) => { try { const r = await api(`/api/admin/users/${u.id}`, { method: 'PATCH', body }); if (r.password) setShown({ username: u.username, password: r.password }); load() } catch (e) { notify(e.message, true) } }
  const dash = u => u.is_admin || u.view_mode === 'all' ? 'Whole organisation' : u.view_mode === 'input' ? (u.input_functions.length ? 'Same as input' : 'None') : u.view_mode === 'selected' ? (u.view_functions.length === 1 ? fname(u.view_functions[0]) : `${u.view_functions.length} functions`) + ((u.view_units || []).length ? ` · ${u.view_units.length === 1 ? u.view_units[0].split('|')[1] : u.view_units.length + ' units'}` : '') : 'None'
  const inp = u => u.is_admin ? 'All functions' : !u.input_functions.length ? 'None' : u.input_functions.length === 1 ? fname(u.input_functions[0]) : `${u.input_functions.length} functions`
  const rows = users.filter(u => !q || (u.username + ' ' + u.full_name + ' ' + u.input_functions.map(fname).join(' ')).toLowerCase().includes(q.toLowerCase()))
  return <>
    {shown && <div className="msg ok" style={{ marginBottom: 14 }}>Login <b>{shown.username}</b>, password <b style={{ fontFamily: 'monospace' }}>{shown.password}</b>. Copy it now; it will not be shown again. <button className="btn" style={{ marginLeft: 8 }} onClick={() => setShown(null)}>Done</button></div>}
    {edit ? <UserEditor fns={fns} units={units} initial={edit} onSave={save} isSuper={!!user?.is_super} onCancel={() => setEdit(null)} /> :
      <div className="kvline" style={{ marginBottom: 14 }}>
        <button className="btn pri" onClick={() => setEdit({})}>Create a login</button>
        <button className="btn" onClick={() => download('/api/admin/users/bulk-poc', 'poc_logins.csv', 'POST').then(load).catch(e => notify(e.message, true))}>Create a POC login for every function without one (CSV)</button>
        <input className="inp" placeholder="Search users or functions" value={q} onChange={e => setQ(e.target.value)} style={{ marginLeft: 'auto', minWidth: 220 }} />
      </div>}
    <div className="panel"><div className="tw"><Table rows={rows} cols={[
      { h: 'User', v: u => <><b>{u.username}</b><div className="formula">{u.full_name}</div></> },
      { h: 'Access', v: u => u.is_admin ? <span className="pill p-ok">Administrator</span> : <span className="formula">Custom</span> },
      { h: 'Input', v: u => inp(u) }, { h: 'Dashboards', v: u => dash(u) },
      { h: 'Export', v: u => u.is_admin || u.can_export ? 'Yes' : 'No' },
      { h: 'Recommendations', v: u => u.is_admin || u.can_decisions ? 'Yes' : 'No' },
      { h: 'Employee Changes', v: u => u.is_admin || u.can_emp_changes ? 'Yes' : 'No' },
      { h: 'Role Overlap', v: u => u.is_admin || u.can_role_overlap ? 'Yes' : 'No' },
      { h: 'View Benchmark', v: u => u.can_bm_view ? 'Yes' : 'No' },
      { h: 'HR Dashboard', v: u => u.can_chro ? (u.can_hr_bm ? 'Yes, with benchmark' : 'Yes') + (u.is_admin || u.username === 'admin' ? '' : u.chro_mode === 'all' ? ' · all functions' : u.chro_mode === 'selected' ? ' · ' + ((u.chro_functions || []).length === 1 ? fname(u.chro_functions[0]) : `${(u.chro_functions || []).length} functions`) : ' · as dashboard view') : 'No' },
      { h: 'Layer Panel', v: u => !(u.is_admin || u.can_layers) ? 'No' : u.can_layer_edit ? 'View and edit' : 'View' },
      { h: 'Work Summary', v: u => u.is_admin || u.can_summary ? 'Yes' : 'No' },
      ...(user?.is_super ? [{ h: 'Grade Benchmark', v: u => u.can_bm_edit ? 'View and change' : u.can_benchmark ? 'View' : 'No' }] : []),
      { h: 'Status', v: u => u.active ? <span className="pill p-ok">Active</span> : <span className="pill p-bad">Disabled</span> },
      { h: '', v: u => <div className="row-actions"><button className="btn pri" onClick={() => { setEdit(u); window.scrollTo(0, 0) }}>Edit access</button><button className="btn" onClick={() => act(u, { reset_password: true })}>Reset password</button>
        <button className="btn" onClick={() => act(u, { active: !u.active })}>{u.active ? 'Disable' : 'Enable'}</button></div> }]} /></div></div>
  </>
}

function PeopleTab({ notify, reloadOrg }) {
  const [q, setQ] = useState('')
  const [flagged, setFlagged] = useState(true)
  const [rows, setRows] = useState([])
  const load = () => api(`/api/admin/people?q=${encodeURIComponent(q)}&flagged=${flagged}`).then(setRows).catch(e => notify(e.message, true))
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t) }, [q, flagged])
  const set = async (code, body) => { try { await api(`/api/admin/people/${encodeURIComponent(code)}`, { method: 'PATCH', body }); load(); reloadOrg() } catch (e) { notify(e.message, true) } }
  return <>
    <p className="sub">Mark employees as external (shown with a marker, e.g. an external law firm partner) or exclude them from span and employee count (e.g. secretaries). Excluded employees are not counted on the dashboard; the note at the top of the dashboard lists them and can count them in. To mark someone who has left, use Employees, Resigned. Employees added by functions can be verified here.</p>
    <div className="kvline"><input className="inp" placeholder="Search name or code" value={q} onChange={e => setQ(e.target.value)} style={{ minWidth: 260 }} />
      <label className="formula"><input type="checkbox" checked={flagged} onChange={e => setFlagged(e.target.checked)} /> Only flagged or unverified</label></div>
    <div className="panel"><div className="tw"><Table rows={rows} empty={flagged ? 'No one is flagged. Untick the box or search to find someone.' : 'No matches.'} cols={[
      { h: 'Name', v: r => r.name }, { h: 'Code', v: r => r.code }, { h: 'Grade', v: r => r.grade }, { h: 'Function', v: r => r.function },
      { h: 'External', v: r => <input type="checkbox" checked={r.external} onChange={e => set(r.code, { external: e.target.checked })} aria-label="External" /> },
      { h: 'Exclude', v: r => <input type="checkbox" checked={r.exclude} onChange={e => set(r.code, { exclude: e.target.checked })} aria-label="Exclude from counts" /> },
      { h: 'Reason', v: r => <EditField value={r.reason} placeholder="Why" onCommit={v => set(r.code, { reason: v })} /> },
      { h: 'Verified', v: r => r.verified ? 'Yes' : <button className="btn" onClick={() => set(r.code, { verified: true })}>Verify{r.added_by ? ` (added by ${r.added_by})` : ''}</button> }]} /></div></div>
  </>
}

function RetagTab({ notify, reloadOrg }) {
  const [rows, setRows] = useState([])
  const [all, setAll] = useState(false)
  const load = () => api('/api/admin/retag-requests').then(setRows).catch(e => notify(e.message, true))
  useEffect(() => { load() }, [])
  const act = async (r, a) => {
    try {
      await api(`/api/admin/retag-requests/${r.id}/${a}`, { method: 'POST' })
      notify(a !== 'approve' ? 'Request rejected.' : r.kind === 'Reporting line' ? `${r.name} now reports to ${r.to}.` : `${r.name} moved to ${r.to}.`); load(); reloadOrg()
    } catch (e) { notify(e.message, true) }
  }
  const pending = rows.filter(r => r.status === 'Pending')
  const shown = all ? rows : pending
  return <div className="panel">
    <div className="kvline"><span className="seg" role="group"><button type="button" aria-pressed={!all} onClick={() => setAll(false)}>Waiting ({fmt(pending.length)})</button><button type="button" aria-pressed={all} onClick={() => setAll(true)}>All requests ({fmt(rows.length)})</button></span></div>
    <div className="tw"><Table rows={shown} empty={all ? 'No requests yet.' : 'No requests are waiting.'} cols={[
      { h: 'Request', v: r => <span className={'pill ' + (r.kind === 'Reporting line' ? 'p-ok' : 'p-warn')}>{r.kind}</span> },
      { h: 'Employee', v: r => <><b>{r.name}</b><div className="formula">{[r.code, r.grade, r.function].filter(Boolean).join(' · ')}</div></> },
      { h: 'From', v: r => r.from || '' }, { h: 'To', v: r => <b>{r.to}</b> }, { h: 'Reason', v: r => r.note || '' },
      { h: 'Requested by', v: r => <>{r.by}<div className="formula">{r.at.replace('T', ' ')}</div></> },
      { h: 'Status', v: r => r.status === 'Pending' ? <div className="row-actions" style={{ flexWrap: 'nowrap' }}><button className="btn pri" onClick={() => act(r, 'approve')}>Approve</button><button className="btn" onClick={() => act(r, 'reject')}>Reject</button></div> : r.status }]} /></div></div>
}

function FrequencyBlock({ notify }) {
  const [rows, setRows] = useState([])
  const [n, setN] = useState(''); const [d, setD] = useState('')
  const load = () => api('/api/admin/frequencies').then(setRows).catch(e => notify(e.message, true))
  useEffect(() => { load() }, [])
  const run = async (p, m, b) => { try { setRows(await api(p, { method: m, body: b })) } catch (e) { notify(e.message, true) } }
  return <div className="panel"><h2>Frequencies</h2>
    <p className="formula" style={{ margin: '4px 0 10px' }}>The frequency options for activities. Working days in one period convert a volume to a working day for time figures (for example, Monthly 22). Renaming one updates the activities that use it.</p>
    <div className="tw"><table><thead><tr><th>Frequency</th><th className="num">Working Days in One Period</th><th className="num">Activities</th><th></th></tr></thead>
      <tbody>{rows.map(f => <tr key={f.id}><td><EditField value={f.name} onCommit={v => run(`/api/admin/frequencies/${f.id}`, 'PATCH', { name: v })} /></td>
        <td className="num"><EditField className="inp sm" type="number" step="0.5" min="0.5" value={f.days} onCommit={v => run(`/api/admin/frequencies/${f.id}`, 'PATCH', { days: v })} /></td>
        <td className="num">{f.used || '-'}</td>
        <td><button className="btn" disabled={f.used > 0} title={f.used ? 'In use; rename it instead' : 'Remove'} onClick={() => confirm(`Remove ${f.name}?`) && run(`/api/admin/frequencies/${f.id}`, 'DELETE')}>✕</button></td></tr>)}</tbody></table></div>
    <div className="fields" style={{ display: 'flex', gap: 8, marginTop: 10 }}>
      <input className="inp" value={n} onChange={e => setN(e.target.value)} placeholder="New frequency" />
      <input className="inp sm" type="number" min="0.5" step="0.5" value={d} onChange={e => setD(e.target.value)} placeholder="Days" style={{ width: 90 }} />
      <button className="btn pri" disabled={!n.trim()} onClick={() => { run('/api/admin/frequencies', 'POST', { name: n, days: Number(d) || 1 }); setN(''); setD('') }}>Add</button></div>
  </div>
}

function ListsTab({ notify }) {
  const [lk, setLk] = useState(null); const [c, setC] = useState(''); const [r, setR] = useState('')
  const load = () => api('/api/lookups').then(setLk)
  useEffect(() => { load() }, [])
  const run = async (p, m, b) => { try { await api(p, { method: m, body: b }); load() } catch (e) { notify(e.message, true) } }
  if (!lk) return null
  const block = (title, items, val, setVal, base) => <div className="panel"><h2>{title}</h2>
    <div className="chips" style={{ margin: '12px 0' }}>{items.map(x => <span key={x} className="chip" style={{ cursor: 'default' }}>{x} <button className="btn" style={{ padding: '0 6px', marginLeft: 4 }} aria-label={`Remove ${x}`} onClick={() => confirm(`Remove ${x}?`) && run(`${base}/${encodeURIComponent(x)}`, 'DELETE')}>✕</button></span>)}</div>
    <div className="fields" style={{ display: 'flex', gap: 8 }}><input className="inp" value={val} onChange={e => setVal(e.target.value)} placeholder={`New ${title.toLowerCase().replace(/s$/, '')}`} />
      <button className="btn pri" onClick={() => { if (val.trim()) { run(base, 'POST', { name: val }); setVal('') } }}>Add</button></div></div>
  return <div className="grid g2">
    <div>{block('Standard activity categories', lk.categories, c, setC, '/api/admin/categories')}<p className="formula">Offered to every function as suggestions. POCs can also type their own category; it is then suggested for their other activities. Removing one here does not change activities that use it.</p></div>
    <div>{block('Regions', lk.regions, r, setR, '/api/admin/regions')}<p className="formula">The regions employees can be tagged to. Regions found in the master sheet are added automatically. A region in use cannot be removed.</p></div>
    <FrequencyBlock notify={notify} /><NatureBlock notify={notify} /></div>
}

// Nature of work: the heading and the options POCs choose from for each activity
function NatureBlock({ notify }) {
  const [d, setD] = useState(null)
  const [nw, setNw] = useState('')
  const [label, setLabel] = useState('')
  const [ren, setRen] = useState(null)      // { name, value }
  const [rm, setRm] = useState(null)        // { name, activities, move_to }
  const load = () => api('/api/admin/nature').then(x => { setD(x); setLabel(x.label) }).catch(e => notify(e.message, true))
  useEffect(() => { load() }, [])
  const call = async (method, body, msg) => {
    try { const x = await api('/api/admin/nature', { method, body }); setD(x); setLabel(x.label); notify(msg + ' Refresh the page to see it everywhere.'); return true } catch (e) { notify(e.message, true); return false }
  }
  if (!d) return null
  return <div className="panel"><h2>{d.label}</h2>
    <p className="formula" style={{ marginTop: 0 }}>The options POCs choose from for each activity. Renaming an option renames it on every activity that uses it.</p>
    <div className="kvline" style={{ margin: '10px 0 14px' }}><span className="formula" style={{ minWidth: 70 }}>Heading</span>
      <input className="inp" value={label} onChange={e => setLabel(e.target.value)} style={{ maxWidth: 260 }} />
      <button className="btn" disabled={!label.trim() || label.trim() === d.label} onClick={() => call('PATCH', { label }, 'Heading saved.')}>Save Heading</button></div>
    <table><thead><tr><th>Option</th><th className="num">Activities</th><th></th></tr></thead><tbody>
      {d.options.map(o => <tr key={o.name}>
        <td>{ren?.name === o.name ? <input className="inp" autoFocus value={ren.value} onChange={e => setRen({ ...ren, value: e.target.value })} onKeyDown={e => e.key === 'Enter' && call('PATCH', { name: o.name, new_name: ren.value }, 'Renamed.').then(ok => ok && setRen(null))} /> : <b>{o.name}</b>}</td>
        <td className="num">{fmt(o.activities)}</td>
        <td style={{ whiteSpace: 'nowrap', textAlign: 'right' }}>{ren?.name === o.name
          ? <><button className="btn pri" onClick={() => call('PATCH', { name: o.name, new_name: ren.value }, 'Renamed.').then(ok => ok && setRen(null))}>Save</button> <button className="btn" onClick={() => setRen(null)}>Cancel</button></>
          : <><button className="btn" onClick={() => setRen({ name: o.name, value: o.name })}>Rename</button> <button className="btn" disabled={d.options.length <= 1} onClick={() => o.activities ? setRm({ name: o.name, activities: o.activities, move_to: d.options.find(x => x.name !== o.name)?.name || '' }) : (confirm(`Remove ${o.name}?`) && call('DELETE', { name: o.name }, 'Removed.'))}>Remove</button></>}</td></tr>)}
    </tbody></table>
    <div className="kvline" style={{ marginTop: 12 }}><input className="inp" value={nw} onChange={e => setNw(e.target.value)} placeholder="New option" style={{ maxWidth: 260 }} />
      <button className="btn pri" disabled={!nw.trim()} onClick={() => call('POST', { name: nw }, 'Added.').then(ok => ok && setNw(''))}>Add</button></div>
    {rm && <Modal title={`Remove ${rm.name}`} onClose={() => setRm(null)}>
      <p>{fmt(rm.activities)} {rm.activities === 1 ? 'activity uses' : 'activities use'} <b>{rm.name}</b>. Move {rm.activities === 1 ? 'it' : 'them'} to:</p>
      <select value={rm.move_to} onChange={e => setRm({ ...rm, move_to: e.target.value })} style={{ minWidth: 280 }}>
        {d.options.filter(x => x.name !== rm.name).map(x => <option key={x.name} value={x.name}>{x.name}</option>)}<option value="">Leave blank (not recorded)</option></select>
      <div className="row-actions" style={{ marginTop: 16 }}><button className="btn danger" onClick={() => call('DELETE', { name: rm.name, move_to: rm.move_to }, `${rm.name} removed.`).then(ok => ok && setRm(null))}>Remove and Move</button>
        <button className="btn" onClick={() => setRm(null)}>Cancel</button></div>
    </Modal>}
  </div>
}

// rename the labels of the dashboard pages (page titles, sidebar, boxes and chart headings) without a code change
function LabelsTab({ notify }) {
  const [mine, setMine] = useState(null)
  const [q, setQ] = useState('')
  useEffect(() => { api('/api/admin/settings').then(r => setMine(r.labels || {})).catch(e => notify(e.message, true)) }, [])
  const save = async next => {
    try { const r = await api('/api/admin/settings', { method: 'PUT', body: { labels: next } }); setMine(r.labels || {}); prefs.labels = r.labels || {}; notify('Label saved.') }
    catch (e) { notify(e.message, true) }
  }
  const set = (k, v) => { const n = { ...mine }; if ((v || '').trim()) n[k] = v; else delete n[k]; save(n) }
  if (!mine) return <div className="loading">Loading…</div>
  const ql = q.trim().toLowerCase()
  const rows = LABELS.filter(([g, k, d]) => !ql || (g + ' ' + d + ' ' + (mine[k] || '')).toLowerCase().includes(ql))
  const groups = [...new Set(rows.map(r => r[0]))]
  const changed = Object.keys(mine).filter(k => LABELS.some(x => x[1] === k)).length
  return <div className="panel" style={{ maxWidth: 980 }}>
    <div className="kvline" style={{ marginBottom: 10 }}>
      <input className="inp" placeholder="Find a label" value={q} onChange={e => setQ(e.target.value)} style={{ minWidth: 260 }} />
      <span className="formula">{changed ? `${changed} renamed` : 'All labels use their standard text'}</span>
      {changed > 0 && <button className="linkbtn" onClick={() => confirm('Put every label back to its standard text?') && save({})}>Reset All</button>}
    </div>
    <TypeOrder mine={mine} save={save} />
    {groups.map(g => <div key={g} style={{ marginTop: 14 }}><h3>{g}</h3>
      <div className="tw"><table><thead><tr><th style={{ width: '38%' }}>Standard Text</th><th>Shown As</th><th style={{ width: 70 }}></th></tr></thead>
        <tbody>{rows.filter(r => r[0] === g).map(([, k, d]) => <tr key={k}>
          <td>{d}</td>
          <td><EditField className="inp" style={{ width: '100%' }} value={mine[k] || ''} placeholder={d} onCommit={v => set(k, v)} /></td>
          <td>{mine[k] && <button className="linkbtn" onClick={() => set(k, '')}>Reset</button>}</td></tr>)}</tbody></table></div></div>)}
  </div>
}

// the order of the employee types (FTE, Contract, FTC, Daily Wagers) on the dashboard cards and in every breakdown
function TypeOrder({ mine, save }) {
  const cur = String(mine['types.order'] || '').split(',').filter(k => TYPE_KEYS.includes(k))
  const order = [...new Set([...cur, ...TYPE_KEYS])]
  const name = k => mine[{ fte: 'dash.fte', dc: 'dash.dc', ftc: 'dash.ftc', dw: 'dash.dw' }[k]] || { fte: 'FTE', dc: 'Contract', ftc: 'FTC', dw: 'Daily Wagers' }[k]
  const move = (i, by) => { const o = [...order]; const j = i + by; if (j < 0 || j >= o.length) return; [o[i], o[j]] = [o[j], o[i]]; save({ ...mine, 'types.order': o.join(',') }) }
  return <div style={{ marginTop: 6 }}><h3>Employee types: order</h3>
    <p className="formula">The order of the type cards on the dashboard (after Total Employees) and of the types in every breakdown. Contract and Daily Wagers show once anyone is marked (Admin, Employees, Edit).</p>
    <div className="typeorder">{order.map((k, i) => <span key={k} className="to-chip"><b>{i + 1}</b>{name(k)}
      <button type="button" disabled={i === 0} onClick={() => move(i, -1)} title="Move left">◀</button><button type="button" disabled={i === order.length - 1} onClick={() => move(i, 1)} title="Move right">▶</button></span>)}
      {cur.length > 0 && <button className="linkbtn" onClick={() => { const n = { ...mine }; delete n['types.order']; save(n) }}>Standard order</button>}</div></div>
}

function SettingsTab({ notify, reloadOrg }) {
  const [s, setS] = useState(null)
  useEffect(() => { api('/api/admin/settings').then(setS) }, [])
  const save = async (k, v) => { try { setS(await api('/api/admin/settings', { method: 'PUT', body: { [k]: v } })); notify('Saved. Refresh the page to apply it everywhere.'); reloadOrg() } catch (e) { notify(e.message, true) } }
  if (!s) return null
  return <div className="panel" style={{ maxWidth: 860 }}>
    <div className="checks" style={{ gap: 16 }}>
      <label className="kvline"><span style={{ minWidth: 260 }}>Productive hours per person per day</span><EditField className="inp sm" type="number" step="0.25" value={s.productive_hours} onCommit={v => save('productive_hours', v)} /></label>
      <label className="kvline"><span style={{ minWidth: 260 }}>Employee code at the top of the organogram</span><EditField className="inp" value={s.root_code} onCommit={v => save('root_code', v)} /></label>
      <label className="kvline"><span style={{ minWidth: 260 }}>Senior grade threshold (grade number, 68 = SM I)</span><EditField className="inp sm" type="number" value={s.senior_rank} onCommit={v => save('senior_rank', v)} /></label>
      <label className="kvline"><span style={{ minWidth: 260 }}>Group team members above this team size</span><EditField className="inp sm" type="number" value={s.large_team} onCommit={v => save('large_team', v)} /></label>
      <label className="kvline"><span style={{ minWidth: 260 }}>Name of the whole group in the dashboard filter</span><EditField className="inp" value={s.group_label} onCommit={v => save('group_label', v)} /></label>
    </div>
    <div style={{ marginTop: 22 }}><h3>Grade of the Top of the Organisation</h3>
      <label className="chk" style={{ fontSize: 13.5 }}><input type="checkbox" checked={!!s.show_top_grade} onChange={async e => { await save('show_top_grade', e.target.checked); reloadOrg && reloadOrg() }} />
        <span>Show the grade of the top of the organisation (when off, it is shown as "-" on every page and export)</span></label></div>
    <div style={{ marginTop: 22 }}><h3>Resigned Employees</h3>
      <label className="chk" style={{ fontSize: 13.5 }}><input type="checkbox" checked={s.hide_resigned !== false} onChange={async e => { await save('hide_resigned', e.target.checked); reloadOrg && reloadOrg() }} />
        <span>Hide resigned employees everywhere: dashboards, organogram, lists and exports (they stay in Admin, Employees)</span></label></div>
    <div style={{ marginTop: 22 }}><h3>Activity Themes and Categories on Activity Insights</h3>
      <label className="chk" style={{ fontSize: 13.5 }}><input type="checkbox" checked={!!s.show_themes} onChange={async e => { await save('show_themes', e.target.checked); prefs.showThemes = e.target.checked }} />
        <span>Show activity themes (first on the page, and the volume chart by theme). Also adds themes to the Excel export. Set the themes up first in Admin, Activity Categories.</span></label>
      <label className="chk" style={{ fontSize: 13.5, marginTop: 6 }}><input type="checkbox" checked={s.show_categories !== false} onChange={async e => { await save('show_categories', e.target.checked); prefs.showCategories = e.target.checked }} />
        <span>Show the Activity Category panel. Categories still open from each theme.</span></label></div>
    <div style={{ marginTop: 22 }}><h3>Time-Based Figures</h3>
      <label className="chk" style={{ fontSize: 13.5 }}><input type="checkbox" checked={!!s.show_time} onChange={e => save('show_time', e.target.checked)} />
        <span>Show man-hours, FTE equivalents and utilisation on the dashboard, employee pages, data capture summaries and exports</span></label>
      <p className="formula" style={{ margin: '4px 0 0 26px' }}>When off, the portal works with the number of activities instead: employees ranked by activities, categories and detailed activities. Volumes and processing times are still recorded. Refresh the page after changing this.</p></div>
    <p className="formula" style={{ marginTop: 12 }}>Daily man-hours = processing time × volume ÷ working days in the frequency period (set per frequency in Lists) ÷ 60. Utilisation = daily man-hours ÷ productive hours.</p>
  </div>
}

const CF = [['product', 'Products'], ['process', 'Process name'], ['channel', 'Channel'], ['description', 'Activity description'], ['category', 'Activity category'],
  ['frequency', 'Frequency'], ['volume', 'Average volume'], ['peak', 'Peak volumes (start and end of month)'],
  ['handling', 'Nature of work'], ['minutes', 'Employee processing time'], ['automation', 'Automation opportunity']]

function CaptureFields({ notify }) {
  const [fns, setFns] = useState([])
  const [fid, setFid] = useState('')
  const [d, setD] = useState(null)
  const load = id => api(`/api/admin/capture-fields${id ? `?function_id=${id}` : ''}`).then(setD).catch(e => notify(e.message, true))
  useEffect(() => { api('/api/capture/functions').then(r => setFns([...r].sort((a, b) => a.name.localeCompare(b.name)))).catch(() => {}) }, [])
  useEffect(() => { setD(null); load(fid) }, [fid])
  const put = async fields => { try { setD(await api('/api/admin/capture-fields', { method: 'PUT', body: { function_id: fid ? +fid : null, fields } })); notify('Saved.') } catch (e) { notify(e.message, true) } }
  const own = new Set(d?.functions_with_own || [])
  return <div className="panel" style={{ maxWidth: 900 }}>
    <h2>Data Capture Fields</h2>
    <p className="sub">All fields are optional by default: POCs fill in what applies to each activity and leave the rest blank. Mark a field Required if every activity must have it, or Hidden to remove it from the form, the table and the Excel template. Set it for all functions, then adjust any function that differs.</p>
    <div className="kvline"><span className="formula">Settings for</span>
      <select value={fid} onChange={e => setFid(e.target.value)} style={{ minWidth: 300 }}>
        <option value="">All functions (default)</option>
        {fns.map(f => <option key={f.id} value={f.id}>{f.name}{own.has(f.id) ? ' · own settings' : ''}</option>)}</select>
      {fid && d && (d.own ? <button className="btn" onClick={() => confirm('Use the default settings for this function again?') && put(null)}>Use the default for this function</button>
        : <span className="formula">Uses the default. Changing a field below gives this function its own settings.</span>)}</div>
    {!d ? <div className="loading">Loading…</div> : <div className="tw"><table><thead><tr><th>Field</th><th>Required</th><th>Optional</th><th>Hidden</th>{fid && <th>Default</th>}</tr></thead>
      <tbody>{CF.map(([k, l]) => <tr key={k}><td>{l}</td>{['required', 'optional', 'hidden'].map(v => <td key={v}>
        <input type="radio" name={'cf-' + k} checked={d.fields[k] === v} onChange={() => put({ ...d.fields, [k]: v })} aria-label={`${l}: ${v}`} /></td>)}
        {fid && <td className="formula">{d.default[k]}{d.default[k] !== d.fields[k] ? ' (changed)' : ''}</td>}</tr>)}</tbody></table></div>}
  </div>
}

function ProgressTab({ notify, reloadOrg }) {
  const [rows, setRows] = useState(null)
  const [ren, setRen] = useState(null)   // { id, name, hr_name, to }: renaming a function
  const load = () => api('/api/capture/functions').then(setRows).catch(e => notify(e.message, true))
  useEffect(() => { load() }, [])
  const rename = async () => {
    try { await api(`/api/admin/functions/${ren.id}`, { method: 'PATCH', body: { name: ren.to } }); notify(`Renamed to ${ren.to.trim()}.`); setRen(null); load(); reloadOrg && reloadOrg() }
    catch (e) { notify(e.message, true) }
  }
  if (!rows) return <div className="loading">Loading…</div>
  const tot = k => rows.reduce((a, r) => a + r[k], 0)
  const pill = s => s === 'Complete' ? <span className="pill p-ok">Complete</span> : s === 'In progress' ? <span className="pill p-warn">In progress</span> : <span className="pill" style={{ background: 'var(--surface-2)', color: 'var(--ink-3)' }}>Not started</span>
  return <>
    <div className="totals">
      <div><b>{rows.filter(r => r.status === 'Complete').length} of {rows.length}</b><span>Functions complete</span></div>
      <div><b>{rows.filter(r => r.status === 'In progress').length}</b><span>In progress</span></div>
      <div><b>{tot('headcount') ? Math.round(tot('staff_with_work') / tot('headcount') * 100) : 0}%</b><span>Employees with activities ({fmt(tot('staff_with_work'))} of {fmt(tot('headcount'))})</span></div>
      <div><b>{fmt(tot('activities'))}</b><span>Activities recorded</span></div>
    </div>
    <div className="panel"><div className="tw"><Table rows={[...rows].sort((a, b) => a.name.localeCompare(b.name))} cols={[
      { h: 'Function', v: r => <><b>{r.name}</b> <button className="linkbtn" onClick={() => setRen({ ...r, to: r.name })}>Rename</button>{r.hr_name && r.hr_name !== r.name && <div className="formula">HR: {r.hr_name}</div>}</> }, { h: 'Status', v: r => pill(r.status) },
      { h: 'Employees', num: 1, v: r => fmt(r.headcount) },
      { h: 'With Activities', num: 1, v: r => `${fmt(r.staff_with_work)} (${r.headcount ? Math.round(r.staff_with_work / r.headcount * 100) : 0}%)` },
      { h: 'Activities', num: 1, v: r => fmt(r.activities) },
      { h: 'Missing Details', num: 1, v: r => r.incomplete ? <span className="pill p-warn">{fmt(r.incomplete)}</span> : '-' },
      ...(prefs.showTime ? [{ h: 'Daily Man-Hours', num: 1, v: r => r.daily_hours ? r.daily_hours.toFixed(1) : '-' },
      { h: 'FTE Equivalent', num: 1, v: r => r.fte_equivalent ? r.fte_equivalent.toFixed(1) : '-' }] : []),
      { h: 'Started (UTC)', v: r => r.status_at ? r.status_at.replace('T', ' ') : '-' }]} /></div></div>
    {ren && <Modal title={`Rename ${ren.name}`} sub="The new name shows everywhere in the portal" onClose={() => setRen(null)}>
      <label style={{ display: 'grid', gap: 6 }}>New name<input className="inp" value={ren.to} maxLength={200} autoFocus onChange={e => setRen(x => ({ ...x, to: e.target.value }))} onKeyDown={e => e.key === 'Enter' && ren.to.trim().length > 1 && rename()} /></label>
      <p className="formula">The HR master sheet's name ({ren.hr_name || ren.name}) is kept, so importing the HR sheet still finds this function, and the Full Export on Employee Changes still uses HR's name.</p>
      <div className="row-actions"><button className="btn pri" disabled={ren.to.trim().length < 2 || ren.to.trim() === ren.name} onClick={rename}>Rename</button><button className="btn" onClick={() => setRen(null)}>Cancel</button></div>
    </Modal>}
  </>
}

function AuditTab() {
  const [rows, setRows] = useState([])
  useEffect(() => { api('/api/admin/audit').then(setRows) }, [])
  return <div className="panel"><div className="tw scroll" style={{ maxHeight: 600 }}><Table rows={rows} cols={[{ h: 'When (UTC)', v: r => r.at.replace('T', ' ') }, { h: 'User', v: r => r.user }, { h: 'Action', v: r => r.action }, { h: 'Detail', v: r => r.detail }]} /></div></div>
}

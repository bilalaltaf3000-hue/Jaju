import React, { useEffect, useMemo, useState } from 'react'
import { api, download } from '../api.js'
import { fmt } from '../org.js'
import { Modal } from '../ui.jsx'
import { prefs } from '../prefs.js'

// Admin: review the activity categories written across functions, merge duplicates into one standard name
// (with undo) and group categories under activity themes.
export default function CategoryReview({ notify }) {
  const [f, setF] = useState({ functions: '', unit: '', region: '', emp_type: '', role: '' })
  const [d, setD] = useState(null)
  const [q, setQ] = useState('')
  const [th, setTh] = useState('')          // theme filter: '' all, '__none' no theme yet, or a theme
  const [ticked, setTicked] = useState(() => new Set())
  const [to, setTo] = useState('')
  const [assign, setAssign] = useState('')
  const [busy, setBusy] = useState(false)
  const [samples, setSamples] = useState(null)
  const [themeName, setThemeName] = useState('')
  const [ren, setRen] = useState(null)
  const qs = () => { const p = new URLSearchParams(); if (f.functions) p.set('functions', f.functions); if (f.unit) p.append('units', f.unit); if (f.region) p.set('region', f.region); if (f.emp_type) p.set('emp_type', f.emp_type); if (f.role) p.set('role', f.role); return p }
  const body = () => ({ functions: f.functions ? [+f.functions] : [], units: f.unit ? [f.unit] : [], region: f.region, emp_type: f.emp_type, role: f.role })
  const load = () => api('/api/admin/category-review?' + qs()).then(x => { setD(x); setTicked(new Set()) }).catch(e => notify(e.message, true))
  useEffect(() => { load() }, [f.functions, f.unit, f.region, f.emp_type, f.role])   // the list stays on show while the new one loads
  const set = (k, v) => setF(s => ({ ...s, [k]: v, ...(k === 'functions' ? { unit: '' } : {}) }))
  const ql = q.trim().toLowerCase()
  const rows = useMemo(() => !d ? [] : d.categories.filter(c => (!ql || c.name.toLowerCase().includes(ql)) && (!th || (th === '__none' ? !c.theme : c.theme === th))), [d, ql, th])
  const toggle = n => setTicked(s => { const x = new Set(s); x.has(n) ? x.delete(n) : x.add(n); return x })
  const scopeText = [f.functions && d?.functions.find(x => String(x.id) === f.functions)?.name, f.unit, f.region, f.emp_type, f.role && `${f.role} employees`].filter(Boolean).join(', ') || 'All functions'
  const run = async (fn, okMsg) => { setBusy(true); try { const r = await fn(); notify(okMsg(r)); await load() } catch (e) { notify(e.message, true) } finally { setBusy(false) } }
  const merge = () => {
    const names = [...ticked]
    if (!to.trim()) return notify('Type or choose the standard name.', true)
    if (!confirm(`Rename ${names.length} ${names.length === 1 ? 'category' : 'categories'} to "${to.trim()}" for ${scopeText}?`)) return
    run(() => api('/api/admin/category-merge', { method: 'POST', body: { ...body(), names, to } }), r => `${fmt(r.activities)} activities now use "${r.to}".`).then(() => setTo(''))
  }
  const setTheme = (names, theme) => run(() => api('/api/admin/category-theme', { method: 'POST', body: { names, theme } }), () => theme ? `Put under ${theme}.` : 'Taken out of its theme.')
  const themeCall = (method, b, msg) => run(() => api('/api/admin/themes', { method, body: b }), () => msg)
  const showSamples = c => api('/api/admin/category-samples?' + new URLSearchParams([...qs(), ['name', c.name]])).then(r => setSamples({ c, rows: r })).catch(e => notify(e.message, true))
  if (!d) return <div className="loading">Loading…</div>
  const themeCount = t => d.categories.filter(c => c.theme === t).length
  const noTheme = d.categories.filter(c => !c.theme).length
  return <div className="catrev">
    <ExcelReview notify={notify} functions={f.functions} fnList={d.functions} onDone={load} />
    <div className="kvline cr-filters">
      <select value={f.functions} onChange={e => set('functions', e.target.value)}><option value="">All functions</option>{d.functions.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</select>
      {d.units.length > 0 && <select value={f.unit} onChange={e => set('unit', e.target.value)}><option value="">All units</option>{d.units.map(u => <option key={u}>{u}</option>)}</select>}
      <select value={f.region} onChange={e => set('region', e.target.value)}><option value="">All regions</option>{d.regions.map(r => <option key={r}>{r}</option>)}</select>
      <span className="seg sm">{[['', 'All Employees'], ['FTE', 'FTE'], ['FTC', 'FTC']].map(([v, l]) => <button key={v} type="button" aria-pressed={f.emp_type === v} onClick={() => set('emp_type', v)}>{l}</button>)}</span>
      <span className="seg sm">{[['Service', 'Service'], ['Support', 'Support'], ['', 'All']].map(([v, l]) => <button key={v} type="button" aria-pressed={f.role === v} onClick={() => set('role', v)}>{l}</button>)}</span>
    </div>

    <div className="cr-top">
      <div className="panel cr-themes">
        <div className="rhead"><h3>Activity Themes</h3>
          <label className="chk cr-show"><input type="checkbox" checked={!!d.show_themes} disabled={busy}
            onChange={e => { const on = e.target.checked; run(() => api('/api/admin/settings', { method: 'PUT', body: { show_themes: on } }), () => { prefs.showThemes = on; return on ? 'Themes are now shown on Activity Insights and in the export.' : 'Themes are hidden from Activity Insights and the export.' }) }} />
            <span>Show Themes on Activity Insights</span></label>
          <label className="chk cr-show" style={{ marginLeft: 14 }}><input type="checkbox" checked={d.show_categories !== false} disabled={busy}
            onChange={e => { const on = e.target.checked; run(() => api('/api/admin/settings', { method: 'PUT', body: { show_categories: on } }), () => { prefs.showCategories = on; return on ? 'The Activity Category panel is shown on Activity Insights.' : 'The Activity Category panel is hidden from Activity Insights.' }) }} />
            <span>Show Categories</span></label></div>
        <div className="cr-themelist">
          <button type="button" className={'cr-theme' + (!th ? ' on' : '')} onClick={() => setTh('')}><span>All Categories</span><b>{fmt(d.categories.length)}</b></button>
          <button type="button" className={'cr-theme warn' + (th === '__none' ? ' on' : '')} onClick={() => setTh('__none')}><span>No Theme Yet</span><b>{fmt(noTheme)}</b></button>
          {d.themes.map(t => <div key={t} className={'cr-theme' + (th === t ? ' on' : '')}>
            {ren?.name === t ? <input className="inp" autoFocus value={ren.value} onChange={e => setRen({ ...ren, value: e.target.value })}
              onKeyDown={e => { if (e.key === 'Enter') { themeCall('PATCH', { name: t, new_name: ren.value }, 'Theme renamed.'); setRen(null); if (th === t) setTh('') } if (e.key === 'Escape') setRen(null) }} />
              : <button type="button" className="cr-tname" onClick={() => setTh(t)}>{t}</button>}
            <b>{fmt(themeCount(t))}</b>
            <span className="cr-tact"><button type="button" className="linkbtn" onClick={() => setRen({ name: t, value: t })}>Rename</button>
              <button type="button" className="linkbtn" onClick={() => confirm(`Remove the theme ${t}? Its categories go back to No Theme.`) && themeCall('DELETE', { name: t }, 'Theme removed.')}>Remove</button></span>
          </div>)}
        </div>
        <div className="kvline" style={{ marginTop: 10 }}><input className="inp" placeholder="New theme, e.g. Governance and Control" value={themeName} onChange={e => setThemeName(e.target.value)} style={{ flex: 1 }} />
          <button className="btn pri" disabled={!themeName.trim() || busy} onClick={() => { themeCall('POST', { name: themeName }, 'Theme added.'); setThemeName('') }}>Add Theme</button></div>
      </div>
      <div className="panel cr-sugg">
        <div className="rhead"><h3>Possible Duplicates</h3></div>
        {d.last_merge && <div className="msg ok" style={{ margin: '0 0 10px' }}>Last merge: <b>{d.last_merge.from.join(', ')}</b> into <b>{d.last_merge.to}</b> ({fmt(d.last_merge.count)} activities, {d.last_merge.at}).
          <button className="btn" style={{ marginLeft: 8 }} disabled={busy} onClick={() => confirm('Undo the last merge? The activities get their earlier categories back.') && run(() => api('/api/admin/category-undo', { method: 'POST' }), r => `Undone: ${fmt(r.activities)} activities restored.`)}>Undo Last Merge</button></div>}
        {!d.suggested.length ? <p className="formula">No near-identical spellings found. Use the search to find categories with the same meaning.</p>
          : <ul className="cr-groups">{d.suggested.map(g => <li key={g.join('|')}><span>{g.join('  /  ')}</span>
            <button className="btn" onClick={() => { setTicked(new Set(g)); setTo(g[0]); setQ(''); setTh('') }}>Tick These</button></li>)}</ul>}
      </div>
    </div>

    <div className="panel" style={{ padding: '10px 14px' }}>
      <div className="kvline" style={{ marginBottom: 8 }}>
        <input className="inp" placeholder="Search categories, e.g. audit" value={q} onChange={e => setQ(e.target.value)} style={{ minWidth: 280 }} />
        <span className="formula">{fmt(rows.length)} of {fmt(d.categories.length)} categories · changes apply to: <b>{scopeText}</b></span>
        {rows.length > 0 && <button className="linkbtn" onClick={() => setTicked(new Set(rows.map(r => r.name)))}>Tick All Shown</button>}
      </div>
      {ticked.size > 0 && <div className="cr-bar">
        <b>{fmt(ticked.size)} ticked</b>
        <span className="cr-act"><span className="formula">Merge into</span>
          <input className="inp" list="cr-names" value={to} onChange={e => setTo(e.target.value)} placeholder="Standard name" style={{ minWidth: 240 }} />
          <datalist id="cr-names">{d.categories.map(c => <option key={c.name} value={c.name} />)}</datalist>
          <button className="btn pri" disabled={busy || !to.trim()} onClick={merge}>{ticked.size === 1 ? 'Rename' : 'Merge'}</button></span>
        {d.themes.length > 0 && <span className="cr-act"><span className="formula">Theme</span>
          <select value={assign} onChange={e => setAssign(e.target.value)}><option value="">Choose a theme</option>{d.themes.map(t => <option key={t}>{t}</option>)}<option value="__clear">No theme</option></select>
          <button className="btn" disabled={busy || !assign} onClick={() => setTheme([...ticked], assign === '__clear' ? '' : assign)}>Apply</button></span>}
        <button className="linkbtn" onClick={() => setTicked(new Set())}>Clear</button>
      </div>}
      <div className="tw scroll" style={{ maxHeight: 620 }}><table className="cr-table">
        <thead><tr><th style={{ width: 30 }}></th><th>Category</th><th>Theme</th><th className="num">Activities</th><th className="num">Employees</th><th>Functions</th><th>Units</th><th></th></tr></thead>
        <tbody>{rows.map(c => <tr key={c.name} className={ticked.has(c.name) ? 'on' : ''}>
          <td><input type="checkbox" checked={ticked.has(c.name)} onChange={() => toggle(c.name)} aria-label={`Tick ${c.name}`} /></td>
          <td><b>{c.name}</b>{c.standard && <span className="pill p-ok" style={{ marginLeft: 6 }}>Standard</span>}</td>
          <td><select className="cr-tsel" value={c.theme} onChange={e => setTheme([c.name], e.target.value)} disabled={!d.themes.length}>
            <option value="">No theme</option>{d.themes.map(t => <option key={t}>{t}</option>)}</select></td>
          <td className="num">{fmt(c.activities)}</td><td className="num">{fmt(c.employees)}</td>
          <td className="cr-small">{c.functions.length > 2 ? `${c.functions.length} functions` : c.functions.join(', ')}</td>
          <td className="cr-small">{c.units.length > 2 ? `${c.units.length} units` : c.units.join(', ') || '-'}</td>
          <td><button className="linkbtn" onClick={() => showSamples(c)}>View</button></td></tr>)}
          {!rows.length && <tr><td colSpan={8} className="formula">No categories match.</td></tr>}</tbody></table></div>
    </div>

    {samples && <Modal wide title={samples.c.name} sub={`${fmt(samples.c.activities)} activities, ${fmt(samples.c.employees)} employees · ${scopeText}`} onClose={() => setSamples(null)}>
      <div className="tw scroll" style={{ maxHeight: 480 }}><table><thead><tr><th>Employee</th><th>Function</th><th style={{ minWidth: 320 }}>Activity Description</th><th>Process</th></tr></thead>
        <tbody>{samples.rows.map((r, i) => <tr key={i}><td>{r.employee}<div className="formula">{r.unit}</div></td><td>{r.function}</td><td>{r.description || '-'}</td><td>{r.process || '-'}</td></tr>)}</tbody></table></div>
      {samples.rows.length >= 25 && <p className="formula">The first 25 activities are shown.</p>}
    </Modal>}
  </div>
}

// Review in Excel: download the activities (all functions or one), edit them in Excel, upload with a preview
const FIELD_TILES = [['product', 'Products'], ['process', 'Processes'], ['channel', 'Channels'], ['volume_type', 'Volume types'],
  ['peak_som', 'Peaks (start of month)'], ['peak_eom', 'Peaks (end of month)'], ['minutes', 'Processing times'], ['automation', 'Automation']]
function ExcelReview({ notify, functions, fnList, onDone }) {
  const [last, setLast] = useState(null)
  const [plan, setPlan] = useState(null)      // the preview of an upload: { file, r }
  const [busy, setBusy] = useState(false)
  const [rm, setRm] = useState(false)       // also remove the activities not in the file
  const [dl, setDl] = useState(null)        // the download dialog: the function chosen ('' = all)
  const loadLast = () => api('/api/admin/activity-review/last').then(setLast).catch(() => {})
  useEffect(() => { loadLast() }, [])
  const send = async (file, dry, remove = false) => { const fd = new FormData(); fd.append('file', file); fd.append('dry_run', dry ? 'true' : 'false'); fd.append('remove_missing', remove ? 'true' : 'false'); return api('/api/admin/activity-review/upload', { method: 'POST', form: fd }) }
  const pick = async e => {
    const file = e.target.files[0]; e.target.value = ''; if (!file) return
    setBusy(true); setRm(false); try { setPlan({ file, r: await send(file, true) }) } catch (ex) { notify(ex.message, true) } finally { setBusy(false) }
  }
  const getFile = async () => {
    const fid = dl.fid, name = fid ? (fnList.find(x => String(x.id) === fid)?.name || 'function') : 'all functions'
    setBusy(true)
    try { await download('/api/admin/activity-review/download?functions=' + fid, `activity_review_${name.replace(/[^A-Za-z0-9]+/g, '_')}.xlsx`); notify(`Downloaded the activities of ${name}.`); setDl(null) }
    catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  const apply = async () => {
    const r0 = plan.r
    const gone = r0.deletes + (rm ? r0.missing : 0)
    if (gone && !confirm(`Delete ${gone} activities from the portal? Undo Last Upload brings them back.`)) return
    setBusy(true)
    try { const r = await send(plan.file, false, rm); notify(`Applied: ${tiles(r).map(([n, l]) => `${fmt(n)} ${l.toLowerCase()}`).join(', ')}${r.removing ? `, ${r.removing} activities not in the file removed` : ''}.`); setPlan(null); loadLast(); onDone() }
    catch (ex) { notify(ex.message, true) } finally { setBusy(false) }
  }
  const undo = async () => {
    if (!confirm('Undo the last Excel upload? Every activity and employee it changed goes back to what it was, added activities are taken out and deleted ones come back.')) return
    setBusy(true); try { const r = await api('/api/admin/activity-review/undo', { method: 'POST' }); notify(`Undone: ${fmt(r.activities)} activities${r.employees ? ` and ${fmt(r.employees)} employees` : ''} restored.`); setLast(null); onDone() }
    catch (ex) { notify(ex.message, true) } finally { setBusy(false) }
  }
  // the figures of a preview, the ones with something to change
  const tiles = r => [[r.adds, 'Activities added'], [r.deletes, 'Activities deleted'], [r.descriptions, 'Descriptions changed'], [r.categories, 'Categories changed'],
    [r.themes_set, 'Categories getting a theme'], [r.new_themes.length, 'New themes'], [r.volumes, 'Volumes changed'], [r.frequencies, 'Frequencies changed'],
    [r.natures, `${prefs.nature.label} changed`], ...FIELD_TILES.map(([k, l]) => [(r.fields || {})[k] || 0, l + ' changed']),
    [r.units, 'Employees: unit changed'], [r.roles, 'Employees: service / support changed']].filter(([n]) => n > 0)
  const r = plan?.r
  const shown = r ? tiles(r) : []
  const nothing = r && !shown.length && !(rm && r.missing)
  return <div className="panel cr-excel">
    <div className="cr-excel-tx"><h3>Review in Excel</h3>
      <span className="formula">Download the activities of all functions or one function, edit them in Excel (unit, service / support, description, category, theme, volume, volume type and more, delete or add rows), then upload. You see a preview first, and Undo Last Upload puts everything back.</span></div>
    <div className="row-actions">
      <button className="btn" disabled={busy} onClick={() => setDl({ fid: functions || '' })}>Download Activities</button>
      <label className="btn pri" style={{ display: 'inline-block' }}>{busy && !dl ? 'Reading…' : 'Upload Changes'}<input type="file" accept=".xlsx,.xlsm" onChange={pick} disabled={busy} style={{ display: 'none' }} /></label>
      {last && <button className="btn" disabled={busy} onClick={undo} title={`Uploaded ${last.at} by ${last.by}`}>Undo Last Upload</button>}
    </div>
    {dl && <Modal title="Download Activities" sub="One Excel file to review and edit, then upload here" onClose={() => setDl(null)}>
      <label className="fld" style={{ display: "flex", flexDirection: "column", gap: 6 }}><span className="fl">Function</span>
        <select value={dl.fid} onChange={e => setDl({ fid: e.target.value })} style={{ minWidth: 320 }}>
          <option value="">All functions ({fmt(fnList.reduce((a, x) => a + (x.activities || 0), 0))} activities)</option>
          {fnList.map(x => <option key={x.id} value={String(x.id)}>{x.name}{x.activities ? ` (${fmt(x.activities)})` : ''}</option>)}</select></label>
      <ul className="formula" style={{ margin: '12px 0 0', paddingLeft: 18, lineHeight: 1.6 }}>
        <li>Edit the green columns; a blank cell leaves the value as it is.</li>
        <li>Unit and Service / support belong to the employee (use the same value on all their rows).</li>
        <li>Write <b>Yes</b> in the red Delete activity column to delete an activity.</li>
        <li>To add an activity, add a row with the employee code and the details, and no Activity ID.</li>
        <li>Each function's file only changes that function's employees, so files can be reviewed and uploaded one at a time.</li>
      </ul>
      <div className="row-actions" style={{ marginTop: 14 }}><button className="btn pri" disabled={busy} onClick={getFile}>{busy ? 'Preparing…' : 'Download'}</button><button className="btn" onClick={() => setDl(null)}>Cancel</button></div>
    </Modal>}
    {r && <Modal wide title="Changes in the File" sub={`${plan.file.name} · sheet "${r.sheet}" · ${fmt(r.rows)} rows, ${fmt(r.matched)} matched${r.by_id ? ' by Activity ID' : ' by employee and activity details'}`} onClose={() => setPlan(null)}>
      {shown.length ? <div className="cr-plan">{shown.map(([n, l]) => <div key={l} className={l.startsWith('Activities deleted') ? 'del' : l.startsWith('Activities added') ? 'add' : ''}><b>{fmt(n)}</b><span>{l}</span></div>)}</div>
        : <p className="formula">No changes found in this file{r.missing ? ' (see the activities not in the file below)' : ''}.</p>}
      {!r.full && <p className="formula">This file is not the review download, so only descriptions, categories, themes and volumes{r.revised.length ? ' (and the Revised columns)' : ''} are read from it. Download the activities here to edit every field, delete or add activities.</p>}
      {r.revised.length > 0 && <p className="formula">Using the <b>Revised</b> columns for: {r.revised.map(k => ({ desc: 'description', cat: 'category', theme: 'theme', freq: 'frequency', vol: 'volume', nat: prefs.nature.label }[k])).join(', ')}.{r.full ? '' : ' The original columns are used to find each activity.'}</p>}
      {r.problem_count > 0 && <div className="msg warn" style={{ marginBottom: 10 }}><b>{fmt(r.problem_count)} values not accepted</b> (left as they are):<ul>{r.problems.slice(0, 8).map((x, i) => <li key={i}>{x}</li>)}</ul>{r.problem_count > 8 && <span className="formula">and {fmt(r.problem_count - 8)} more</span>}</div>}
      {r.new_themes.length > 0 && <p className="formula"><b>New themes:</b> {r.new_themes.join(', ')}</p>}
      {!r.has_theme && <p className="formula">No theme column in this file: themes are left as they are.</p>}
      {r.samples.length > 0 && <div className="tw" style={{ marginTop: 8 }}><table><thead><tr><th>Employee</th><th>Now</th><th>Becomes</th></tr></thead>
        <tbody>{r.samples.map((x, i) => <tr key={i}><td>{x.employee}{x.description && <div className="formula">description</div>}</td><td className="formula">{x.from || '-'}</td><td><b>{x.to}</b></td></tr>)}</tbody></table></div>}
      {r.emp_samples?.length > 0 && <div className="tw" style={{ marginTop: 8 }}><table><thead><tr><th>Employee</th><th>Field</th><th>Now</th><th>Becomes</th></tr></thead>
        <tbody>{r.emp_samples.map((x, i) => <tr key={i}><td>{x.employee}</td><td>{x.what}</td><td className="formula">{x.from || '-'}</td><td><b>{x.to}</b></td></tr>)}</tbody></table></div>}
      {r.emp_conflicts?.length > 0 && <div className="msg warn" style={{ marginTop: 10 }}><b>Different values on one employee's rows</b> (the value used most is applied):<ul>{r.emp_conflicts.slice(0, 8).map((x, i) => <li key={i}>{x}</li>)}</ul></div>}
      {r.adds > 0 && <div className="msg ok" style={{ marginTop: 10 }}><b>{fmt(r.adds)} new activities</b> (rows without an Activity ID):
        <ul style={{ margin: '6px 0 0' }}>{r.add_samples.map((x, i) => <li key={i}>{x.employee}: <b>{x.category || 'No category'}</b> · {x.description || '-'}</li>)}</ul>
        {r.adds > r.add_samples.length && <span className="formula">and {fmt(r.adds - r.add_samples.length)} more</span>}</div>}
      {r.deletes > 0 && <div className="msg warn" style={{ marginTop: 10 }}><b>{fmt(r.deletes)} activities marked Delete</b>:
        <ul style={{ margin: '6px 0 0' }}>{r.delete_samples.map((x, i) => <li key={i}>{x.employee}: <b>{x.category || 'No category'}</b> · {x.description || '-'}</li>)}</ul>
        {r.deletes > r.delete_samples.length && <span className="formula">and {fmt(r.deletes - r.delete_samples.length)} more</span>}</div>}
      <div className="msg" style={{ marginTop: 10 }}><b>Completeness</b>
        <ul style={{ margin: '6px 0 0' }}>
          <li>The file covers <b>{fmt(r.matched)}</b> of the portal's <b>{fmt(r.portal_total)}</b> activities{r.by_details > 0 ? ` (${fmt(r.by_details)} of them had an Activity ID that no longer matches, for example copied from an older file or shifted by sorting one column, and were found by employee and activity details)` : r.by_content > 0 ? ` (${fmt(r.by_content)} found by their details because rows were sorted or moved)` : ''}. Employees who are not in the file are not changed.</li>
          {r.missing > 0 && <li><b>{fmt(r.missing)}</b> activities of the employees in the file are not in it (rows deleted or merged in Excel, or activities added after the download). They stay in the portal unless you tick the box below.</li>}
          <li>After this upload, <b>{r.no_theme_activities ? fmt(r.no_theme_activities) : 'no'}</b> activities{r.no_theme_categories ? ` (${fmt(r.no_theme_categories)} categories)` : ''} still have no theme{r.no_theme_top.length > 0 ? ': ' + r.no_theme_top.map(x => `${x.name} (${x.activities})`).join(', ') + (r.no_theme_categories > r.no_theme_top.length ? ' …' : '') : '.'}</li>
          {r.no_category > 0 && <li><b>{fmt(r.no_category)}</b> activities have no category.</li>}
        </ul></div>
      {r.missing > 0 && <div className="msg warn" style={{ marginTop: 10 }}>
        <label className="chk" style={{ fontSize: 13.5 }}><input type="checkbox" checked={rm} onChange={e => setRm(e.target.checked)} />
          <span><b>Also remove these {fmt(r.missing)} activities from the portal</b> (rows deleted or merged in Excel). Only employees in the file are affected; Undo Last Upload brings them back.</span></label>
        <ul style={{ margin: '6px 0 0' }}>{r.missing_samples.map((x, i) => <li key={i}>{x.employee}: <b>{x.category || 'No category'}</b> · {x.description || '-'}</li>)}</ul>
        {r.missing > r.missing_samples.length && <span className="formula">and {fmt(r.missing - r.missing_samples.length)} more</span>}
      </div>}
      {r.conflicts.length > 0 && <div className="msg warn" style={{ marginTop: 10 }}><b>One category, several themes</b> (the theme used most is applied):<ul>{r.conflicts.map((x, i) => <li key={i}>{x}</li>)}</ul></div>}
      {r.unmatched_count > 0 && <div className="msg warn" style={{ marginTop: 10 }}><b>{fmt(r.unmatched_count)} rows left out</b>:<ul>{r.unmatched.slice(0, 8).map((x, i) => <li key={i}>{x}</li>)}</ul>{r.unmatched_count > 8 && <span className="formula">and {fmt(r.unmatched_count - 8)} more</span>}</div>}
      <div className="row-actions" style={{ marginTop: 14 }}>
        <button className="btn pri" disabled={busy || nothing} onClick={apply}>{nothing ? 'Nothing to Change' : 'Apply Changes'}</button>
        <button className="btn" onClick={() => setPlan(null)}>Cancel</button>
        <span className="formula">Undo Last Upload puts everything back.</span></div>
    </Modal>}
  </div>
}

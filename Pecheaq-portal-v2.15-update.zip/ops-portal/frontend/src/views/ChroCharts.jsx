import React, { useRef, useState } from 'react'

// Small SVG charts for the CHRO dashboard. Colours come from CSS custom properties on .chv (light and dark),
// validated as a set: --c1 teal, --c2 orange, --c3 blue, --c4 yellow (yellow always carries a visible label);
// --before is the muted As Is grey, --after the To Be teal. Text uses the text tokens, never the series colour.
const fmt = v => v === null || v === undefined ? '–' : Number(v).toLocaleString('en-US', { maximumFractionDigits: 1 })
const sgn = v => (v > 0 ? '+' : '') + fmt(v)

// a bar with 4px rounded data end, square at the baseline
const barV = (x, y, w, h, r = 4) => { if (h <= 0) return ''; r = Math.min(r, h, w / 2); return `M${x},${y + h}V${y + r}Q${x},${y} ${x + r},${y}H${x + w - r}Q${x + w},${y} ${x + w},${y + r}V${y + h}Z` }
const barH = (x, y, w, h, r = 4, left = false) => {
  if (w <= 0) return ''; r = Math.min(r, w, h / 2)
  return left ? `M${x + w},${y}H${x + r}Q${x},${y} ${x},${y + r}V${y + h - r}Q${x},${y + h} ${x + r},${y + h}H${x + w}Z`
    : `M${x},${y}H${x + w - r}Q${x + w},${y} ${x + w},${y + r}V${y + h - r}Q${x + w},${y + h} ${x + w - r},${y + h}H${x}Z`
}

// hover tooltip shared by the charts in one card
export function useTip() {
  const [t, setT] = useState(null)
  const ref = useRef(null)
  const on = (e, lines) => { const r = ref.current?.getBoundingClientRect(); if (!r) return; setT({ x: e.clientX - r.left, y: e.clientY - r.top, lines }) }
  const off = () => setT(null)
  const el = t && <div className="chv-tip" style={{ left: Math.min(t.x + 14, (ref.current?.clientWidth || 600) - 220), top: t.y + 14 }}>
    {t.lines.map((l, i) => <div key={i} className={i === 0 ? 'chv-tip-h' : ''}>{l}</div>)}</div>
  return { ref, on, off, el }
}

export function Legend({ items }) {
  return <div className="chv-leg">{items.map(it => <span key={it.label}><i style={{ background: it.color }} />{it.label}</span>)}</div>
}

// ---------------------------------------------------------------- headcount bridge (waterfall)
export function Bridge({ steps, height = 230 }) {
  const tip = useTip()
  const W = 640, H = height, pad = { l: 8, r: 8, t: 22, b: 40 }
  let run = 0
  const bars = steps.map(s => {
    if (s.kind === 'total') { const b = { ...s, from: 0, to: s.v }; run = s.v; return b }
    const from = run; run = run + s.v; return { ...s, from, to: run }
  })
  const hi = Math.max(...bars.map(b => Math.max(b.from, b.to)))
  const lo = Math.min(...bars.filter(b => b.kind === 'total').map(b => b.v)) * 0.92   // zoom in on the change (labelled)
  const base = Math.max(0, Math.floor(lo / 50) * 50)
  const y = v => pad.t + (H - pad.t - pad.b) * (1 - (v - base) / Math.max(1, hi - base))
  const bw = (W - pad.l - pad.r) / bars.length
  return <div className="chv-box" ref={tip.ref}>
    <svg viewBox={`0 0 ${W} ${H}`} className="chv-svg" role="img" aria-label="Headcount bridge from As Is to To Be">
      <line x1={pad.l} x2={W - pad.r} y1={y(base)} y2={y(base)} className="chv-axis" />
      {bars.map((b, i) => {
        const x = pad.l + i * bw + bw * 0.18, w = bw * 0.64
        const top = y(Math.max(b.from, b.to)), bot = b.kind === 'total' ? y(base) : y(Math.min(b.from, b.to))
        const h = Math.max(b.v ? 2 : 0, bot - top)
        const cls = b.kind === 'total' ? 'chv-total' : b.v < 0 ? 'chv-down' : 'chv-up'
        return <g key={i} onMouseMove={e => tip.on(e, [b.label, b.kind === 'total' ? `${fmt(b.v)} people` : `${sgn(b.v)} people`, ...(b.note ? [b.note] : [])])} onMouseLeave={tip.off}>
          <rect x={pad.l + i * bw} y={pad.t - 10} width={bw} height={H - pad.t - pad.b + 10} fill="transparent" />
          <path d={barV(x, top, w, h)} className={cls} />
          {i < bars.length - 1 && <line x1={x + w} x2={x + bw} y1={y(b.to)} y2={y(b.to)} className="chv-conn" />}
          <text x={x + w / 2} y={top - 6} className="chv-val" textAnchor="middle">{b.kind === 'total' ? fmt(b.v) : b.v ? sgn(b.v) : '0'}</text>
          <text x={x + w / 2} y={H - pad.b + 16} className="chv-lab" textAnchor="middle">{b.label.split(' ').slice(0, 2).join(' ')}</text>
          <text x={x + w / 2} y={H - pad.b + 29} className="chv-lab" textAnchor="middle">{b.label.split(' ').slice(2).join(' ')}</text>
        </g>
      })}
      {base > 0 && <text x={pad.l} y={y(base) - 4} className="chv-lab">axis from {fmt(base)}</text>}
    </svg>{tip.el}</div>
}

// ---------------------------------------------------------------- grouped vertical bars: As Is vs To Be per category
export function Grouped({ cats, a, b, height = 220, unit = 'managers' }) {
  const tip = useTip()
  const W = 560, H = height, pad = { l: 34, r: 8, t: 18, b: 28 }
  const mx = Math.max(1, ...a, ...b)
  const step = Math.pow(10, Math.floor(Math.log10(mx))) * (mx / Math.pow(10, Math.floor(Math.log10(mx))) > 5 ? 2 : 1)
  const top = Math.ceil(mx / step) * step
  const y = v => pad.t + (H - pad.t - pad.b) * (1 - v / top)
  const gw = (W - pad.l - pad.r) / cats.length, bw = Math.min(26, gw * 0.32)
  const ticks = []; for (let v = 0; v <= top; v += step) ticks.push(v)
  return <div className="chv-box" ref={tip.ref}>
    <svg viewBox={`0 0 ${W} ${H}`} className="chv-svg" role="img">
      {ticks.map(t => <g key={t}><line x1={pad.l} x2={W - pad.r} y1={y(t)} y2={y(t)} className={t ? 'chv-grid' : 'chv-axis'} /><text x={pad.l - 6} y={y(t) + 4} textAnchor="end" className="chv-lab">{fmt(t)}</text></g>)}
      {cats.map((c, i) => {
        const cx = pad.l + i * gw + gw / 2
        return <g key={c} onMouseMove={e => tip.on(e, [c, `As Is: ${fmt(a[i])} ${unit}`, `To Be: ${fmt(b[i])} ${unit}`, `Change: ${sgn(b[i] - a[i])}`])} onMouseLeave={tip.off}>
          <rect x={pad.l + i * gw} y={pad.t} width={gw} height={H - pad.t - pad.b} fill="transparent" />
          <path d={barV(cx - bw - 1, y(a[i]), bw, y(0) - y(a[i]))} className="chv-before" />
          <path d={barV(cx + 1, y(b[i]), bw, y(0) - y(b[i]))} className="chv-after" />
          <text x={cx + 1 + bw / 2} y={y(b[i]) - 5} textAnchor="middle" className="chv-val">{fmt(b[i])}</text>
          <text x={cx} y={H - 9} textAnchor="middle" className="chv-lab">{c}</text></g>
      })}
    </svg>{tip.el}</div>
}

// ---------------------------------------------------------------- layer pyramid: As Is left, To Be right
export function Pyramid({ rows }) {
  const tip = useTip()
  const W = 560, rh = 24, pad = { t: 22, b: 6 }, mid = W / 2, lab = 30
  const H = pad.t + rows.length * rh + pad.b
  const mx = Math.max(1, ...rows.map(r => Math.max(r.a, r.b)))
  const sc = v => (mid - lab - 40) * v / mx
  return <div className="chv-box" ref={tip.ref}>
    <svg viewBox={`0 0 ${W} ${H}`} className="chv-svg" role="img">
      <text x={mid - lab - 4} y={13} textAnchor="end" className="chv-lab chv-b">As Is</text><text x={mid + lab + 4} y={13} className="chv-lab chv-b">To Be</text>
      {rows.map((r, i) => {
        const yy = pad.t + i * rh, h = rh - 6, wa = sc(r.a), wb = sc(r.b)
        return <g key={r.l} onMouseMove={e => tip.on(e, [r.l, `As Is: ${fmt(r.a)} people`, `To Be: ${fmt(r.b)} people`, `Change: ${sgn(r.b - r.a)}`])} onMouseLeave={tip.off}>
          <rect x={0} y={yy} width={W} height={rh} fill="transparent" />
          <path d={barH(mid - lab - wa, yy, wa, h, 4, true)} className="chv-before" />
          <path d={barH(mid + lab, yy, wb, h)} className="chv-after" />
          <text x={mid} y={yy + h / 2 + 4} textAnchor="middle" className="chv-lab chv-b">{r.l}</text>
          <text x={mid - lab - wa - 5} y={yy + h / 2 + 4} textAnchor="end" className="chv-val">{fmt(r.a)}</text>
          <text x={mid + lab + wb + 5} y={yy + h / 2 + 4} className="chv-val">{fmt(r.b)}{r.b !== r.a ? <tspan className="chv-lab"> ({sgn(r.b - r.a)})</tspan> : null}</text></g>
      })}
    </svg>{tip.el}</div>
}

// ---------------------------------------------------------------- horizontal stacked bars (one row per item)
export function StackH({ rows, keys, onRow, labelW = 190 }) {
  const tip = useTip()
  const W = 600, rh = 26, pad = { t: 4, b: 4 }
  const H = pad.t + rows.length * rh + pad.b
  const tot = r => keys.reduce((a, k) => a + (r.parts[k.k] || 0), 0)
  const mx = Math.max(1, ...rows.map(tot))
  const sc = v => (W - labelW - 50) * v / mx
  return <div className="chv-box" ref={tip.ref}>
    <svg viewBox={`0 0 ${W} ${H}`} className="chv-svg" role="img">
      {rows.map((r, i) => {
        const yy = pad.t + i * rh; let x = labelW
        const segs = keys.filter(k => r.parts[k.k]).map(k => { const w = sc(r.parts[k.k]); const s = { k, x, w }; x += w; return s })
        return <g key={r.label} className={onRow ? 'chv-click' : ''} onClick={onRow ? () => onRow(r) : undefined}
          onMouseMove={e => tip.on(e, [r.label, ...keys.filter(k => r.parts[k.k]).map(k => `${k.label}: ${fmt(r.parts[k.k])}`), `Total: ${fmt(tot(r))}`])} onMouseLeave={tip.off}>
          <rect x={0} y={yy} width={W} height={rh} fill="transparent" />
          <text x={labelW - 8} y={yy + rh / 2 + 4} textAnchor="end" className="chv-lab chv-ink">{r.label.length > 30 ? r.label.slice(0, 29) + '…' : r.label}</text>
          {segs.map((s, j) => <path key={s.k.k} d={j === segs.length - 1 ? barH(s.x, yy + 4, Math.max(0, s.w - (j ? 0 : 0)), rh - 8) : `M${s.x},${yy + 4}h${Math.max(0, s.w - 2)}v${rh - 8}h${-Math.max(0, s.w - 2)}Z`} style={{ fill: s.k.color }} />)}
          <text x={x + 6} y={yy + rh / 2 + 4} className="chv-val">{fmt(tot(r))}</text></g>
      })}
    </svg>{tip.el}</div>
}

// ---------------------------------------------------------------- dumbbell: a value moving from As Is to To Be per item
export function Dumbbell({ rows, unit = '', labelW = 190, onRow }) {
  const tip = useTip()
  const W = 600, rh = 26, pad = { t: 22, b: 6 }
  const H = pad.t + rows.length * rh + pad.b
  const mx = Math.max(1, ...rows.map(r => Math.max(r.a, r.b))) * 1.08
  const x = v => labelW + (W - labelW - 30) * v / mx
  const ticks = [0, mx / 4, mx / 2, (3 * mx) / 4].map(v => Math.round(v))
  return <div className="chv-box" ref={tip.ref}>
    <svg viewBox={`0 0 ${W} ${H}`} className="chv-svg" role="img">
      {ticks.map(t => <g key={t}><line x1={x(t)} x2={x(t)} y1={pad.t - 4} y2={H - pad.b} className="chv-grid" /><text x={x(t)} y={12} textAnchor="middle" className="chv-lab">{fmt(t)}</text></g>)}
      {rows.map((r, i) => {
        const yy = pad.t + i * rh + rh / 2
        return <g key={r.label} className={onRow ? 'chv-click' : ''} onClick={onRow ? () => onRow(r) : undefined}
          onMouseMove={e => tip.on(e, [r.label, `As Is: ${fmt(r.a)}${unit}`, `To Be: ${fmt(r.b)}${unit}`, `Change: ${sgn(Math.round((r.b - r.a) * 10) / 10)}`])} onMouseLeave={tip.off}>
          <rect x={0} y={yy - rh / 2} width={W} height={rh} fill="transparent" />
          <text x={labelW - 8} y={yy + 4} textAnchor="end" className="chv-lab chv-ink">{r.label.length > 30 ? r.label.slice(0, 29) + '…' : r.label}</text>
          <line x1={x(r.a)} x2={x(r.b)} y1={yy} y2={yy} className="chv-db" />
          <circle cx={x(r.a)} cy={yy} r={5} className="chv-before chv-ring" />
          <circle cx={x(r.b)} cy={yy} r={5.5} className="chv-after chv-ring" />
          <text x={Math.max(x(r.a), x(r.b)) + 10} y={yy + 4} className="chv-val">{fmt(r.b)}</text></g>
      })}
    </svg>{tip.el}</div>
}

// ---------------------------------------------------------------- 100% bars: the mix of one side
export function Mix100({ rows, keys }) {
  const tip = useTip()
  return <div className="chv-box chv-mix" ref={tip.ref}>{rows.map(r => {
    const tot = keys.reduce((a, k) => a + (r.parts[k.k] || 0), 0) || 1
    return <div key={r.label} className="chv-mixrow"><span className="chv-mixlab">{r.label}</span>
      <div className="chv-mixbar">{keys.filter(k => r.parts[k.k]).map(k => <i key={k.k} style={{ width: (r.parts[k.k] / tot * 100) + '%', background: k.color }}
        onMouseMove={e => tip.on(e, [`${r.label} · ${k.label}`, `${fmt(r.parts[k.k])} people (${Math.round(r.parts[k.k] / tot * 100)}%)`])} onMouseLeave={tip.off}>
        {r.parts[k.k] / tot > 0.09 ? <b>{Math.round(r.parts[k.k] / tot * 100)}%</b> : null}</i>)}</div></div>
  })}{tip.el}</div>
}

// ---------------------------------------------------------------- grade mix: paired horizontal bars per grade
export function PairH({ rows, labelW = 84, W = 360 }) {
  const tip = useTip()
  const rh = 24, pad = { t: 4, b: 4 }
  const H = pad.t + rows.length * rh + pad.b
  const mx = Math.max(1, ...rows.map(r => Math.max(r.a, r.b)))
  const sc = v => (W - labelW - 74) * v / mx
  return <div className="chv-box" ref={tip.ref}>
    <svg viewBox={`0 0 ${W} ${H}`} className="chv-svg" role="img">
      {rows.map((r, i) => {
        const yy = pad.t + i * rh
        return <g key={r.l} onMouseMove={e => tip.on(e, [r.l, `As Is: ${fmt(r.a)}`, `To Be: ${fmt(r.b)}`, `Change: ${sgn(r.b - r.a)}`])} onMouseLeave={tip.off}>
          <rect x={0} y={yy} width={W} height={rh} fill="transparent" />
          <text x={labelW - 8} y={yy + rh / 2 + 4} textAnchor="end" className="chv-lab chv-ink">{r.l}</text>
          <path d={barH(labelW, yy + 3, sc(r.a), 9, 3)} className="chv-before" />
          <path d={barH(labelW, yy + 14, sc(r.b), 9, 3)} className="chv-after" />
          <text x={labelW + Math.max(sc(r.a), sc(r.b)) + 6} y={yy + rh / 2 + 4} className="chv-val">{fmt(r.b)}{r.b !== r.a ? <tspan className="chv-lab"> ({sgn(r.b - r.a)})</tspan> : null}</text></g>
      })}
    </svg>{tip.el}</div>
}

// ---------------------------------------------------------------- one segmented bar (e.g. the grade benchmark tiers)
export function Segments({ parts }) {
  const tip = useTip()
  const tot = parts.reduce((a, p) => a + p.v, 0) || 1
  return <div className="chv-box" ref={tip.ref}><div className="chv-mixbar chv-seg">{parts.filter(p => p.v).map(p => <i key={p.label} style={{ width: Math.max(2, p.v / tot * 100) + '%', background: p.color }}
    onMouseMove={e => tip.on(e, [p.label, `${fmt(p.v)} people (${Math.round(p.v / tot * 100)}%)`])} onMouseLeave={tip.off} />)}</div>
    <div className="chv-segleg">{parts.map(p => <div key={p.label}><i style={{ background: p.color }} /><b>{fmt(p.v)}</b><span>{p.label}</span></div>)}</div>{tip.el}</div>
}

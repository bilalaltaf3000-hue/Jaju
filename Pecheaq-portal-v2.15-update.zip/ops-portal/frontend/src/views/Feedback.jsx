import React, { useEffect, useState } from 'react'
import { api, download } from '../api.js'
import { fmt } from '../org.js'
import { Modal } from '../ui.jsx'

// Feedback from any login about any change; the admin reads it in Admin, Feedback.
const TOPICS = ['Suggestion', 'Employee change']   // earlier topics (change request, issue, other) still show in the lists
const TOPIC_LABEL = { 'Change request': 'Change Request', 'Employee change': 'Employee Change', Issue: 'Issue', Suggestion: 'Suggestion', Other: 'Other' }
const STATUSES = ['New', 'Under review', 'Done', 'Not planned']
const STATUS_LABEL = { New: 'New', 'Under review': 'Under Review', Done: 'Done', 'Not planned': 'Not Planned' }
const STATUS_PILL = { New: 'p-warn', 'Under review': '', Done: 'p-ok', 'Not planned': 'p-bad' }
const when = s => s ? new Date(s + (s.endsWith('Z') ? '' : 'Z')).toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''

export function FeedbackModal({ pages, page: page0, notify, onClose }) {
  const [topic, setTopic] = useState('Suggestion')
  const [page, setPage] = useState(page0 || '')
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState(false)
  const [mine, setMine] = useState(null)
  const load = () => api('/api/feedback/mine').then(setMine).catch(() => setMine([]))
  useEffect(() => { load() }, [])
  const [ch, setCh] = useState({ type: 'retag' })
  const isChange = topic === 'Employee change'
  const chOk = !isChange || (ch.type === 'add' ? (ch.new_code || '').trim() && (ch.name || '').trim() && ch.function_id && ch.manager_code
    : ch.code && (ch.type === 'remove' || ch.manager_code || ch.function_id || (ch.unit || '').trim()))
  const send = () => {
    setBusy(true)
    api('/api/feedback', { method: 'POST', body: { topic, page, message: msg, change: isChange ? ch : null } })
      .then(() => { setMsg(''); setCh({ type: ch.type }); notify && notify(isChange ? 'Request sent to the admin.' : 'Thank you. Your feedback has been sent.'); load() })
      .catch(e => notify && notify(e.message, true)).finally(() => setBusy(false))
  }
  return <Modal title="Feedback" sub="Share a suggestion, or ask for an employee change" onClose={onClose}>
    <div className="fb-form">
      <div className="fb-row">
        <label>Topic<div className="seg sm" role="group">{TOPICS.map(t => <button key={t} type="button" aria-pressed={topic === t} onClick={() => setTopic(t)}>{TOPIC_LABEL[t]}</button>)}</div></label>
        <label>Page<select value={page} onChange={e => setPage(e.target.value)}><option value="">General</option>{pages.map(p => <option key={p} value={p}>{p}</option>)}</select></label>
      </div>
      {isChange && <EmployeeChange ch={ch} setCh={setCh} />}
      <label>{isChange ? 'Reason (Optional)' : 'Your Feedback'}<textarea rows={isChange ? 3 : 6} value={msg} onChange={e => setMsg(e.target.value)} placeholder={isChange ? 'Why this change is needed' : 'Your suggestion'} maxLength={5000} autoFocus={!isChange} /></label>
      <div className="row-actions"><button className="btn pri" disabled={busy || (isChange ? !chOk : msg.trim().length < 3)} onClick={send}>{busy ? 'Sending…' : isChange ? 'Send Request' : 'Send Feedback'}</button>
        <span className="formula">{msg.length ? `${fmt(msg.length)} / 5,000` : ''}</span></div>
    </div>
    {mine && mine.length > 0 && <div className="fb-mine">
      <h3>My Feedback</h3>
      <ul>{mine.map(f => <li key={f.id}>
        <div className="fb-meta"><span className={'pill ' + (STATUS_PILL[f.status] || '')}>{STATUS_LABEL[f.status] || f.status}</span><b>{TOPIC_LABEL[f.topic] || f.topic}</b>{f.page && <span>· {f.page}</span>}<em>{when(f.at)}</em></div>
        {f.change_text && <p className="fb-change">{f.change_text}</p>}
        {f.message && f.message !== '-' && <p>{f.message}</p>}
        {f.reply && <div className="fb-reply"><b>Reply</b> {f.reply}</div>}
      </li>)}</ul>
    </div>}
  </Modal>
}

function EmpPicker({ list, valueEmp, onPick, qv, setQv, placeholder, exclude }) {
  const ql = (qv || '').trim().toLowerCase()
  const hits = list.filter(e => e.code !== exclude && (!ql || (e.name + ' ' + e.code + ' ' + e.position).toLowerCase().includes(ql))).slice(0, 60)
  if (valueEmp) return <div className="chosen" style={{ margin: '4px 0 0' }}><span><b>{valueEmp.name}</b><small>{[valueEmp.position, valueEmp.grade, valueEmp.code, valueEmp.function].filter(Boolean).join(' · ')}</small></span><button type="button" className="linkbtn" onClick={() => onPick('')}>Change</button></div>
  return <><input className="inp" placeholder={placeholder} value={qv} onChange={e => setQv(e.target.value)} />
    <div className="pick" style={{ maxHeight: 180 }}>{hits.map(e => <button key={e.code} type="button" onClick={() => { onPick(e.code); setQv('') }}><span><b>{e.name}</b><small>{[e.position, e.grade, e.code, e.unit].filter(Boolean).join(' · ')}</small></span></button>)}
      {!hits.length && <div className="formula" style={{ padding: 8 }}>No employee matches.</div>}</div></>
}

// the employee change a POC asks for: re-tag, remove or add (employees of their own function or unit)
function EmployeeChange({ ch, setCh }) {
  const [d, setD] = useState(null)
  const [q, setQ] = useState('')
  const [mq, setMq] = useState('')
  useEffect(() => { api('/api/feedback/employees').then(setD).catch(() => setD({ employees: [], functions: [], units: {} })) }, [])
  if (!d) return <div className="formula">Loading employees…</div>
  const set = (k, v) => setCh(c => ({ ...c, [k]: v }))
  const emp = d.employees.find(e => e.code === ch.code)
  const mgr = d.employees.find(e => e.code === ch.manager_code)
  const fnId = ch.type === 'add' ? ch.function_id : (ch.function_id || emp?.function_id)
  const units = fnId ? d.units[String(fnId)] || [] : []

  return <div className="fb-changebox">
    <label>Type of Change<div className="seg sm" role="group">{[['retag', 'Re-tag'], ['remove', 'Remove'], ['add', 'Add']].map(([k, l]) => <button key={k} type="button" aria-pressed={ch.type === k} onClick={() => setCh({ type: k })}>{l}</button>)}</div></label>
    {ch.type !== 'add' && <label>Employee<EmpPicker list={d.employees} valueEmp={emp} onPick={v => set('code', v)} qv={q} setQv={setQ} placeholder="Find by name, code or position" /></label>}
    {ch.type === 'retag' && emp && <>
      <div className="formula">Today: reports to {emp.manager_name || '-'}{emp.unit ? `, unit ${emp.unit}` : ''}, {emp.function}</div>
      <label>New Manager (Optional)<EmpPicker list={d.employees} valueEmp={mgr} onPick={v => set('manager_code', v)} qv={mq} setQv={setMq} placeholder="Find the new manager" exclude={emp.code} /></label>
      <div className="fb-row">
        <label>New Function (Optional)<select value={ch.function_id || ''} onChange={e => set('function_id', e.target.value ? +e.target.value : null)}><option value="">Same function</option>{d.functions.filter(f => f.id !== emp.function_id).map(f => <option key={f.id} value={f.id}>{f.name}</option>)}</select></label>
        <label>New Unit (Optional)<input className="inp" list="fb-units" value={ch.unit || ''} onChange={e => set('unit', e.target.value)} placeholder="Same unit" /></label>
      </div></>}
    {ch.type === 'add' && <>
      <div className="fb-row">
        <label>Employee Code<input className="inp" value={ch.new_code || ''} onChange={e => set('new_code', e.target.value)} /></label>
        <label style={{ flex: 1 }}>Full Name<input className="inp" value={ch.name || ''} onChange={e => set('name', e.target.value)} /></label>
      </div>
      <div className="fb-row">
        <label style={{ flex: 1 }}>Position<input className="inp" value={ch.position || ''} onChange={e => set('position', e.target.value)} /></label>
        <label>Grade<input className="inp" value={ch.grade || ''} onChange={e => set('grade', e.target.value)} style={{ width: 110 }} /></label>
        <label>Type<select value={ch.emp_type || 'FTE'} onChange={e => set('emp_type', e.target.value)}><option>FTE</option><option>FTC</option></select></label>
      </div>
      <div className="fb-row">
        <label>Function<select value={ch.function_id || ''} onChange={e => set('function_id', e.target.value ? +e.target.value : null)}><option value="">Choose</option>{[...new Map(d.employees.map(e => [e.function_id, e.function])).entries()].map(([id, n]) => <option key={id} value={id}>{n}</option>)}</select></label>
        <label>Unit<input className="inp" list="fb-units" value={ch.unit || ''} onChange={e => set('unit', e.target.value)} /></label>
      </div>
      <label>Reports To<EmpPicker list={d.employees} valueEmp={mgr} onPick={v => set('manager_code', v)} qv={mq} setQv={setMq} placeholder="Find the manager" /></label></>}
    <datalist id="fb-units">{units.map(u => <option key={u} value={u} />)}</datalist>
  </div>
}

export function FeedbackAdmin({ notify }) {
  const [rows, setRows] = useState(null)
  const [st, setSt] = useState('')
  const [edit, setEdit] = useState({})
  const load = () => api('/api/feedback').then(setRows).catch(e => notify(e.message, true))
  useEffect(() => { load() }, [])
  const save = (f, patch) => api(`/api/feedback/${f.id}`, { method: 'PUT', body: patch })
    .then(n => { setRows(rs => rs.map(r => r.id === n.id ? n : r)); notify('Saved.') }).catch(e => notify(e.message, true))
  const del = f => { if (!confirm('Delete this feedback?')) return; api(`/api/feedback/${f.id}`, { method: 'DELETE' }).then(load).catch(e => notify(e.message, true)) }
  if (!rows) return <div className="loading">Loading…</div>
  const list = rows.filter(r => !st || r.status === st)
  const count = s => rows.filter(r => r.status === s).length
  return <div>
    <div className="kvline" style={{ alignItems: 'center' }}>
      <div className="seg sm" role="group">{[['', `All (${fmt(rows.length)})`], ...STATUSES.map(s => [s, `${STATUS_LABEL[s]} (${fmt(count(s))})`])].map(([v, l]) => <button key={v} type="button" aria-pressed={st === v} onClick={() => setSt(v)}>{l}</button>)}</div>
      <button className="btn" style={{ marginLeft: 'auto' }} disabled={!rows.length} onClick={() => download('/api/feedback/export.csv', 'portal_feedback.csv').catch(e => notify(e.message, true))}>Download CSV</button>
    </div>
    {!list.length ? <div className="empty">No feedback{st ? ` marked ${STATUS_LABEL[st]}` : ' yet'}.</div> :
      <div className="fb-admin">{list.map(f => <article key={f.id} className="panel">
        <div className="fb-meta"><span className={'pill ' + (STATUS_PILL[f.status] || '')}>{STATUS_LABEL[f.status] || f.status}</span><b>{f.full_name || f.username}</b><span>({f.username})</span>
          <span>· {TOPIC_LABEL[f.topic] || f.topic}{f.page ? ` · ${f.page}` : ''}</span><em>{when(f.at)}</em></div>
        {f.change_text && <p className="fb-change">{f.change_text}</p>}
        {f.message && f.message !== '-' && <p>{f.message}</p>}
        <div className="fb-act">
          {f.change && f.status !== 'Done' && <button className="btn pri" onClick={() => confirm(`Apply this change?\n\n${f.change_text}`) && api(`/api/feedback/${f.id}/apply`, { method: 'POST' })
            .then(n => { setRows(rs => rs.map(r => r.id === n.id ? n : r)); notify('Change applied.') }).catch(e => notify(e.message, true))}>Apply</button>}
          {f.change && f.status !== 'Done' && f.status !== 'Not planned' && <button className="btn" onClick={() => save(f, { status: 'Not planned', reply: edit[f.id] ?? f.reply })}>Reject</button>}
          <select value={f.status} onChange={e => save(f, { status: e.target.value })}>{STATUSES.map(s => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}</select>
          <input className="inp" placeholder="Reply to the person (optional)" value={edit[f.id] ?? f.reply} onChange={e => setEdit(x => ({ ...x, [f.id]: e.target.value }))} />
          <button className="btn" disabled={(edit[f.id] ?? f.reply) === f.reply} onClick={() => save(f, { reply: edit[f.id] ?? '' })}>Save Reply</button>
          <button className="btn" onClick={() => del(f)}>Delete</button>
        </div>
      </article>)}</div>}
  </div>
}

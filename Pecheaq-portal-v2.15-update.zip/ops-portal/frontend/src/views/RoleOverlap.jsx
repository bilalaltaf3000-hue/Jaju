import React, { useEffect, useMemo, useState } from 'react'
import { api, download } from '../api.js'
import { fmt, short, vfmt } from '../org.js'
import { Modal } from '../ui.jsx'
import { canDecisions } from '../rights.js'
import { SummaryRunPanel } from './Summary.jsx'

// Role Overlap: the on-premise AI compares supervisors with their direct reports, and colleagues with each other.
// Everything here is for HR to review; nothing in the portal's data changes. Only the admin runs the AI.
const FLAG = { team_work: ['Doing team\'s work', 'c-red'], single: ['Single report', 'c-amb'], near: ['Near-identical', 'c-red'], supervisory: ['Mainly supervisory', 'c-teal'], few: ['Few activities', 'c-gray'] }
const REGION = { same: ['Same region', 'c-red'], different: ['Different regions', 'c-teal'], unknown: ['Region not set', 'c-amb'] }
const STATUS_COL = { Open: 'c-gray', 'Under review': 'c-blue', Confirmed: 'c-teal', Dismissed: 'c-gray' }
const heat = (n, hi) => n >= hi ? 'h3' : n >= Math.max(1, hi / 2) ? 'h2' : n > 0 ? 'h1' : 'h0'
const when = s => s ? new Date(s + (s.length <= 16 ? ':00' : '') + 'Z').toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : ''
const n0 = v => Number(v || 0).toLocaleString('en-US')
const Chip = ({ c, children }) => <span className={'ro-chip ' + c}>{children}</span>

function RunBar({ run, canRun, fid, onStart, onStop, label }) {
  const going = run && (run.status === 'queued' || run.status === 'running')
  const pct = run && run.total ? Math.round((run.done + run.failed) / run.total * 100) : 0
  return <span className="ro-run">
    {going ? <span className="ro-prog"><i><b style={{ width: pct + '%' }} /></i><span>{run.status === 'queued' ? 'Starting…' : `${pct}% · ${run.current || ''}`}</span></span>
      : run ? <span className="formula">{run.status === 'done' ? `Last run ${when(run.finished_at)} · ${fmt(run.total)} AI requests · ${Math.max(1, Math.round(run.seconds / 60))} min${run.failed ? ` · ${fmt(run.failed)} failed` : ''}`
        : run.status === 'cancelled' ? `Last run stopped ${when(run.finished_at)}` : `Last run failed ${when(run.finished_at)}`}</span> : null}
    {canRun && (going ? <button className="btn" onClick={onStop}>Stop</button> : <button className="btn pri" onClick={() => onStart(fid)}>{label}</button>)}
  </span>
}

function CaseBox({ d, fid, notify, onSaved, user }) {
  const [st, setSt] = useState(d.case.status)
  const [note, setNote] = useState(d.case.note)
  const [busy, setBusy] = useState(false)
  useEffect(() => { setSt(d.case.status); setNote(d.case.note) }, [d.key, d.case.status, d.case.note])
  const save = async (extra = {}) => {
    setBusy(true)
    try { const c = await api('/api/ro/case', { method: 'PATCH', body: { key: d.key, function_id: fid, status: st, note, ...extra } }); notify('Review saved.'); onSaved(c) }
    catch (e) { notify(e.message, true) } finally { setBusy(false) }
  }
  const rec = async () => {
    const subject = prompt('Subject of the Recommendation', d.recSubject)
    if (!subject) return
    try { await api('/api/ro/case/recommend', { method: 'POST', body: { key: d.key, function_id: fid, subject, details: d.recDetails } }); notify('Recommendation added.'); onSaved() }
    catch (e) { notify(e.message, true) }
  }
  return <div className="ro-case panel">
    <label>HR review<span className="seg sm" role="group">{['Open', 'Under review', 'Confirmed', 'Dismissed'].map(s => <button key={s} type="button" aria-pressed={st === s} onClick={() => setSt(s)}>{s}</button>)}</span></label>
    <label>Note<textarea rows={2} value={note} maxLength={4000} onChange={e => setNote(e.target.value)} placeholder="For example: volume needs two people; checked with the unit head" /></label>
    <div className="row-actions"><button className="btn pri" disabled={busy} onClick={() => save()}>{busy ? 'Saving…' : 'Save Review'}</button>
      {d.case.updated_by && <span className="formula">Last saved by {d.case.updated_by}{d.case.updated_at ? ', ' + when(d.case.updated_at) : ''}</span>}
      <span style={{ flex: 1 }} />
      {d.case.decision_id ? <span className="formula">Added as a Recommendation</span> : canDecisions(user) && <button className="btn" onClick={rec}>Add as Recommendation</button>}</div>
  </div>
}

function Decide({ k, dec, onSet }) {
  const v = dec[k] || ''
  return <span className="ro-dec">
    <button type="button" className={v === 'confirmed' ? 'on ok' : ''} onClick={() => onSet(k, v === 'confirmed' ? '' : 'confirmed')} title="The same work">Confirm</button>
    <button type="button" className={v === 'rejected' ? 'on no' : ''} onClick={() => onSet(k, v === 'rejected' ? '' : 'rejected')} title="Not the same work">Not the same</button></span>
}

const isVol = a => (a.volume || 0) > 0 || (a.vday || 0) > 0
const volTxt = a => a.volume ? `Volume ${vfmt(a.volume)} ${(a.freq || '').toLowerCase()}${a.freq && a.freq !== 'Daily' && a.vday ? ` (≈ ${vfmt(a.vday)} a day)` : ''}` : `≈ ${vfmt(a.vday)} a day`
function VolGroups({ list, render, cols }) {   // volume-based activities first, then the others
  const v = list.filter(isVol), n = list.filter(a => !isVol(a))
  return [[v, 'Volume-based activities'], [n, 'Non-volume-based activities']].filter(([l]) => l.length).map(([l, t]) => cols
    ? <tbody key={t}><tr className="ro-vg"><td colSpan={cols}>{t} ({l.length})</td></tr>{l.map(render)}</tbody>
    : <React.Fragment key={t}><div className="ro-vg">{t} ({l.length})</div>{l.map(render)}</React.Fragment>)
}

function Act({ a, children }) {
  return <div className="ro-act"><div>{a.desc || <i className="formula">No description</i>}</div>
    <small>{[a.cat, a.process, isVol(a) ? volTxt(a) : a.freq].filter(Boolean).join(' · ')}</small>{children}</div>
}

function SupervisorModal({ fid, code, notify, onClose, onChanged, user }) {
  const [d, setD] = useState(null)
  const [view, setView] = useState('common')
  const load = () => api(`/api/ro/supervisor/${fid}/${encodeURIComponent(code)}`).then(setD).catch(e => { notify(e.message, true); onClose() })
  useEffect(() => { load() }, [code])
  const setDec = async (k, v) => {
    try { const c = await api('/api/ro/case', { method: 'PATCH', body: { key: d.key, function_id: fid, decision: { [k]: v } } }); setD(x => ({ ...x, case: c })); onChanged() } catch (e) { notify(e.message, true) }
  }
  if (!d) return <Modal wide title="Loading…" onClose={onClose}><div className="loading">Loading…</div></Modal>
  const s = d.supervisor, f = d.figures, dec = d.case.decisions || {}
  const byA = {}
  d.matches.forEach(m => { (byA[m.a] = byA[m.a] || []).push(m) })
  const actOf = {}
  d.reports.forEach(r => r.acts.forEach(a => { actOf[a.id] = { ...a, who: r.code } }))
  const reps = d.reports
  const common = s.acts.filter(a => (byA[a.id] || []).some(m => !m.check))
  const unique = s.acts.filter(a => !common.includes(a))
  const repsC = reps.filter(r => d.matches.some(m => !m.check && actOf[m.b] && actOf[m.b].who === r.code))
  return <Modal wide title={`${s.name} · ${s.position || 'Supervisor'}`} sub={`${[s.grade, `${fmt(f.team)} direct report${f.team === 1 ? '' : 's'}`, `${fmt(f.activities)} activities`, s.region].filter(Boolean).join(' · ')} · analysed ${when(d.at)}`} onClose={onClose}>
    <div className="ro-figs"><span><b>{f.matched} of {f.activities}</b> activities also done by the team ({f.same_pct}%)</span>
      {f.supervisory_pct != null && <span><b>{f.supervisory_pct}%</b> supervisory work</span>}
      {f.overlap_fte > 0 && <span title="Indicative: the share of the supervisor's activities also done by the team"><b>≈ {f.overlap_fte} FTE</b> of overlapping work</span>}
      {f.flags.map(x => FLAG[x] && <Chip key={x} c={FLAG[x][1]}>{FLAG[x][0]}{x === 'near' && d.near.length ? `: ${d.near.join(', ')}` : ''}</Chip>)}</div>
    {f.flags.includes('few') && <div className="ro-note">Only {f.activities} {f.activities === 1 ? 'activity was' : 'activities were'} captured for {s.name}, too few for a percentage to mean anything, so this supervisor is not flagged or counted in the FTE. Ask for the full list of activities first.</div>}
    {d.summary && <div className="ro-ai"><b>{f.checks || f.flags.includes('few') ? 'Summary:' : 'AI summary:'}</b> {d.summary}</div>}
    <div className="seg ro-tabs" role="group">
      <button type="button" aria-pressed={view === 'common'} onClick={() => setView('common')}>Common activities ({common.length})</button>
      <button type="button" aria-pressed={view === 'unique'} onClick={() => setView('unique')}>Unique activities ({unique.length})</button></div>
    {view === 'common' ? (!common.length ? <div className="empty">None of {s.name}'s activities is also done by the team.</div>
      : <div className="ro-gridwrap"><table className="ro-grid">
        <thead><tr><th style={{ minWidth: 300 }}>{s.name}'s activity</th>
          {repsC.map(r => <th key={r.code} style={{ minWidth: 240 }}>{r.name}<small>{[r.position, r.grade].filter(Boolean).join(' · ')}</small></th>)}</tr></thead>
        <VolGroups list={common} cols={repsC.length + 1} render={a => <tr key={a.id}><td><Act a={a} /></td>
          {repsC.map(r => { const ms = (byA[a.id] || []).filter(m => !m.check && actOf[m.b] && actOf[m.b].who === r.code)
            return <td key={r.code} className={ms.length ? (ms.some(m => m.conf === 'high') ? 'm-hi' : 'm-md') : ''}>{ms.map(m => <div key={m.b} className="ro-m">
              <Act a={actOf[m.b]} /><em>{m.conf === 'high' ? 'Same work' : 'Partly the same'} · {m.reason}</em><Decide k={`${m.a}-${m.b}`} dec={dec} onSet={setDec} /></div>)}</td> })}</tr>} />
      </table></div>)
    : <div className="ro-uniq">{!unique.length ? <div className="empty">Every activity of {s.name} is also done by the team.</div> : <VolGroups list={unique} render={a => { const ov = (byA[a.id] || []).filter(m => m.check && actOf[m.b])
      return <div key={a.id} className="ro-uq"><Act a={a} />
        {ov.length > 0 && <div className="ro-ovs"><b>Oversees the team's work, not counted as the same:</b>{ov.slice(0, 3).map(m => <div key={m.b}>{reps.find(r => r.code === actOf[m.b].who)?.name}: {short(actOf[m.b].desc, 160)}</div>)}{ov.length > 3 && <div>and {ov.length - 3} more</div>}</div>}</div> }} />}</div>}
    <p className="formula">Common: the supervisor and a direct report do the same task (red: clearly the same, amber: partly). Unique: only the supervisor does it; managing, overseeing, checking or approving what the team does is supervision and is listed here, not counted as the same work. Flags need at least 3 supervisor activities.</p>
    <CaseBox d={{ ...d, recSubject: `Review the role of ${s.name} (${s.position || 'supervisor'})`, recDetails: `${d.summary}\n\n${f.same_pct}% of the supervisor's activities are also done by the team (${f.matched} of ${f.activities}).${f.supervisory_pct != null ? ` Supervisory work: ${f.supervisory_pct}%.` : ''}` }} fid={fid} notify={notify} user={user} onSaved={c => { c ? setD(x => ({ ...x, case: c })) : load(); onChanged() }} />
  </Modal>
}

function PairModal({ fid, a, b, notify, onClose, onChanged, user }) {
  const [d, setD] = useState(null)
  const load = () => api(`/api/ro/pair/${fid}/${encodeURIComponent(a)}/${encodeURIComponent(b)}`).then(setD).catch(e => { notify(e.message, true); onClose() })
  useEffect(() => { load() }, [a, b])
  const setDec = async (k, v) => {
    try { const c = await api('/api/ro/case', { method: 'PATCH', body: { key: d.key, function_id: fid, decision: { [k]: v } } }); setD(x => ({ ...x, case: c })); onChanged() } catch (e) { notify(e.message, true) }
  }
  if (!d) return <Modal wide title="Loading…" onClose={onClose}><div className="loading">Loading…</div></Modal>
  const A = Object.fromEntries(d.a.acts.map(x => [x.id, x])), B = Object.fromEntries(d.b.acts.map(x => [x.id, x])), f = d.figures, dec = d.case.decisions || {}
  return <Modal wide title={`${d.a.name} · ${d.b.name}`} sub={`${f.same_manager ? 'Same manager' : 'Same unit, different managers'} · analysed ${when(d.at)}`} onClose={onClose}>
    <div className="ro-figs"><Chip c={REGION[f.region][1]}>{REGION[f.region][0]}{f.region !== 'unknown' ? `: ${d.a.region}${f.region === 'different' ? ' · ' + d.b.region : ''}` : ''}</Chip>
      <span><b>{f.a_matched} of {f.a_acts}</b> of {d.a.name}'s activities</span><span><b>{f.b_matched} of {f.b_acts}</b> of {d.b.name}'s</span>
      {(f.a_vday > 0 || f.b_vday > 0) && <span>Volume on the same work: <b>{vfmt(f.a_vday)}</b> and <b>{vfmt(f.b_vday)}</b> a day</span>}</div>
    {f.region === 'different' && <div className="ro-ai">They do the same work in different regions: usually regional cover rather than duplication.</div>}
    <div className="ro-gridwrap"><table className="ro-grid">
      <thead><tr><th>{d.a.name}<small>{[d.a.position, d.a.grade, d.a.region].filter(Boolean).join(' · ')}</small></th><th>{d.b.name}<small>{[d.b.position, d.b.grade, d.b.region].filter(Boolean).join(' · ')}</small></th><th style={{ width: 220 }}>AI</th></tr></thead>
      <tbody>{d.matches.map(m => <tr key={m.a + '-' + m.b}><td><Act a={A[m.a] || B[m.a] || {}} /></td><td><Act a={B[m.b] || A[m.b] || {}} /></td>
        <td className={m.conf === 'high' ? 'm-hi' : 'm-md'}><em className="ro-why">{m.conf === 'high' ? 'High' : 'Medium'} · {m.reason}</em><Decide k={`${m.a}-${m.b}`} dec={dec} onSet={setDec} /></td></tr>)}</tbody>
    </table></div>
    <CaseBox d={{ ...d, recSubject: `Review the roles of ${d.a.name} and ${d.b.name}`, recDetails: `${f.a_matched} of ${f.a_acts} and ${f.b_matched} of ${f.b_acts} activities are the same work (${REGION[f.region][0].toLowerCase()}).` }} fid={fid} notify={notify} user={user} onSaved={c => { c ? setD(x => ({ ...x, case: c })) : load(); onChanged() }} />
  </Modal>
}

function Overview({ ov, onOpen, onCase }) {
  const t = ov.totals, n = ov.functions.length
  if (!n) return <div className="panel"><div className="empty">No function has been analysed yet.{ov.can_run ? ' Click Run Analysis.' : ' Ask the admin to run the analysis.'}</div></div>
  const fte = t.fte >= 10 ? Math.round(t.fte) : t.fte
  const byFte = ov.functions.filter(r => r.fte > 0).sort((a, b) => b.fte - a.fte).slice(0, 8)
  const mx = Math.max(1, ...byFte.map(r => r.fte))
  return <div className="ro-exec">
    <div className="ro-hero">
      <div className="ro-hl"><span className="ro-eyebrow">COSO · {n} of {ov.all_functions.length} functions analysed</span>
        <h2>{n0(t.cases)} roles to review, about <em>{fte} FTE</em> of work done twice</h2>
</div>
      <div className="ro-hk">
        <div><b>{n0(t.team_work)}</b><span>supervisors doing their team's work</span></div>
        <div><b>{n0(t.single)}</b><span>managers with a single report</span></div>
        <div><b>{n0(t.same_region)}</b><span>colleague pairs doing the same work in the same region</span></div>
        <div><b>{t.supervisory_avg != null ? t.supervisory_avg + '%' : '-'}</b><span>average supervisory share of supervisors' work</span></div>
      </div>
    </div>
    <div className="ro-ex2">
      <div className="panel"><div className="rhead"><div><h3>Where the capacity is</h3><span className="formula">Indicative FTE of overlapping work by function. Click to open.</span></div></div>
        {!byFte.length ? <div className="empty">No overlapping work found.</div> : <div className="ro-hbars">{byFte.map(r => <button key={r.id} type="button" onClick={() => onOpen(r.id)}>
          <span className="nm">{r.name}</span><span className="br"><i style={{ width: r.fte / mx * 100 + '%' }} /></span><b>≈ {r.fte >= 10 ? Math.round(r.fte) : r.fte}</b><small>{n0(r.cases)} case{r.cases === 1 ? '' : 's'}</small></button>)}</div>}
      </div>
      <div className="panel"><div className="rhead"><div><h3>Cases to look at first</h3><span className="formula">The strongest findings across COSO. Click to see the comparison.</span></div></div>
        <div className="ro-cases">{(ov.top || []).map(c => <button key={c.kind + c.codes.join('|')} type="button" onClick={() => onCase(c)}>
          <div className="ro-ch"><b>{c.who}</b></div>
          <div className="formula">{c.function}{c.position && c.kind === 'sup' ? ' · ' + c.position : ''}</div>
          <div className="ro-cf"><Chip c="c-red">{c.flag}</Chip>{c.fte > 0 && <span>≈ {c.fte} FTE</span>}</div>
          <p>{c.why}</p></button>)}
          {!(ov.top || []).length && <div className="empty">No flagged cases.</div>}</div>
      </div>
    </div>
    <details className="panel ro-det"><summary><h3>All functions in detail</h3><span className="formula">Every flag by function</span></summary>
      <div className="tw"><table><thead><tr><th>Function</th><th className="num">Supervisors</th><th>Doing team's work</th><th>Single report</th><th>Near-identical</th><th>Same work, same region</th><th className="num">Overlapping work</th><th>Analysed</th></tr></thead>
        <tbody>{ov.functions.map(r => <tr key={r.id} className="click" onClick={() => onOpen(r.id)}><td><b>{r.name}</b></td><td className="num">{n0(r.supervisors)}</td>
          <td><span className={'ro-heat ' + heat(r.team_work, 6)}>{r.team_work}</span></td><td><span className={'ro-heat ' + heat(r.single, 6)}>{r.single}</span></td>
          <td><span className={'ro-heat ' + heat(r.near, 4)}>{r.near}</span></td><td><span className={'ro-heat ' + heat(r.same_region, 8)}>{r.same_region}</span></td>
          <td className="num">{r.fte} FTE</td>
          <td className="formula">{when(r.at)}</td></tr>)}</tbody></table></div>
      {ov.not_analysed.length > 0 && <p className="formula">Not analysed yet: {ov.not_analysed.map(f => f.name).join(', ')}.</p>}
    </details>
  </div>
}

function ByFunction({ fid, setFid, ov, data, onSup, onPair }) {
  const [flag, setFlag] = useState('')
  const [rev, setRev] = useState('')
  const okRev = c => !rev || (rev === 'open' ? c === 'Open' : c === rev)
  const sups = !data?.analysed ? [] : data.supervisors.filter(s => okRev(s.case) && (!flag || (flag === 'region' ? false : s.flags.includes(flag))))
  const pairs = !data?.analysed ? [] : data.pairs.filter(p => okRev(p.case) && (!flag || (flag === 'region' && p.region === 'same')))
  return <>
    <div className="dc-bar">
      <select value={fid || ''} onChange={e => setFid(+e.target.value || null)}><option value="">Choose a function</option>{ov.all_functions.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}</select>
      <select value={flag} onChange={e => setFlag(e.target.value)}><option value="">All flags</option><option value="team_work">Doing team's work</option><option value="single">Single report</option><option value="near">Near-identical</option><option value="region">Same work, same region</option></select>
      <select value={rev} onChange={e => setRev(e.target.value)}><option value="">Any review status</option><option value="open">Not yet reviewed</option><option>Under review</option><option>Confirmed</option><option>Dismissed</option></select>
    </div>
    {!fid ? <div className="empty">Choose a function.</div> : !data ? <div className="loading">Loading…</div> : !data.analysed ? <div className="empty">This function has not been analysed yet.{data.can_run ? ' Click Run Analysis.' : ' Ask the admin to run the analysis.'}</div> : <div className="ro-two">
      <div className="panel"><div className="rhead"><div><h3>Supervisors and their teams</h3><span className="formula">{fmt(sups.length)} of {fmt(data.supervisors.length)} · analysed {when(data.at)}</span></div></div>
        <div className="tw"><table><thead><tr><th>Supervisor</th><th className="num" title="Direct reports">Direct reports</th><th title="How many of the supervisor's activities a direct report also does">Activities also done by the team</th><th className="num" title="Share of the supervisor's activities that are supervision">Supervisory share</th><th>Flags</th><th>Review</th></tr></thead>
          <tbody>{sups.map(s => <tr key={s.code} className="click" onClick={() => onSup(s.code)}><td><b>{s.name}</b><small className="formula" style={{ display: 'block' }}>{[s.position, s.grade].filter(Boolean).join(' · ')}</small></td>
            <td className="num">{s.team}</td><td><span className="ro-bar"><i><b style={{ width: s.same_pct + '%', background: s.flags.includes('few') ? 'var(--ink-3)' : s.same_pct >= data.threshold ? 'var(--coral)' : 'var(--amber)' }} /></i><b>{s.matched} of {s.activities}</b><small>{s.same_pct}%</small></span></td>
            <td className="num">{s.supervisory_pct != null ? s.supervisory_pct + '%' : '-'}</td>
            <td>{s.flags.map(x => FLAG[x] && <Chip key={x} c={FLAG[x][1]}>{FLAG[x][0]}</Chip>)}</td><td><Chip c={STATUS_COL[s.case]}>{s.case}</Chip></td></tr>)}
            {!sups.length && <tr><td colSpan={6} className="formula">Nothing matches the filters.</td></tr>}</tbody></table></div></div>
      <div className="panel"><div className="rhead"><div><h3>Colleagues doing the same work</h3><span className="formula">Same manager, or the same unit under different managers</span></div></div>
        <div className="tw"><table><thead><tr><th>Colleagues</th><th title="Activities that are the same work, out of each person's activities">Same activities (each)</th><th>Region</th><th className="num">Volume a day</th><th>Review</th></tr></thead>
          <tbody>{pairs.map(p => <tr key={p.a.code + p.b.code} className="click" onClick={() => onPair(p.a.code, p.b.code)}><td><b>{p.a.name} · {p.b.name}</b>
            <small className="formula" style={{ display: 'block' }}>{p.same_manager ? `under ${p.manager || 'the same manager'}` : 'same unit, different managers'}</small></td>
            <td>{p.a_matched} of {p.a_acts} · {p.b_matched} of {p.b_acts}</td><td><Chip c={REGION[p.region][1]}>{REGION[p.region][0]}</Chip></td>
            <td className="num">{p.a_vday || p.b_vday ? `${vfmt(p.a_vday)} · ${vfmt(p.b_vday)}` : '-'}</td><td><Chip c={STATUS_COL[p.case]}>{p.region === 'different' && p.case === 'Open' ? 'Regional cover' : p.case}</Chip></td></tr>)}
            {!pairs.length && <tr><td colSpan={5} className="formula">Nothing matches the filters.</td></tr>}</tbody></table></div></div>
    </div>}
  </>
}

function Tracker({ onOpen }) {
  const [d, setD] = useState(null)
  const [st, setSt] = useState('')
  useEffect(() => { api('/api/ro/tracker').then(setD).catch(() => setD({ cases: [] })) }, [])
  if (!d) return <div className="loading">Loading…</div>
  const rows = d.cases.filter(c => !st || c.status === st)
  return <div className="panel">
    <div className="dc-bar"><select value={st} onChange={e => setSt(e.target.value)}><option value="">All statuses ({d.cases.length})</option>{d.statuses.map(s => <option key={s}>{s} ({d.cases.filter(c => c.status === s).length})</option>)}</select></div>
    {!rows.length ? <div className="empty">No cases reviewed yet. Open a supervisor or a pair of colleagues and save a review.</div>
      : <div className="tw"><table><thead><tr><th>Case</th><th>Function</th><th>Status</th><th>Note</th><th>Owner</th><th>Updated</th></tr></thead>
        <tbody>{rows.map(c => <tr key={c.key} className="click" onClick={() => onOpen(c)}><td><b>{c.label}</b><small className="formula" style={{ display: 'block' }}>{c.kind === 'pair' ? 'Colleagues' : 'Supervisor'}</small></td>
          <td>{c.function}</td><td><Chip c={STATUS_COL[c.status]}>{c.status}{c.decision_id ? ' → Recommendation' : ''}</Chip></td><td className="formula" style={{ maxWidth: 320 }}>{c.note}</td>
          <td>{c.owner}</td><td className="formula">{when(c.updated_at)}</td></tr>)}</tbody></table></div>}
  </div>
}

export default function RoleOverlap({ notify, user }) {
  const [tab, setTab] = useState('overview')
  const [ov, setOv] = useState(null)
  const [fid, setFid] = useState(null)
  const [fd, setFd] = useState(null)
  const [run, setRun] = useState(null)
  const [open, setOpen] = useState(null)   // { kind: 'sup', code } | { kind: 'pair', a, b }
  const [rev, setRev] = useState(0)
  const loadOv = () => api('/api/ro/overview').then(o => { setOv(o); setRun(o.run) }).catch(e => notify(e.message, true))
  useEffect(() => { loadOv() }, [rev])
  useEffect(() => { if (!fid) { setFd(null); return } setFd(null); api('/api/ro/function/' + fid).then(setFd).catch(e => notify(e.message, true)) }, [fid, rev])
  const going = run && (run.status === 'queued' || run.status === 'running')
  useEffect(() => {   // while a run is going, check its progress; reload the results when it ends
    if (!going) return
    const t = setInterval(() => api('/api/ro/run').then(r => { setRun(r); if (r && r.status !== 'queued' && r.status !== 'running') { setRev(x => x + 1); if (r.status === 'failed') notify(r.error || 'The analysis failed.', true) } }).catch(() => {}), 3000)
    return () => clearInterval(t)
  }, [going])
  const start = async f => {
    if (!confirm(f ? 'Run the AI analysis for this function? It takes a few minutes; you can leave the page.' : 'Run the AI analysis for every function? It can take up to an hour; you can leave the page.')) return
    try { setRun(await api('/api/ro/run', { method: 'POST', body: { function_id: f || null } })); notify('Analysis started.') } catch (e) { notify(e.message, true) }
  }
  const stop = async () => { try { await api('/api/ro/run/stop', { method: 'POST' }); notify('Stopping after the current requests…') } catch (e) { notify(e.message, true) } }
  const changed = () => setRev(x => x + 1)
  const openFn = id => { setFid(id); setTab('function') }
  if (!ov) return <section className="view on"><div className="loading">Loading…</div></section>
  return <section className="view on">
    <header className="pghead"><h1>Role Overlap</h1>
      <div className="pg-side">
        <button className="btn" onClick={() => download('/api/ro/pdf', 'role_overlap.pdf').catch(e => notify(e.message, true))} disabled={!ov.functions.length}>One-page PDF</button>
        <button className="btn" onClick={() => download('/api/ro/export' + (tab === 'function' && fid ? `?function_id=${fid}` : ''), 'role_overlap.xlsx').catch(e => notify(e.message, true))} disabled={!ov.functions.length}>Download Excel</button>
      </div></header>
    <div className="ro-top">
      <div className="tabs">{[['overview', 'COSO Overview'], ['function', 'By Function'], ['tracker', 'Review Tracker']].map(([k, l]) => <button key={k} aria-current={tab === k} onClick={() => setTab(k)}>{l}</button>)}</div>
      <RunBar run={run} canRun={ov.can_run} fid={tab === 'function' ? fid : null} onStart={start} onStop={stop} label={tab === 'function' && fid ? 'Run Analysis' : 'Run Analysis (All Functions)'} />
    </div>
    {run && run.status === 'failed' && !going && run.error && <p className="msg warn">{run.error}</p>}
    {tab === 'overview' && <Overview ov={ov} onOpen={openFn} onCase={c => { setFid(c.fid); setOpen(c.kind === 'pair' ? { kind: 'pair', a: c.codes[0], b: c.codes[1], fid: c.fid } : { kind: 'sup', code: c.codes[0], fid: c.fid }) }} />}
    {tab === 'function' && <ByFunction fid={fid} setFid={setFid} ov={ov} data={fd} onSup={code => setOpen({ kind: 'sup', code })} onPair={(a, b) => setOpen({ kind: 'pair', a, b })} />}
    {tab === 'tracker' && <Tracker key={rev} onOpen={c => { setFid(c.function_id); setOpen(c.kind === 'pair' ? { kind: 'pair', a: c.codes[0], b: c.codes[1], fid: c.function_id } : { kind: 'sup', code: c.codes[0], fid: c.function_id }) }} />}
    {open && open.kind === 'sup' && <SupervisorModal fid={open.fid || fid} code={open.code} notify={notify} user={user} onClose={() => setOpen(null)} onChanged={changed} />}
    {open && open.kind === 'pair' && <PairModal fid={open.fid || fid} a={open.a} b={open.b} notify={notify} user={user} onClose={() => setOpen(null)} onChanged={changed} />}
  </section>
}

// Admin → AI Server: where the on-premise AI is, how many requests at once, and the threshold for "Doing team's work"
export function AiServerTab({ notify }) {
  const [f, setF] = useState(null)
  const [test, setTest] = useState(null)
  const [busy, setBusy] = useState(false)
  useEffect(() => { api('/api/ro/ai').then(setF).catch(e => notify(e.message, true)) }, [])
  if (!f) return <div className="loading">Loading…</div>
  const set = (k, v) => setF(x => ({ ...x, [k]: v }))
  const save = async () => { try { setF(await api('/api/ro/ai', { method: 'PUT', body: f })); notify('AI server settings saved.') } catch (e) { notify(e.message, true) } }
  const run = async () => { setBusy(true); setTest(null); try { await save(); setTest({ ok: true, ...(await api('/api/ro/ai/test', { method: 'POST' })) }) } catch (e) { setTest({ ok: false, error: e.message }) } finally { setBusy(false) } }
  return <><div className="grid g2">
    <div className="panel vac-form"><h2>On-premise AI Server</h2>
      <p className="sub">The vLLM server on the VM that Role Overlap uses. It listens on the VM only (127.0.0.1); no data leaves the bank. See the update guide for starting it.</p>
      <label>Address<input className="inp" value={f.url} onChange={e => set('url', e.target.value)} placeholder="http://127.0.0.1:8000" /></label>
      <label>Model name (as served by vLLM)<input className="inp" value={f.model} onChange={e => set('model', e.target.value)} placeholder="qwen" /></label>
      <label>API key (only if vLLM was started with --api-key)<input className="inp" type="password" value={f.api_key} onChange={e => set('api_key', e.target.value)} placeholder="none" /></label>
      <div className="dc-grid">
        <label>Requests at once<input className="inp" type="number" min="1" max="16" value={f.concurrency} onChange={e => set('concurrency', +e.target.value)} /></label>
        <label>Answer length (tokens)<input className="inp" type="number" min="300" max="8000" value={f.max_tokens} onChange={e => set('max_tokens', +e.target.value)} /></label>
        <label>Wait per request (seconds)<input className="inp" type="number" min="20" max="1800" value={f.timeout} onChange={e => set('timeout', +e.target.value)} /></label>
      </div>
      <div className="ro-chk"><input id="ro-json" type="checkbox" checked={!!f.json_mode} onChange={e => set('json_mode', e.target.checked)} /><label htmlFor="ro-json">Ask vLLM for JSON answers (turn off if the server rejects it)</label></div>
      <div className="row-actions"><button className="btn pri" onClick={save}>Save</button><button className="btn" disabled={busy} onClick={run}>{busy ? 'Testing…' : 'Save and Test Connection'}</button></div>
      {test && (test.ok ? <p className="msg ok">Connected. Models: {test.models.join(', ')}. Answered in {test.seconds} s.</p> : <p className="msg warn">{test.error}</p>)}
    </div>
    <div className="panel vac-form"><h2>Role Overlap Rules</h2>
      <label>"Doing team's work" from (% of the supervisor's activities also done by the team)<input className="inp" type="number" min="10" max="100" value={f.threshold} onChange={e => set('threshold', +e.target.value)} style={{ maxWidth: 140 }} /></label>
      <p className="formula">Other flags: a single direct report; near-identical (one report does 70% or more of the manager's activities, and at least 2 of them); mainly supervisory (60% or more supervisory work). A supervisor with fewer than 3 activities is marked Few activities and not flagged. Changing the threshold updates the results at once.</p>
      <div className="row-actions"><button className="btn pri" onClick={save}>Save</button></div>
    </div>
  </div>
  <div style={{ marginTop: 16 }}><SummaryRunPanel notify={notify} /></div></>
}

// HR Dashboard → Summary: the restructuring at a glance (Current → Proposed), for the CHRO
import React, { useEffect, useMemo, useState } from 'react'
import { api } from '../api.js'
import { fmt } from '../org.js'
import { L } from '../prefs.js'
import { Modal, types } from '../ui.jsx'

const nz = v => (v ? fmt(v) : '–')
const XC = { fte: '#7FD3C0', dc: '#E8B547', ftc: '#3FA592', dw: '#B59BD6' }
const SRC = [['', 'Entered'], ['pr', 'PR contract staff replaced'], ['nonpr', 'Non-PR staff replaced'], ['trade', 'Trade Staff Realignment'], ['redeploy', 'Trade Staff Redeployment']]
const qKey = q => { const m = /Q\s*([1-4])\D*(\d{4})/i.exec(q || ''); return m ? +m[2] * 10 + +m[1] : 99999 }

// people of one type: all, FTE (permanent and PR contract) or FTC (and daily wagers)
const ofType = t => p => t === 'FTE' ? p.fte : t === 'FTC' ? !p.fte : true

// the figures of one state: staff, managers (anyone with a direct report), direct-report links, HR layers (KM L1, his directs L2 …)
function shape(O, pop, tf = () => true) {   // tf: the type of the direct reports counted (FTE / FTC: their managers, of any type)
  const reps = p => p.kids.filter(k => O.counted(k) && tf(k)).length
  const mgr = O.C.filter(p => reps(p) > 0), links = mgr.reduce((a, p) => a + reps(p), 0)
  const lay = {}; pop.forEach(p => { if (p.d >= 0) lay[p.d + 1] = (lay[p.d + 1] || 0) + 1 })
  const fns = new Set(pop.filter(p => p !== O.ROOT).map(p => O.F[p.f]).filter(Boolean))
  return { staff: pop.length, mgr: mgr.length, links, span: mgr.length ? links / mgr.length : 0, mgrOwn: pop.filter(p => p.nk > 0).length, layers: Math.max(0, ...Object.keys(lay).map(Number)), lay, fns: fns.size }
}

// bell curves of staff by layer: Current (dashed) and Proposed (solid)
function LayerCurve({ A, B, onPick }) {
  const n = Math.max(1, ...Object.keys(A).map(Number), ...Object.keys(B).map(Number)), Ls = Array.from({ length: n }, (_, i) => i + 1)
  const W = 1200, H = 240, pl = 40, pr = 40, pt = 30, pb = 36
  const mx = Math.max(1, ...Object.values(A), ...Object.values(B)) * 1.14
  const X = l => pl + (l - 1) * (W - pl - pr) / Math.max(1, n - 1), Y = v => pt + (H - pt - pb) * (1 - v / mx), y0 = Y(0)
  const path = (D, close) => {
    const pts = Ls.map(l => [X(l), Y(D[l] || 0)])
    let s = `M${pts[0][0]},${pts[0][1]}`
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2
      const c1 = [p1[0] + (p2[0] - p0[0]) / 6, Math.min(p1[1] + (p2[1] - p0[1]) / 6, y0)], c2 = [p2[0] - (p3[0] - p1[0]) / 6, Math.min(p2[1] - (p3[1] - p1[1]) / 6, y0)]
      s += ` C${c1[0]},${c1[1]} ${c2[0]},${c2[1]} ${p2[0]},${p2[1]}`
    }
    return close ? s + ` L${pts[pts.length - 1][0]},${y0} L${pts[0][0]},${y0} Z` : s
  }
  return <div className="sm-lay">
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="Staff by layer, Current and Proposed">
      {[0, 1, 2, 3, 4].map(g => <line key={g} x1={pl} x2={W - pr} y1={pt + (H - pt - pb) * g / 4} y2={pt + (H - pt - pb) * g / 4} className="sm-grid" />)}
      <path d={path(A, true)} className="sm-a-f" /><path d={path(A, false)} className="sm-a-l" />
      <path d={path(B, true)} className="sm-b-f" /><path d={path(B, false)} className="sm-b-l" />
      {Ls.map(l => { const a = A[l] || 0, b = B[l] || 0, top = Math.min(a ? Y(a) : y0, b ? Y(b) : y0)
        return <g key={l} className="sm-pt" onClick={() => onPick(l)}>
          <rect x={X(l) - 40} y={pt - 20} width={80} height={H - pt} fill="transparent" />
          {a > 0 && <circle cx={X(l)} cy={Y(a)} r="4" className="sm-a-p" />}{b > 0 && <circle cx={X(l)} cy={Y(b)} r="4.5" className="sm-b-p" />}
          <text x={X(l)} y={top - 10} textAnchor="middle" className={b ? 'sm-v' : 'sm-v rm'}>{b ? fmt(b) : 'removed'}</text>
          <text x={X(l)} y={H - 12} textAnchor="middle" className="sm-l">L{l}</text></g> })}
    </svg>
    <div className="sm-cells" style={{ gridTemplateColumns: `repeat(${n}, 1fr)` }}>{Ls.map(l => { const a = A[l] || 0, b = B[l] || 0, d = b - a
      return <div key={l}><span>{fmt(a)} → {fmt(b)}</span><em className={d > 0 ? 'up' : d < 0 ? 'dn' : 'eq'}>{d ? (d > 0 ? '+' : '') + fmt(d) : '–'}</em></div> })}</div>
  </div>
}

// the function-wise table (as the HR team's format, without colours; not the top person's own function)
function FnTable({ oa, ob, typ, onClose }) {
  const [side, setSide] = useState('pro')
  const O = side === 'pro' ? ob : oa
  const pop = O.C.filter(ofType(typ)), all = pop.length
  const by = {}
  pop.forEach(p => { if (p === O.ROOT) return; const f = O.F[p.f] || '–'; const x = by[f] || (by[f] = { f, hc: 0, m: 0, links: 0, ml: 0 }); x.hc++; if (p.nk > 0) { x.m++; x.links += p.nk } x.ml = Math.max(x.ml, p.d + 1) })
  const rows = Object.values(by).filter(x => x.f !== (O.F[O.ROOT.f] || '')).sort((a, b) => b.hc - a.hc)
  return <Modal wide title="Function-wise" sub={typ === 'all' ? 'All staff' : typ} onClose={onClose}>
    <div className="row-actions" style={{ marginBottom: 10 }}><div className="sm-seg">{[['cur', L('hr.cur')], ['pro', L('hr.pro')]].map(([k, t]) => <button key={k} type="button" aria-pressed={side === k} onClick={() => setSide(k)}>{t}</button>)}</div></div>
    <div className="tw scroll" style={{ maxHeight: 480 }}><table>
      <thead><tr><th>Function</th><th className="num">HC</th><th className="num">% of HC</th><th className="num">Managers</th><th className="num">Avg Span</th><th className="num">Manager Density</th><th className="num">Max Layer</th></tr></thead>
      <tbody>{rows.map(x => <tr key={x.f}><td><b>{x.f}</b></td><td className="num">{fmt(x.hc)}</td><td className="num">{all ? Math.round(x.hc / all * 100) : 0}%</td><td className="num">{nz(x.m)}</td>
        <td className="num">{x.m ? Math.round(x.links / x.m) : '–'}</td><td className="num">{Math.round(x.m / x.hc * 100)}%</td><td className="num">L{x.ml}</td></tr>)}</tbody></table></div>
  </Modal>
}

// administrators: the initiatives (name, from the portal or entered, number, description, quarter)
function InitEdit({ rows, notify, onSaved, onClose }) {
  const [rs, setRs] = useState(() => rows.map(r => ({ ...r, n: r.n ?? '' })))
  const set = (i, k, v) => setRs(x => x.map((r, j) => j === i ? { ...r, [k]: v } : r))
  const save = async () => { try { const r = await api('/api/chro/summary-inits', { method: 'PUT', body: { rows: rs } }); notify('Saved.'); onSaved(r) } catch (e) { notify(e.message, true) } }
  return <Modal wide title="Headcount Saves Opportunities" sub="Number: blank uses the portal's count (for the portal ones)" onClose={onClose}>
    <div className="tw scroll" style={{ maxHeight: 460 }}><table>
      <thead><tr><th>Initiative</th><th>Number from</th><th className="num">Number</th><th>Description</th><th>Quarter</th><th /></tr></thead>
      <tbody>{rs.map((r, i) => <tr key={r.id || i}>
        <td><input className="inp" value={r.name} onChange={e => set(i, 'name', e.target.value)} style={{ width: '100%' }} /></td>
        <td><select className="inp" value={r.src} onChange={e => set(i, 'src', e.target.value)}>{SRC.map(([k, t]) => <option key={k} value={k}>{t}</option>)}</select></td>
        <td><input className="inp" value={r.n} onChange={e => set(i, 'n', e.target.value.replace(/[^0-9]/g, ''))} placeholder={r.src ? 'portal' : ''} style={{ width: 80, textAlign: 'right' }} /></td>
        <td><input className="inp" value={r.desc} onChange={e => set(i, 'desc', e.target.value)} style={{ width: '100%' }} /></td>
        <td><input className="inp" value={r.q} onChange={e => set(i, 'q', e.target.value)} placeholder="Q1 2027" style={{ width: 110 }} /></td>
        <td><button className="btn sm" onClick={() => setRs(x => x.filter((_, j) => j !== i))}>Remove</button></td></tr>)}</tbody></table></div>
    <div className="row-actions" style={{ justifyContent: 'space-between', marginTop: 10 }}>
      <button className="btn" onClick={() => setRs(x => [...x, { id: '', name: '', src: '', n: '', desc: '', q: '' }])}>Add an initiative</button>
      <button className="btn pri" onClick={save}>Save</button></div>
  </Modal>
}

export default function Summary({ oa, ob, obAll, op, fnName, canEdit, notify, people, onBench, onUnits, onGeo, onSpan, spanCount }) {
  const [typ, setTyp] = useState('all')
  const [inits, setInits] = useState(null)
  const [edit, setEdit] = useState(false), [fnOpen, setFnOpen] = useState(false), [consOpen, setConsOpen] = useState(false)
  useEffect(() => { api('/api/chro/summary-inits').then(setInits).catch(() => setInits([])) }, [])
  const tf = ofType(typ)
  const cur = useMemo(() => oa && shape(oa, oa.C.filter(tf), tf), [oa, typ])
  const pro = useMemo(() => ob && shape(ob, ob.C.filter(tf), tf), [ob, typ])
  // like for like: the Proposed layers count the surrendered staff too (the same people in both states)
  const proAll = useMemo(() => ob && shape(ob, ob.P.filter(p => !p.ctx && !p.rs && (ob.counted(p) || p.hs) && tf(p))), [ob, typ])
  const saves = useMemo(() => oa && obAll ? oa.C.filter(p => { const b = obAll.byId.get(p.id); return b && b.hs && !b.rp && tf(p) }) : [], [oa, obAll, typ])
  const [spanUp, spanDn] = spanCount(typ === 'all' ? 'all' : typ)
  if (!oa || !ob || !cur || !pro) return <div className="loading">Loading…</div>
  const tl = types().filter(t => ob.C.some(t.test))
  const tcount = k => ob.C.filter(p => types().find(t => t.k === k).test(p)).length
  const chip = (lab, a, b, fmtv = v => fmt(v), good = 'down', dfmt = v => fmt(v)) => { const d = Math.round((b - a) * 10) / 10
    return <div className="sm-chip"><small>{lab}</small><span className="fr">{fmtv(a)} →</span> <b>{fmtv(b)}</b>{d !== 0 && <em className={(good === 'down' ? d < 0 : d > 0) ? 'ok' : 'nok'}>{d > 0 ? '+' : '−'}{dfmt(Math.abs(d))}</em>}</div> }
  const srcRows = { pr: (op?.pr || []).filter(r => r.pr), nonpr: (op?.pr || []).filter(r => !r.pr), trade: op?.trade || [], redeploy: op?.redeploy || [] }
  const num = r => r.n !== null && r.n !== undefined && r.n !== '' ? +r.n : r.src ? srcRows[r.src].length : 0
  const openInit = r => { if (!r.src) return; const ps = srcRows[r.src].map(x => obAll.byId.get(x.code)).filter(Boolean); ps.length && people(r.name, ps, obAll) }
  const qs = inits ? [...new Set(inits.map(r => r.q || '—'))].sort((a, b) => qKey(a) - qKey(b)) : []
  const nCons = (op?.units_n || 0) + (op?.geo || []).length + (op?.cross || []).length
  const pick = l => { const ps = ob.P.filter(p => !p.ctx && !p.rs && (ob.counted(p) || p.hs) && tf(p) && p.d + 1 === l); ps.length && people(`Layer ${l} (${L('hr.pro')})`, ps, ob) }
  return <div className="sm">
    <div className="sm-bar"><div className="sm-seg">{[['all', 'All'], ['FTE', 'FTE'], ['FTC', 'FTC']].map(([k, t]) => <button key={k} type="button" aria-pressed={typ === k} onClick={() => setTyp(k)}>{t}</button>)}</div></div>
    <div className="sm-hero">
      <div><div className="sm-eye">{(fnName || L('dash.title')).toUpperCase()} · 2026</div><h1>{L('sum.title')}</h1><div className="sm-sub">{L('sum.sub')}</div>
        <button type="button" className="sm-btnl" onClick={() => setFnOpen(true)}>Function-wise table ›</button></div>
      <div><div className="sm-lab">{L('hr.outlook')} 2026</div><div className="sm-big">{fmt(pro.staff)}</div>
        {typ === 'all' && <><div className="sm-tbar">{tl.map(t => <i key={t.k} style={{ width: (tcount(t.k) / Math.max(1, pro.staff) * 100) + '%', background: XC[t.k] }} />)}</div>
          <div className="sm-leg">{tl.map(t => <span key={t.k}><i style={{ background: XC[t.k] }} />{t.label} <b>{fmt(tcount(t.k))}</b></span>)}</div></>}
        <div className="sm-sub" style={{ marginTop: 8 }}>Spread across {pro.fns} functions and {proAll.layers} hierarchical layers · Avg span <b>{Math.round(pro.span)}</b> ({fmt(pro.mgr)} managers hold {fmt(pro.links)}{typ === 'all' ? '' : ' ' + typ} direct-report links)</div></div>
      <div className="sm-chips">
        {chip('Layers', cur.layers, proAll.layers, v => 'L' + v)}
        {chip('Managers', cur.mgr, pro.mgr)}
        {chip('Avg span of control', Math.round(cur.span), Math.round(pro.span), v => fmt(v), 'up')}
        {chip('Managerial roles', Math.round(cur.mgrOwn / Math.max(1, cur.staff) * 1000) / 10, Math.round(pro.mgrOwn / Math.max(1, pro.staff) * 1000) / 10, v => v.toFixed(1) + '%', 'down', v => v.toFixed(1) + 'pt')}
      </div>
    </div>

    <h2 className="sm-h"><span className="n">1</span>STRATEGIC ALIGNMENT</h2>
    <div className="sm-sa">
      <button type="button" className="sm-t" onClick={onBench}><small>Position Benchmark</small><b className="txt">L1–L7 grade framework</b><span className="go">Open ›</span></button>
      <button type="button" className="sm-t" onClick={() => saves.length && people(L('hr.saved'), saves, oa)}><small>{L('hr.saved')}</small><b>{nz(saves.length)}</b><p>by December 2026</p><span className="go">›</span></button>
      <button type="button" className="sm-t" onClick={() => setConsOpen(true)}><small>Consolidation of Units</small><b>{nz(nCons)}</b><span className="go">›</span></button>
      <div className="sm-t two"><small>Span of Control</small><b><button type="button" onClick={() => spanUp && onSpan('up', typ)}>{nz(spanUp)}<span>Expansion</span></button><button type="button" onClick={() => spanDn && onSpan('down', typ)}>{nz(spanDn)}<span>Rationalization</span></button></b></div>
      <div className="sm-t st"><small>Managerial Layer</small><b className="txt"><span className="ok">✓</span> {L('sum.ml')}</b></div>
      <div className="sm-t st"><small>Governance</small><b className="txt"><span className="ok">✓</span> {L('sum.gov')}</b></div>
    </div>

    <h2 className="sm-h"><span className="n">2</span>HEADCOUNT SAVES OPPORTUNITIES{canEdit && <button type="button" className="linkbtn" style={{ marginLeft: 'auto' }} onClick={() => setEdit(true)}>Edit</button>}</h2>
    <div className="sm-tl" style={{ gridTemplateColumns: `repeat(${Math.max(1, qs.length)}, minmax(0, 1fr))` }}>
      {!inits ? <div className="formula">Loading…</div> : qs.map(q => <div key={q} className="sm-q"><h5>{q}</h5>
        {inits.filter(r => (r.q || '—') === q).map(r => <button type="button" key={r.id || r.name} className={'sm-it' + (r.src ? '' : ' static')} onClick={() => openInit(r)}>
          <span className="h">{r.name}<b>{nz(num(r))}</b></span>{r.desc && <span className="p">{r.desc}</span>}</button>)}</div>)}
    </div>

    <h2 className="sm-h"><span className="n">3</span>STRUCTURE SHIFT · LAYERS<span className="sm-k"><i className="k1" />{L('hr.cur')} <i className="k2" />{L('hr.pro')}</span></h2>
    <LayerCurve A={cur.lay} B={proAll.lay} onPick={pick} />

    {fnOpen && <FnTable oa={oa} ob={ob} typ={typ} onClose={() => setFnOpen(false)} />}
    {edit && <InitEdit rows={inits || []} notify={notify} onSaved={r => { setInits(r); setEdit(false) }} onClose={() => setEdit(false)} />}
    {consOpen && <Modal title="Consolidation of Units" onClose={() => setConsOpen(false)}>
      <div className="hx-ogr">{[[`Within ${ob.groupLabel}`, op?.units_n || 0, () => onUnits('within')], ['Geographic', (op?.geo || []).length, onGeo], [`Outside ${ob.groupLabel}`, (op?.cross || []).length, () => onUnits('outside')]].map(([t, v, go], j) =>
        <button type="button" key={t} className="hx-or" disabled={!v} onClick={() => { setConsOpen(false); go() }}><span className="hx-orn">{j + 1}</span><span className="hx-ort">{t}</span><b>{nz(v)}</b></button>)}</div></Modal>}
  </div>
}
